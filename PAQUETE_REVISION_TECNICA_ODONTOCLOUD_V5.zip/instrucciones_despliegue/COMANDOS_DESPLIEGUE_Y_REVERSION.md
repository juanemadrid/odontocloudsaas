# ODONTOCLOUD — PROCEDIMIENTOS DE DESPLIEGUE Y REVERSIÓN POR FASE (V5)

> [!WARNING]
> **ESTE DOCUMENTO ES DE CARÁCTER INFORMATIVO Y DE PLANIFICACIÓN TÉCNICA.**
> **LOS COMANDOS LISTADOS A CONTINUACIÓN NO ESTÁN AUTORIZADOS PARA SU EJECUCIÓN EN PRODUCCIÓN.**
> **NINGUNA ACCIÓN DEBE REALIZARSE EN PRODUCCIÓN SIN AUTORIZACIÓN EXPRESA PREVIA.**
> **LA RAMA MAIN SE MANTIENE INTACTA Y NO SE REALIZAN DESPLIEGUES AUTOMÁTICOS.**

---

## ESTRUCTURA DEL PAQUETE TÉCNICO V5

Este paquete contiene los 7 componentes verificados para la auditoría técnica independiente, incorporando la resolución definitiva de los hallazgos del ZIP V4:

1. `respaldos/r2_offsite_backup_age.sh`:
   - Comprobación criptográfica del contenido real del objeto remoto en R2 (`rclone cat ... | sha256sum`) contra el hash declarado en el manifiesto (`encrypted_sha256`).
   - Rechazo estricto de respuestas vacías, espacios en blanco o JSON inválido provenientes de `rclone` (`jq -e 'type == "array"'` y `type == "object"`).
   - Terminación obligatoria con código distinto de cero (`exit 6`) y emisión de alerta identificable `[R2_SYNC_INCOMPLETE]` si queda cualquier respaldo corrupto, incompleto o no demostrable.
   - Conservación de artefactos cifrados en staging local (`.staging_r2`) para evitar re-cifrados no deterministas.

2. `respaldos/restore_drill_isolated.sh`:
   - Bloqueo absoluto de restauración destructiva en clústeres compartidos con producción.
   - Exigencia obligatoria de `--confirm-disposable-cluster` y verificación técnica mediante sondeo SQL en catálogo (`pg_database`):
     - `EXTRA_DBS_COUNT == 0` (cero bases de datos ajenas en el clúster).
     - Cero bases de datos con nombres de otros sistemas (`odontocloud`, `edunexus`, `escolaria`, etc.).
   - Distinción técnica estricta entre **roles globales del clúster** (`pg_roles`) y **privilegios GRANT específicos por tabla** (`information_schema.table_privileges`).

3. `respaldos/R2_RETENCION_E_INMUTABILIDAD.md`:
   - Manual técnico que documenta la retención de 90 días en Cloudflare R2 frente a la conservación de 15 a 20 años de historias clínicas (**Resolución 839 de 2017**).
   - Especifica la activación obligatoria de **Bucket Lock (Object Retention)** y reglas de ciclo de vida (`Object Lifecycle`).

4. `seguridad_rls/20261011_preflight_check_clinical_rls.sql`:
   - Script diagnóstico 100% **DE SOLO LECTURA** (`BEGIN TRANSACTION READ ONLY`).
   - Realiza un inventario exhaustivo de las políticas RLS y funciones asistenciales antes de cualquier despliegue.
   - Detecta políticas clínicas que contienen `is_superadmin()` y evalúa políticas permisivas concurrentes que pudieran habilitar accesos indebidos por la semántica `OR` de PostgreSQL.
   - Verifica los supuestos estructurales de columnas y esquemas (`profiles.role`, `profiles.activo`, `tenant_id`).

5. `seguridad_rls/20261011_clinical_data_least_privilege.sql`:
   - Migración quirúrgica RLS de mínimo privilegio.
   - Remueve el bypass de superadmin en tablas clínicas (`pacientes`, `evoluciones`, `odontogramas`, `treatment_plans`, `consentimientos`, `documentos_clinicos`, `formulaciones`).
   - Limita la lectura y escritura clínica exclusivamente al personal asistencial (`is_clinical_staff()`) de la misma clínica.
   - Revoca la eliminación física (`DELETE`) en `pacientes` y `formulaciones` para salvaguardar la trazabilidad legal.
   - Restringe la función de Storage `can_access_private_attachment` a personal asistencial autenticado.

6. `seguridad_rls/20261011_rollback_clinical_data_least_privilege.sql`:
   - Reversión 100% simétrica con garantía matemática de igualdad (`Snapshot 0 === Snapshot 1`, 0 diffs en catálogo).
   - Restaura exactamente las políticas originales con sus cláusulas `USING` y `WITH CHECK`.
   - Restaura las políticas `DELETE` clínicas preexistentes y la versión original de `can_access_private_attachment`.

7. `instrucciones_despliegue/COMANDOS_DESPLIEGUE_Y_REVERSION.md`:
   - Este manual operativo de despliegue controlado y reversión inmediata.

---

## FASE A — RESPALDOS EXTERNOS ASIMÉTRICOS (CLOUDFLARE R2)

### 1. Pre-requisitos en Estación Administrativa Segura (Fuera del Servidor):
1. Instalar `age` en la estación local del Oficial de Seguridad.
2. Generar el par de claves criptográficas asimétricas:
   ```bash
   age-keygen -o odontocloud_offline_master.key
   ```
   - La clave privada (`AGE-SECRET-KEY-1...`) permanece resguardada de forma offline.
   - La clave pública (`age1...`) es el único artefacto transferido al VPS.

### 2. Configuración en Cloudflare R2:
1. En el bucket `odontocloud-backups-colombia`, activar **Bucket Lock (Object Retention)** con vigencia de **90 días**.
2. Configurar regla de ciclo de vida (`Object Lifecycle`) para expiración automática tras 90 días.
3. Generar API Token con alcance exclusivo al bucket de respaldos.

### 3. Instalación en el VPS (Servicio 2 - OdontoCloud):
```bash
# A. Instalar binarios requeridos en el host:
apt-get update && apt-get install -y age rclone jq

# B. Depositar exclusivamente la clave pública:
mkdir -p /etc/odontocloud
chmod 700 /etc/odontocloud
echo "age1tuclavepublica..." > /etc/odontocloud/backup_recipient.pub
chmod 400 /etc/odontocloud/backup_recipient.pub

# C. Configurar rclone (remoto 'r2-odontocloud', tipo s3, provider Cloudflare).

# D. Instalar script secundario de respaldo:
cp r2_offsite_backup_age.sh /usr/local/sbin/r2-backup-odontocloud.sh
chmod 700 /usr/local/sbin/r2-backup-odontocloud.sh
chown root:root /usr/local/sbin/r2-backup-odontocloud.sh

# E. Programar cron complementario (04:00 UTC, posterior al respaldo local de 03:15 UTC):
cat << 'EOF' > /etc/cron.d/odontocloud-r2-backup
0 4 * * * root /usr/local/sbin/r2-backup-odontocloud.sh >> /var/log/odontocloud-r2-backup.log 2>&1
EOF
chmod 644 /etc/cron.d/odontocloud-r2-backup
```

### 4. Procedimiento de Reversión (Fase A):
```bash
# Remover el cron secundario y el script complementario:
rm -f /etc/cron.d/odontocloud-r2-backup
rm -f /usr/local/sbin/r2-backup-odontocloud.sh
# El respaldo local nativo a las 03:15 UTC se mantiene completamente intacto y operativo.
```

---

## FASE B — SEGURIDAD RLS Y MÍNIMO PRIVILEGIO CLÍNICO

### 1. Pre-vuelo Diagnóstico Obligatorio (Solo Lectura, Cero Modificaciones):
Antes de cualquier aplicación, ejecutar el pre-flight check de compatibilidad para inventariar políticas y validar supuestos:
```bash
docker exec -i supabase-db-ueh7xuehxl9thmhre7fpk4xx psql -U postgres -d postgres -v ON_ERROR_STOP=1 \
  < 20261011_preflight_check_clinical_rls.sql
```

### 2. Comandos de Aplicación (Ventana Autorizada):
```bash
docker exec -i supabase-db-ueh7xuehxl9thmhre7fpk4xx psql -U postgres -d postgres -v ON_ERROR_STOP=1 \
  < 20261011_clinical_data_least_privilege.sql
```

### 3. Procedimiento de Reversión Inmediata (Fase B):
```bash
docker exec -i supabase-db-ueh7xuehxl9thmhre7fpk4xx psql -U postgres -d postgres -v ON_ERROR_STOP=1 \
  < 20261011_rollback_clinical_data_least_privilege.sql
```
