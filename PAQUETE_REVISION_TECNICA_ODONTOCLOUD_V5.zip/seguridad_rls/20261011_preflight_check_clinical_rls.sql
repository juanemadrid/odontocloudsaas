-- ==============================================================================
-- ODONTOCLOUD — PRE-FLIGHT READ-ONLY CHECK: COMPATIBILIDAD RLS CLÍNICO
-- ==============================================================================
-- Este script es 100% de SOLO LECTURA (READ ONLY).
-- NO realiza ninguna modificación en el catálogo ni en los datos productivos.
--
-- PROPÓSITO:
--   1. Realizar un inventario exhaustivo de las tablas clínicas y sus políticas RLS actuales.
--   2. Detectar políticas que contienen bypass de superadmin ('is_superadmin()').
--   3. Identificar políticas permisivas adicionales o redundantes que podrían mantener
--      acceso indebido a datos clínicos a través del mecanismo de unión OR de PostgreSQL.
--   4. Inspeccionar el estado y definición de funciones críticas:
--      - public.is_clinical_staff()
--      - public.can_access_private_attachment(text)
--      - public.is_superadmin()
--      - public.get_user_tenant_id()
--      - public.is_active_user()
--   5. Verificar supuestos estructurales de la migración y del rollback.
-- ==============================================================================

\set ON_ERROR_STOP on

BEGIN TRANSACTION READ ONLY;

-- ------------------------------------------------------------------------------
-- 1. INVENTARIO DE TABLAS CLÍNICAS Y ESTADO DE ROW LEVEL SECURITY
-- ------------------------------------------------------------------------------
SELECT
  c.relname AS tabla_clinica,
  c.relrowsecurity AS rls_habilitado,
  c.relforcerowsecurity AS rls_forzado,
  (SELECT count(*) FROM pg_policy p WHERE p.polrelid = c.oid) AS total_politicas
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'public'
  AND c.relname IN (
    'pacientes',
    'evoluciones',
    'odontogramas',
    'treatment_plans',
    'consentimientos',
    'documentos_clinicos',
    'formulaciones'
  )
ORDER BY c.relname;


-- ------------------------------------------------------------------------------
-- 2. INVENTARIO COMPLETO DE POLÍTICAS RLS VIGENTES EN TABLAS CLÍNICAS
-- ------------------------------------------------------------------------------
SELECT
  p.tablename,
  p.policyname,
  p.permissive,
  p.roles,
  p.cmd,
  p.qual AS expresion_using,
  p.with_check AS expresion_with_check
FROM pg_policies p
WHERE p.schemaname = 'public'
  AND p.tablename IN (
    'pacientes',
    'evoluciones',
    'odontogramas',
    'treatment_plans',
    'consentimientos',
    'documentos_clinicos',
    'formulaciones'
  )
ORDER BY p.tablename, p.cmd, p.policyname;


-- ------------------------------------------------------------------------------
-- 3. DETECCIÓN DE EXPOSICIÓN A SUPERADMIN EN POLÍTICAS RLS
-- ------------------------------------------------------------------------------
SELECT
  p.tablename,
  p.policyname,
  p.cmd,
  p.permissive,
  CASE
    WHEN (coalesce(p.qual, '') ~* 'is_superadmin' OR coalesce(p.with_check, '') ~* 'is_superadmin') THEN 'EXPUESTO_A_SUPERADMIN'
    ELSE 'NO_EXPUESTO'
  END AS diagnostico_superadmin,
  p.qual AS expresion_using
FROM pg_policies p
WHERE p.schemaname = 'public'
  AND p.tablename IN (
    'pacientes',
    'evoluciones',
    'odontogramas',
    'treatment_plans',
    'consentimientos',
    'documentos_clinicos',
    'formulaciones'
  )
  AND (coalesce(p.qual, '') ~* 'is_superadmin' OR coalesce(p.with_check, '') ~* 'is_superadmin')
ORDER BY p.tablename, p.policyname;


-- ------------------------------------------------------------------------------
-- 4. DETECCIÓN DE POLÍTICAS PERMISIVAS ADICIONALES (MECANISMO OR DE POSTGRESQL)
-- En PostgreSQL, si existen múltiples políticas PERMISSIVE sobre la misma tabla y comando,
-- el acceso se otorga si CUALQUIERA de ellas se cumple (A OR B).
-- Este reporte detecta si existen políticas alternas que mantengan superadmin activo.
-- ------------------------------------------------------------------------------
SELECT
  p.tablename,
  p.cmd,
  count(*) AS cantidad_politicas_permisivas,
  string_agg(p.policyname, ', ' ORDER BY p.policyname) AS nombres_politicas,
  CASE
    WHEN count(*) > 1 THEN 'ALERTA: MULTIPLES_POLITICAS_PERMISIVAS_CONCURRENTE'
    ELSE 'CORRECTO: POLITICA_UNICA'
  END AS evaluacion_aislamiento
FROM pg_policies p
WHERE p.schemaname = 'public'
  AND p.permissive = 'PERMISSIVE'
  AND p.tablename IN (
    'pacientes',
    'evoluciones',
    'odontogramas',
    'treatment_plans',
    'consentimientos',
    'documentos_clinicos',
    'formulaciones'
  )
GROUP BY p.tablename, p.cmd
ORDER BY p.tablename, p.cmd;


-- ------------------------------------------------------------------------------
-- 5. ESTADO Y DEFINICIÓN DE FUNCIONES DE SEGURIDAD Y ASISTENCIA
-- ------------------------------------------------------------------------------
SELECT
  p.proname AS nombre_funcion,
  pg_get_function_arguments(p.oid) AS argumentos,
  pg_get_function_result(p.oid) AS tipo_retorno,
  p.prosecdef AS security_definer,
  CASE
    WHEN pg_get_functiondef(p.oid) ~* 'is_superadmin' THEN 'CONTIENE_SUPERADMIN'
    ELSE 'SIN_SUPERADMIN'
  END AS diagnostico_superadmin
FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
WHERE n.nspname = 'public'
  AND p.proname IN (
    'is_clinical_staff',
    'can_access_private_attachment',
    'is_superadmin',
    'get_user_tenant_id',
    'is_active_user'
  )
ORDER BY p.proname;


-- ------------------------------------------------------------------------------
-- 6. VERIFICACIÓN ESTRICTA Y DEMOSTRACIÓN DE CONDICIONES PREVIAS (BLOQUEANTE)
-- Valida obligatoriamente:
--   a) Que RLS esté habilitado en todas las tablas clínicas.
--   b) Que las SIETE (7) políticas DELETE preexistentes existan efectivamente en el estado previo
--      (garantizando que el rollback recrea exactamente políticas legítimas preexistentes).
--   c) Que la función de Storage 'can_access_private_attachment' exista en el catálogo.
--   d) Que las columnas 'tenant_id', 'profiles.role' y 'profiles.activo' existan.
-- Si CUALQUIER condición falla, detiene la ejecución con [PRE-FLIGHT BLOQUEADO].
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_col_exists boolean;
  v_rls_enabled boolean;
  v_pol_exists boolean;
  v_storage_fn_exists boolean;
  v_blocking_errors text := '';
  v_table text;
  v_tables text[] := ARRAY['pacientes', 'evoluciones', 'odontogramas', 'treatment_plans', 'consentimientos'];
BEGIN
  -- A. Verificar RLS habilitado en tablas clínicas
  FOREACH v_table IN ARRAY v_tables LOOP
    SELECT coalesce(c.relrowsecurity, false) INTO v_rls_enabled
    FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname = 'public' AND c.relname = v_table;

    IF NOT v_rls_enabled THEN
      v_blocking_errors := v_blocking_errors || 'RLS_DESHABILITADO en ' || v_table || '; ';
    END IF;
  END LOOP;

  -- B. Verificar existencia previa y equivalencia exacta de las SIETE (7) políticas DELETE
  -- Cada política debe ser: cmd = 'DELETE', permissive = 'PERMISSIVE', para rol 'authenticated',
  -- with_check IS NULL, y con predicado que comprueba tenant_id e is_superadmin.

  -- 1. pacientes_tenant_delete
  SELECT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public' AND tablename = 'pacientes' AND policyname = 'pacientes_tenant_delete'
      AND cmd = 'DELETE' AND permissive = 'PERMISSIVE' AND ('authenticated' = ANY(roles))
      AND with_check IS NULL AND qual ~* 'is_active_user' AND qual ~* 'tenant_id' AND qual ~* 'is_superadmin'
  ) INTO v_pol_exists;
  IF NOT v_pol_exists THEN v_blocking_errors := v_blocking_errors || 'POLITICA_INVALIDA: pacientes_tenant_delete (debe ser DELETE PERMISSIVE para authenticated con tenant_id e is_superadmin); '; END IF;

  -- 2. evoluciones_tenant_delete
  SELECT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public' AND tablename = 'evoluciones' AND policyname = 'evoluciones_tenant_delete'
      AND cmd = 'DELETE' AND permissive = 'PERMISSIVE' AND ('authenticated' = ANY(roles))
      AND with_check IS NULL AND qual ~* 'is_active_user' AND qual ~* 'tenant_id' AND qual ~* 'is_superadmin'
  ) INTO v_pol_exists;
  IF NOT v_pol_exists THEN v_blocking_errors := v_blocking_errors || 'POLITICA_INVALIDA: evoluciones_tenant_delete (debe ser DELETE PERMISSIVE para authenticated con tenant_id e is_superadmin); '; END IF;

  -- 3. odontogramas_tenant_delete
  SELECT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public' AND tablename = 'odontogramas' AND policyname = 'odontogramas_tenant_delete'
      AND cmd = 'DELETE' AND permissive = 'PERMISSIVE' AND ('authenticated' = ANY(roles))
      AND with_check IS NULL AND qual ~* 'is_active_user' AND qual ~* 'tenant_id' AND qual ~* 'is_superadmin'
  ) INTO v_pol_exists;
  IF NOT v_pol_exists THEN v_blocking_errors := v_blocking_errors || 'POLITICA_INVALIDA: odontogramas_tenant_delete (debe ser DELETE PERMISSIVE para authenticated con tenant_id e is_superadmin); '; END IF;

  -- 4. treatment_plans_tenant_delete
  SELECT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public' AND tablename = 'treatment_plans' AND policyname = 'treatment_plans_tenant_delete'
      AND cmd = 'DELETE' AND permissive = 'PERMISSIVE' AND ('authenticated' = ANY(roles))
      AND with_check IS NULL AND qual ~* 'is_active_user' AND qual ~* 'tenant_id' AND qual ~* 'is_superadmin'
  ) INTO v_pol_exists;
  IF NOT v_pol_exists THEN v_blocking_errors := v_blocking_errors || 'POLITICA_INVALIDA: treatment_plans_tenant_delete (debe ser DELETE PERMISSIVE para authenticated con tenant_id e is_superadmin); '; END IF;

  -- 5. consentimientos_tenant_delete
  SELECT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public' AND tablename = 'consentimientos' AND policyname = 'consentimientos_tenant_delete'
      AND cmd = 'DELETE' AND permissive = 'PERMISSIVE' AND ('authenticated' = ANY(roles))
      AND with_check IS NULL AND qual ~* 'is_active_user' AND qual ~* 'tenant_id' AND qual ~* 'is_superadmin'
  ) INTO v_pol_exists;
  IF NOT v_pol_exists THEN v_blocking_errors := v_blocking_errors || 'POLITICA_INVALIDA: consentimientos_tenant_delete (debe ser DELETE PERMISSIVE para authenticated con tenant_id e is_superadmin); '; END IF;

  -- 6. documentos_clinicos_tenant_delete (si la tabla existe)
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'documentos_clinicos') THEN
    SELECT EXISTS (
      SELECT 1 FROM pg_policies
      WHERE schemaname = 'public' AND tablename = 'documentos_clinicos' AND policyname = 'documentos_clinicos_tenant_delete'
        AND cmd = 'DELETE' AND permissive = 'PERMISSIVE' AND ('authenticated' = ANY(roles))
        AND with_check IS NULL AND qual ~* 'is_active_user' AND qual ~* 'tenant_id' AND qual ~* 'is_superadmin'
    ) INTO v_pol_exists;
    IF NOT v_pol_exists THEN v_blocking_errors := v_blocking_errors || 'POLITICA_INVALIDA: documentos_clinicos_tenant_delete; '; END IF;
  END IF;

  -- 7. formulaciones_delete o formulaciones_tenant_delete (si la tabla existe)
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'formulaciones') THEN
    SELECT EXISTS (
      SELECT 1 FROM pg_policies
      WHERE schemaname = 'public' AND tablename = 'formulaciones' AND policyname IN ('formulaciones_delete', 'formulaciones_tenant_delete')
        AND cmd = 'DELETE' AND permissive = 'PERMISSIVE'
        AND with_check IS NULL AND qual ~* 'tenant_id' AND qual ~* 'is_superadmin'
    ) INTO v_pol_exists;
    IF NOT v_pol_exists THEN v_blocking_errors := v_blocking_errors || 'POLITICA_INVALIDA: formulaciones_delete; '; END IF;
  END IF;

  -- B.2. Verificar existencia previa y equivalencia exacta de políticas SELECT, INSERT, UPDATE en tablas clínicas
  -- Demuestra igualdad de predicados, roles ('authenticated'), permissiveness ('PERMISSIVE') y WITH CHECK
  FOREACH v_table IN ARRAY v_tables LOOP
    -- SELECT
    SELECT EXISTS (
      SELECT 1 FROM pg_policies
      WHERE schemaname = 'public' AND tablename = v_table AND cmd = 'SELECT'
        AND permissive = 'PERMISSIVE' AND ('authenticated' = ANY(roles))
        AND qual ~* 'is_active_user' AND qual ~* 'tenant_id' AND qual ~* 'is_superadmin'
    ) INTO v_pol_exists;
    IF NOT v_pol_exists THEN v_blocking_errors := v_blocking_errors || 'POLITICA_INVALIDA: SELECT en ' || v_table || ' (debe ser PERMISSIVE para authenticated con tenant_id e is_superadmin); '; END IF;

    -- INSERT
    SELECT EXISTS (
      SELECT 1 FROM pg_policies
      WHERE schemaname = 'public' AND tablename = v_table AND cmd = 'INSERT'
        AND permissive = 'PERMISSIVE' AND ('authenticated' = ANY(roles))
        AND with_check ~* 'is_active_user' AND with_check ~* 'tenant_id' AND with_check ~* 'is_superadmin'
    ) INTO v_pol_exists;
    IF NOT v_pol_exists THEN v_blocking_errors := v_blocking_errors || 'POLITICA_INVALIDA: INSERT en ' || v_table || ' (debe ser PERMISSIVE para authenticated con tenant_id e is_superadmin); '; END IF;

    -- UPDATE
    SELECT EXISTS (
      SELECT 1 FROM pg_policies
      WHERE schemaname = 'public' AND tablename = v_table AND cmd = 'UPDATE'
        AND permissive = 'PERMISSIVE' AND ('authenticated' = ANY(roles))
        AND qual ~* 'is_active_user' AND qual ~* 'tenant_id' AND qual ~* 'is_superadmin'
        AND with_check ~* 'is_active_user' AND with_check ~* 'tenant_id' AND with_check ~* 'is_superadmin'
    ) INTO v_pol_exists;
    IF NOT v_pol_exists THEN v_blocking_errors := v_blocking_errors || 'POLITICA_INVALIDA: UPDATE en ' || v_table || ' (debe ser PERMISSIVE para authenticated con tenant_id e is_superadmin); '; END IF;
  END LOOP;

  -- C. Verificar funciones de seguridad y Storage
  SELECT EXISTS (
    SELECT 1 FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.proname = 'can_access_private_attachment'
      AND p.prosecdef = true
      AND pg_get_functiondef(p.oid) ~* 'is_superadmin'
  ) INTO v_storage_fn_exists;
  IF NOT v_storage_fn_exists THEN
    v_blocking_errors := v_blocking_errors || 'FUNCION_STORAGE_INVALIDA: can_access_private_attachment (debe ser SECURITY DEFINER y contener bypass previo is_superadmin); ';
  END IF;

  -- Inspección del estado original de is_clinical_staff()
  SELECT EXISTS (
    SELECT 1 FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.proname = 'is_clinical_staff'
  ) INTO v_pol_exists;
  IF v_pol_exists THEN
    RAISE NOTICE '[PRE-FLIGHT INFO] Función public.is_clinical_staff() preexistente detectada en catálogo. El rollback preservará la función si existen dependencias activas.';
  ELSE
    RAISE NOTICE '[PRE-FLIGHT INFO] Función public.is_clinical_staff() no existe en el catálogo original; será creada de forma segura por la migración.';
  END IF;

  -- D. Verificar columnas estructurales
  FOREACH v_table IN ARRAY v_tables LOOP
    SELECT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema = 'public' AND table_name = v_table AND column_name = 'tenant_id'
    ) INTO v_col_exists;
    IF NOT v_col_exists THEN v_blocking_errors := v_blocking_errors || 'FALTA_COLUMNA: ' || v_table || '.tenant_id; '; END IF;
  END LOOP;

  SELECT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'profiles' AND column_name = 'role'
  ) INTO v_col_exists;
  IF NOT v_col_exists THEN v_blocking_errors := v_blocking_errors || 'FALTA_COLUMNA: profiles.role; '; END IF;

  SELECT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'profiles' AND column_name = 'activo'
  ) INTO v_col_exists;
  IF NOT v_col_exists THEN v_blocking_errors := v_blocking_errors || 'FALTA_COLUMNA: profiles.activo; '; END IF;

  -- E. Decisión de Autorización vs Bloqueo
  IF length(v_blocking_errors) > 0 THEN
    RAISE EXCEPTION '[PRE-FLIGHT BLOQUEADO] Despliegue NO AUTORIZADO por incompatibilidades o políticas ausentes: %', v_blocking_errors;
  ELSE
    RAISE NOTICE '[PRE-FLIGHT AUTORIZADO] Demostración exitosa: RLS habilitado, funciones verificadas, columnas conformes y políticas SELECT, INSERT, UPDATE y DELETE preexistentes confirmadas con igualdad de predicados y roles.';
  END IF;
END $$;

COMMIT;
