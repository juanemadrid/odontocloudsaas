-- ==============================================================================
-- ODONTOCLOUD — SCRIPT DE ROLLBACK EXACTO Y SIMÉTRICO
-- ==============================================================================
-- Restaura con precisión milimétrica y simetría total las políticas EXACTAS
-- que fueron modificadas o revocadas por '20261011_clinical_data_least_privilege.sql'
-- a su estado anterior idéntico al generado en '20260801_security_hardening.sql'
-- y '20250802_add_missing_columns.sql'.
--
-- Restaura todas las definiciones originales, incluyendo:
--   - Políticas SELECT, INSERT, UPDATE en todas las tablas clínicas afectadas.
--   - Políticas DELETE previamente existentes en pacientes, evoluciones,
--     odontogramas, treatment_plans, consentimientos, documentos_clinicos y formulaciones.
--   - Políticas 'formulaciones_select', 'formulaciones_insert', 'formulaciones_update',
--     y 'formulaciones_delete' con su nombre y predicado exacto original.
--
-- No toca ninguna otra tabla, no altera triggers, no borra adendas ni firmas.
-- Es 100% transaccional y se detiene ante cualquier error (\set ON_ERROR_STOP on).
-- ==============================================================================

\set ON_ERROR_STOP on

BEGIN;

-- 1. Restaurar función can_access_private_attachment a su estado previo
CREATE OR REPLACE FUNCTION public.can_access_private_attachment(object_name text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT public.is_superadmin()
    OR (
      public.is_active_user()
      AND (
        split_part(object_name, '/', 1) = public.get_user_tenant_id()::text
        OR (
          split_part(object_name, '/', 1) = 'pacientes'
          AND (
            split_part(object_name, '/', 2) = public.get_user_tenant_id()::text
            OR EXISTS (
              SELECT 1
              FROM public.pacientes AS patient
              WHERE patient.id::text = split_part(object_name, '/', 2)
                AND patient.tenant_id::text = public.get_user_tenant_id()::text
            )
          )
        )
      )
    );
$$;

REVOKE ALL ON FUNCTION public.can_access_private_attachment(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_access_private_attachment(text) TO authenticated;


-- 2. Restaurar políticas exactas previas en tablas clínicas afectadas

-- A. PACIENTES
DROP POLICY IF EXISTS pacientes_tenant_select ON public.pacientes;
CREATE POLICY pacientes_tenant_select ON public.pacientes FOR SELECT TO authenticated
USING (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));

DROP POLICY IF EXISTS pacientes_tenant_insert ON public.pacientes;
CREATE POLICY pacientes_tenant_insert ON public.pacientes FOR INSERT TO authenticated
WITH CHECK (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));

DROP POLICY IF EXISTS pacientes_tenant_update ON public.pacientes;
CREATE POLICY pacientes_tenant_update ON public.pacientes FOR UPDATE TO authenticated
USING (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()))
WITH CHECK (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));

DROP POLICY IF EXISTS pacientes_tenant_delete ON public.pacientes;
CREATE POLICY pacientes_tenant_delete ON public.pacientes FOR DELETE TO authenticated
USING (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));


-- B. EVOLUCIONES
DROP POLICY IF EXISTS evoluciones_tenant_select ON public.evoluciones;
CREATE POLICY evoluciones_tenant_select ON public.evoluciones FOR SELECT TO authenticated
USING (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));

DROP POLICY IF EXISTS evoluciones_tenant_insert ON public.evoluciones;
CREATE POLICY evoluciones_tenant_insert ON public.evoluciones FOR INSERT TO authenticated
WITH CHECK (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));

DROP POLICY IF EXISTS evoluciones_tenant_update ON public.evoluciones;
CREATE POLICY evoluciones_tenant_update ON public.evoluciones FOR UPDATE TO authenticated
USING (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()))
WITH CHECK (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));

DROP POLICY IF EXISTS evoluciones_tenant_delete ON public.evoluciones;
CREATE POLICY evoluciones_tenant_delete ON public.evoluciones FOR DELETE TO authenticated
USING (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));


-- C. ODONTOGRAMAS
DROP POLICY IF EXISTS odontogramas_tenant_select ON public.odontogramas;
CREATE POLICY odontogramas_tenant_select ON public.odontogramas FOR SELECT TO authenticated
USING (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));

DROP POLICY IF EXISTS odontogramas_tenant_insert ON public.odontogramas;
CREATE POLICY odontogramas_tenant_insert ON public.odontogramas FOR INSERT TO authenticated
WITH CHECK (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));

DROP POLICY IF EXISTS odontogramas_tenant_update ON public.odontogramas;
CREATE POLICY odontogramas_tenant_update ON public.odontogramas FOR UPDATE TO authenticated
USING (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()))
WITH CHECK (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));

DROP POLICY IF EXISTS odontogramas_tenant_delete ON public.odontogramas;
CREATE POLICY odontogramas_tenant_delete ON public.odontogramas FOR DELETE TO authenticated
USING (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));


-- D. TREATMENT_PLANS
DROP POLICY IF EXISTS treatment_plans_tenant_select ON public.treatment_plans;
CREATE POLICY treatment_plans_tenant_select ON public.treatment_plans FOR SELECT TO authenticated
USING (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));

DROP POLICY IF EXISTS treatment_plans_tenant_insert ON public.treatment_plans;
CREATE POLICY treatment_plans_tenant_insert ON public.treatment_plans FOR INSERT TO authenticated
WITH CHECK (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));

DROP POLICY IF EXISTS treatment_plans_tenant_update ON public.treatment_plans;
CREATE POLICY treatment_plans_tenant_update ON public.treatment_plans FOR UPDATE TO authenticated
USING (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()))
WITH CHECK (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));

DROP POLICY IF EXISTS treatment_plans_tenant_delete ON public.treatment_plans;
CREATE POLICY treatment_plans_tenant_delete ON public.treatment_plans FOR DELETE TO authenticated
USING (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));


-- E. CONSENTIMIENTOS
DROP POLICY IF EXISTS consentimientos_tenant_select ON public.consentimientos;
CREATE POLICY consentimientos_tenant_select ON public.consentimientos FOR SELECT TO authenticated
USING (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));

DROP POLICY IF EXISTS consentimientos_tenant_insert ON public.consentimientos;
CREATE POLICY consentimientos_tenant_insert ON public.consentimientos FOR INSERT TO authenticated
WITH CHECK (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));

DROP POLICY IF EXISTS consentimientos_tenant_update ON public.consentimientos;
CREATE POLICY consentimientos_tenant_update ON public.consentimientos FOR UPDATE TO authenticated
USING (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()))
WITH CHECK (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));

DROP POLICY IF EXISTS consentimientos_tenant_delete ON public.consentimientos;
CREATE POLICY consentimientos_tenant_delete ON public.consentimientos FOR DELETE TO authenticated
USING (public.is_active_user() AND (tenant_id::text = public.get_user_tenant_id()::text OR public.is_superadmin()));


-- F. DOCUMENTOS_CLINICOS (si la tabla existe)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'documentos_clinicos') THEN
    DROP POLICY IF EXISTS documentos_clinicos_tenant_select ON public.documentos_clinicos;
    CREATE POLICY documentos_clinicos_tenant_select ON public.documentos_clinicos FOR SELECT TO authenticated
    USING (public.is_active_user() AND (tenant_id = public.get_user_tenant_id() OR public.is_superadmin()));

    DROP POLICY IF EXISTS documentos_clinicos_tenant_insert ON public.documentos_clinicos;
    CREATE POLICY documentos_clinicos_tenant_insert ON public.documentos_clinicos FOR INSERT TO authenticated
    WITH CHECK (public.is_active_user() AND (tenant_id = public.get_user_tenant_id() OR public.is_superadmin()));

    DROP POLICY IF EXISTS documentos_clinicos_tenant_update ON public.documentos_clinicos;
    CREATE POLICY documentos_clinicos_tenant_update ON public.documentos_clinicos FOR UPDATE TO authenticated
    USING (public.is_active_user() AND (tenant_id = public.get_user_tenant_id() OR public.is_superadmin()))
    WITH CHECK (public.is_active_user() AND (tenant_id = public.get_user_tenant_id() OR public.is_superadmin()));

    DROP POLICY IF EXISTS documentos_clinicos_tenant_delete ON public.documentos_clinicos;
    CREATE POLICY documentos_clinicos_tenant_delete ON public.documentos_clinicos FOR DELETE TO authenticated
    USING (public.is_active_user() AND (tenant_id = public.get_user_tenant_id() OR public.is_superadmin()));
  END IF;
END
$$;


-- G. FORMULACIONES (si la tabla existe)
-- Restaura exactamente las políticas originales creadas en 20250802_add_missing_columns.sql
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'formulaciones') THEN
    DROP POLICY IF EXISTS "formulaciones_select" ON public.formulaciones;
    DROP POLICY IF EXISTS formulaciones_tenant_select ON public.formulaciones;
    CREATE POLICY "formulaciones_select" ON public.formulaciones FOR SELECT
      USING (tenant_id = public.get_user_tenant_id() OR public.is_superadmin());

    DROP POLICY IF EXISTS "formulaciones_insert" ON public.formulaciones;
    DROP POLICY IF EXISTS formulaciones_tenant_insert ON public.formulaciones;
    CREATE POLICY "formulaciones_insert" ON public.formulaciones FOR INSERT
      WITH CHECK (tenant_id = public.get_user_tenant_id() OR public.is_superadmin());

    DROP POLICY IF EXISTS "formulaciones_update" ON public.formulaciones;
    DROP POLICY IF EXISTS formulaciones_tenant_update ON public.formulaciones;
    CREATE POLICY "formulaciones_update" ON public.formulaciones FOR UPDATE
      USING (tenant_id = public.get_user_tenant_id() OR public.is_superadmin());

    DROP POLICY IF EXISTS "formulaciones_delete" ON public.formulaciones;
    DROP POLICY IF EXISTS formulaciones_tenant_delete ON public.formulaciones;
    CREATE POLICY "formulaciones_delete" ON public.formulaciones FOR DELETE
      USING (tenant_id = public.get_user_tenant_id() OR public.is_superadmin());
  END IF;
END
$$;


-- 3. Reversión segura de función auxiliar preservando estado y dependencias preexistentes
-- La migración utilizó CREATE OR REPLACE FUNCTION public.is_clinical_staff().
-- Para preservar funciones y políticas preexistentes sin causar efectos colaterales destructivos:
-- a) Se verifica si existen políticas RLS u otras funciones que hagan referencia a is_clinical_staff().
-- b) Si existen dependencias externas, la función se preserva íntegramente.
-- c) Si no existen dependencias en el catálogo, se elimina limpiamente restaurando el estado original.
DO $$
DECLARE
  v_has_active_deps boolean;
BEGIN
  -- Comprobar si existen políticas RLS que aún dependan de is_clinical_staff
  SELECT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND (coalesce(qual, '') ~* 'is_clinical_staff' OR coalesce(with_check, '') ~* 'is_clinical_staff')
  ) INTO v_has_active_deps;

  -- Comprobar si otras funciones o vistas del catálogo dependen de is_clinical_staff
  IF NOT v_has_active_deps THEN
    SELECT EXISTS (
      SELECT 1 FROM pg_proc p
      JOIN pg_namespace n ON n.oid = p.pronamespace
      WHERE n.nspname = 'public'
        AND p.proname NOT IN ('is_clinical_staff')
        AND coalesce(p.prosrc, '') ~* 'is_clinical_staff'
    ) INTO v_has_active_deps;
  END IF;

  IF v_has_active_deps THEN
    RAISE NOTICE '[ROLLBACK] Preservando public.is_clinical_staff(): existen objetos y políticas dependientes en el catálogo.';
  ELSE
    DROP FUNCTION IF EXISTS public.is_clinical_staff();
    RAISE NOTICE '[ROLLBACK] public.is_clinical_staff() revertida limpiamente sin dependencias residuales.';
  END IF;
END $$;

COMMIT;
