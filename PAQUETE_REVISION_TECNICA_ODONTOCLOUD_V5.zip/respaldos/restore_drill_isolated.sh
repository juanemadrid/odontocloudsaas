#!/usr/bin/env bash
# ==============================================================================
# ODONTOCLOUD — PROCEDIMIENTO DE RESTAURACIÓN DISASTER RECOVERY (ENTORNO AISLADO)
# ==============================================================================
# Este script ejecuta y valida el procedimiento de contingencia completo:
#   1. Verificación previa de integridad (.age contra manifiesto JSON).
#   2. Descifrado seguro con criptografía moderna 'age' usando la clave privada offline.
#   3. Validación de integridad SHA-256 del archivo .tgz original descifrado.
#   4. Extracción y verificación del paquete tar y de sus firmas internas (SHA256SUMS).
#   5. Verificación y desempaquetado de objetos de Supabase Storage (storage.tgz).
#   6. Verificación y restauración estricta de roles (roles.sql) con ON_ERROR_STOP=1.
#   7. Comprobación técnica objetiva de aislamiento en el destino antes de cualquier acción.
#   8. Ejecución de pg_restore --clean --exit-on-error EXCLUSIVAMENTE contra destino validado.
#   9. Verificación post-restauración de roles, privilegios, tablas, relaciones y funciones.
#
# REGLAS DE SEGURIDAD ESTRICTAS:
#   - PROHIBIDO EJECUTAR CONTRA BASES DE DATOS DE PRODUCCIÓN.
#   - Se prohíben valores por defecto destructivos o implícitos (localhost:5432).
#   - Se exigen obligatoriamente host, puerto, usuario, base de datos y --confirm-isolated-db.
#   - El destino debe superar una prueba técnica previa de aislamiento antes de ejecutar --clean.
# ==============================================================================

set -euo pipefail

usage() {
  cat <<EOF
Uso: $0 [OPCIONES]

Opciones obligatorias de descifrado:
  -f, --file ARCHIVO_AGE         Ruta al archivo cifrado con age (*.tgz.age)
  -k, --key ARCHIVO_KEY          Ruta a la clave privada age (AGE-SECRET-KEY-1...)

Opciones de destino y base de datos aislada (EXIGIDAS SI NO SE OMITE BD):
  -d, --dest CARPETA_DESTINO     Directorio temporal de trabajo (default: /tmp/odontocloud-restore-drill)
      --db-host HOST             Host de PostgreSQL de pruebas (EXPLÍCITO, ej: 127.0.0.1 o sandbox)
      --db-port PUERTO           Puerto de PostgreSQL de pruebas (EXPLÍCITO, ej: 5433 o 54322)
      --db-user USUARIO          Usuario administrador de la BD aislada (EXPLÍCITO, ej: postgres)
      --confirm-disposable-cluster Confirmación explícita de instancia/clúster PostgreSQL desechable y dedicada
      --confirm-isolated-db      (Compatibilidad) Confirmación de base de datos aislada
      --skip-db-restore          Omite pg_restore y valida únicamente descifrado, dump y storage
  -h, --help                     Muestra esta ayuda

Ejemplo de drill completo en base aislada:
  $0 -f /backups/odontocloud-20261010T031501Z.tgz.age \\
     -k /secure/keys/odontocloud_offline.key \\
     -d /tmp/restore_drill \\
     --db-host 127.0.0.1 --db-port 5433 --db-user postgres \\
     --db-name test_isolated_drill_db --confirm-isolated-db
EOF
  exit 1
}

ENCRYPTED_FILE=""
KEY_FILE=""
DEST_DIR="/tmp/odontocloud-restore-drill"
DB_HOST=""
DB_PORT=""
DB_USER=""
DB_NAME=""
CONFIRM_DISPOSABLE=false
SKIP_DB_RESTORE=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    -f|--file) ENCRYPTED_FILE="$2"; shift 2 ;;
    -k|--key) KEY_FILE="$2"; shift 2 ;;
    -d|--dest) DEST_DIR="$2"; shift 2 ;;
    --db-host) DB_HOST="$2"; shift 2 ;;
    --db-port) DB_PORT="$2"; shift 2 ;;
    --db-user) DB_USER="$2"; shift 2 ;;
    --db-name) DB_NAME="$2"; shift 2 ;;
    --confirm-disposable-cluster) CONFIRM_DISPOSABLE=true; shift 1 ;;
    --confirm-isolated-db) CONFIRM_DISPOSABLE=true; shift 1 ;;
    --skip-db-restore) SKIP_DB_RESTORE=true; shift 1 ;;
    -h|--help) usage ;;
    *) echo "Opción no reconocida: $1"; usage ;;
  esac
done

# Validaciones obligatorias de descifrado
if [[ -z "$ENCRYPTED_FILE" || -z "$KEY_FILE" ]]; then
  echo "ERROR CRÍTICO: Debe especificar el archivo cifrado (-f) y la clave privada age (-k)."
  usage
fi

if [[ ! -f "$ENCRYPTED_FILE" ]]; then
  echo "ERROR CRÍTICO: El archivo cifrado no existe: $ENCRYPTED_FILE"
  exit 1
fi

if [[ ! -f "$KEY_FILE" ]]; then
  echo "ERROR CRÍTICO: El archivo de clave privada age no existe: $KEY_FILE"
  exit 1
fi

if ! command -v age >/dev/null 2>&1; then
  echo "ERROR CRÍTICO: La herramienta 'age' no está instalada en el sistema."
  exit 1
fi

# Validaciones estrictas del destino de base de datos (Cero suposiciones o fallbacks silenciosos)
if [[ "$SKIP_DB_RESTORE" != "true" ]]; then
  if [[ -z "$DB_HOST" || -z "$DB_PORT" || -z "$DB_USER" || -z "$DB_NAME" ]]; then
    echo "ERROR CRÍTICO DE SEGURIDAD: Parámetros de base de datos incompletos."
    echo "Para restaurar la base de datos se exige especificar EXPLÍCITAMENTE todos los parámetros:"
    echo "  --db-host, --db-port, --db-user, --db-name y --confirm-disposable-cluster."
    echo "No se permiten valores implícitos ni por defecto (localhost:5432)."
    echo "Si solo desea verificar los archivos y Storage, utilice --skip-db-restore."
    exit 1
  fi

  # Prohibir host productivo
  if [[ "$DB_HOST" =~ ^(150\.136\.210\.37|.*odontocloudcolombia\.com.*|supabasekong.*)$ ]]; then
    echo "ERROR CRÍTICO BLOQUEANTE: El host '$DB_HOST' corresponde al entorno de producción."
    echo "PROHIBIDO TERMINANTEMENTE ejecutar pruebas de restauración contra producción."
    exit 1
  fi

  # Prohibir nombres de base de datos productivos o del sistema
  if [[ "$DB_NAME" =~ ^(postgres|production|odontocloud|odontocloud_prod|prod|edunexus|escolaria)$ ]]; then
    echo "ERROR CRÍTICO DE SEGURIDAD: El nombre '$DB_NAME' está reservado o pertenece a producción."
    echo "El drill exige una base de datos aislada específica de pruebas."
    exit 1
  fi

  # Exigir que el nombre contenga una palabra clave de prueba/aislamiento
  if [[ ! "$DB_NAME" =~ (test|isolated|staging|drill|sandbox|pruebas) ]]; then
    echo "ERROR CRÍTICO DE SEGURIDAD: El nombre de la base de datos '$DB_NAME' debe incluir explícitamente"
    echo "un término de aislamiento (test, isolated, staging, drill, sandbox o pruebas)."
    exit 1
  fi

  if [[ "$CONFIRM_DISPOSABLE" != "true" ]]; then
    echo "ERROR CRÍTICO DE SEGURIDAD: Debe confirmar explícitamente que la instancia/clúster PostgreSQL"
    echo "es 100% desechable e independiente para este drill mediante --confirm-disposable-cluster."
    echo "Está terminantemente prohibido ejecutar restauraciones destructivas en clústeres compartidos con producción."
    exit 1
  fi

  if ! command -v psql >/dev/null 2>&1; then
    echo "ERROR CRÍTICO: 'psql' no está instalado en el sistema y es obligatorio para validaciones y roles."
    exit 1
  fi

  if ! command -v pg_restore >/dev/null 2>&1; then
    echo "ERROR CRÍTICO: 'pg_restore' no está instalado en el sistema y se solicitó restauración de base de datos."
    exit 1
  fi
fi

echo "======================================================================="
echo " ODONTOCLOUD — DRILL DE RESTAURACIÓN CON AGE Y PG_RESTORE"
echo "======================================================================="
echo "Archivo cifrado: $ENCRYPTED_FILE"
echo "Clave privada:   $KEY_FILE"
echo "Directorio trab: $DEST_DIR"
if [[ "$SKIP_DB_RESTORE" == "true" ]]; then
  echo "Modo BD:         OMITIDO (--skip-db-restore)"
else
  echo "Destino BD:      ${DB_USER}@${DB_HOST}:${DB_PORT}/${DB_NAME} (CONFIRMADO AISLADO)"
fi
echo ""

mkdir -p "$DEST_DIR"

BASENAME="$(basename "$ENCRYPTED_FILE" .age)"
DECRYPTED_ARCHIVE="${DEST_DIR}/${BASENAME}"
MANIFEST_FILE="${ENCRYPTED_FILE}.manifest.json"

# PASO 1: Validación previa con manifiesto si está disponible
if [[ -f "$MANIFEST_FILE" ]]; then
  echo "[PASO 1/8] Verificando hash SHA256 contra el manifiesto..."
  EXPECTED_ENC_SHA="$(grep '"encrypted_sha256"' "$MANIFEST_FILE" | cut -d'"' -f4 || true)"
  if [[ -n "$EXPECTED_ENC_SHA" ]]; then
    ACTUAL_ENC_SHA="$(sha256sum "$ENCRYPTED_FILE" | awk '{print $1}')"
    if [[ "$EXPECTED_ENC_SHA" != "$ACTUAL_ENC_SHA" ]]; then
      echo "ERROR CRÍTICO: El hash del archivo cifrado no coincide con el manifiesto."
      echo "Esperado: $EXPECTED_ENC_SHA"
      echo "Obtenido: $ACTUAL_ENC_SHA"
      exit 1
    fi
    echo "✓ Integridad del archivo cifrado verificada correctamente contra manifiesto ($ACTUAL_ENC_SHA)."
  fi
else
  echo "[PASO 1/8] Manifiesto no encontrado en origen. Continuando con descifrado..."
fi

# PASO 2: Descifrado asimétrico con age
echo "[PASO 2/8] Descifrando paquete con 'age' y clave privada offline..."
age -d -i "$KEY_FILE" -o "$DECRYPTED_ARCHIVE" "$ENCRYPTED_FILE"

if [[ ! -f "$DECRYPTED_ARCHIVE" || ! -s "$DECRYPTED_ARCHIVE" ]]; then
  echo "ERROR CRÍTICO: Falló el descifrado del paquete age o el archivo resultante está vacío."
  exit 1
fi
echo "✓ Paquete descifrado exitosamente: $DECRYPTED_ARCHIVE"

# PASO 3: Validación del checksum original
if [[ -f "$MANIFEST_FILE" ]]; then
  echo "[PASO 3/8] Verificando hash del contenido original descifrado..."
  EXPECTED_ORIGINAL_SHA="$(grep '"original_sha256"' "$MANIFEST_FILE" | cut -d'"' -f4 || true)"
  if [[ -n "$EXPECTED_ORIGINAL_SHA" ]]; then
    ACTUAL_ORIGINAL_SHA="$(sha256sum "$DECRYPTED_ARCHIVE" | awk '{print $1}')"
    if [[ "$EXPECTED_ORIGINAL_SHA" != "$ACTUAL_ORIGINAL_SHA" ]]; then
      echo "ERROR CRÍTICO: El SHA256 descifrado no coincide con el original registrado en el manifiesto."
      echo "Esperado: $EXPECTED_ORIGINAL_SHA"
      echo "Obtenido: $ACTUAL_ORIGINAL_SHA"
      exit 1
    fi
    echo "✓ Checksum SHA256 del archivo original verificado exactamente ($ACTUAL_ORIGINAL_SHA)."
  fi
else
  echo "[PASO 3/8] Omitiendo verificación de hash original (sin archivo manifest.json)."
fi

# PASO 4: Desempaquetado y verificación de archivos internos
echo "[PASO 4/8] Verificando y descomprimiendo paquete tar principal..."
tar -tzf "$DECRYPTED_ARCHIVE" >/dev/null
EXTRACT_DIR="${DEST_DIR}/extracted_payload"
rm -rf "$EXTRACT_DIR"
mkdir -p "$EXTRACT_DIR"
tar -xzf "$DECRYPTED_ARCHIVE" -C "$EXTRACT_DIR"

if [[ -f "${EXTRACT_DIR}/SHA256SUMS" ]]; then
  echo "Verificando firmas internas de los componentes:"
  (cd "$EXTRACT_DIR" && sha256sum -c SHA256SUMS)
fi
echo "✓ Estructura de paquete tar y firmas internas verificadas."

# PASO 5: Verificación exhaustiva de Supabase Storage
echo "[PASO 5/8] Verificando y probando extracción de Supabase Storage..."
STORAGE_DIR="${DEST_DIR}/storage_verified"
rm -rf "$STORAGE_DIR"
mkdir -p "$STORAGE_DIR"

STORAGE_FILES_COUNT=0
if [[ -f "${EXTRACT_DIR}/storage.tgz" ]]; then
  tar -tzf "${EXTRACT_DIR}/storage.tgz" >/dev/null
  tar -xzf "${EXTRACT_DIR}/storage.tgz" -C "$STORAGE_DIR"
  STORAGE_FILES_COUNT="$(find "$STORAGE_DIR" -type f | wc -l)"
  echo "✓ Paquete storage.tgz extraído y verificado ($STORAGE_FILES_COUNT archivos/objetos comprobados)."
elif [[ -d "${EXTRACT_DIR}/storage" ]]; then
  cp -r "${EXTRACT_DIR}/storage"/* "$STORAGE_DIR/" 2>/dev/null || true
  STORAGE_FILES_COUNT="$(find "$STORAGE_DIR" -type f | wc -l)"
  echo "✓ Directorio storage verificado ($STORAGE_FILES_COUNT archivos comprobados)."
else
  echo "AVISO: No se encontró artefacto 'storage.tgz' en este paquete."
fi

DATABASE_DUMP="${EXTRACT_DIR}/database.dump"
if [[ ! -f "$DATABASE_DUMP" ]]; then
  DATABASE_DUMP="$(find "$EXTRACT_DIR" -maxdepth 1 -name '*.dump' -o -name '*.sql' | head -n 1 || true)"
fi

if [[ -z "$DATABASE_DUMP" || ! -f "$DATABASE_DUMP" ]]; then
  echo "ERROR CRÍTICO: No se encontró archivo database.dump en el paquete extraído."
  exit 1
fi

if [[ "$SKIP_DB_RESTORE" == "true" ]]; then
  echo ""
  echo "======================================================================="
  echo " RESULTADO DEL DRILL: VALIDACIÓN DE ARCHIVOS COMPLETADA"
  echo "======================================================================="
  echo "1. Cifrado age descifrado con clave privada offline exitosamente."
  echo "2. Integridad SHA-256 comprobada para paquete cifrado y contenido original."
  echo "3. Paquete de Storage verificado ($STORAGE_FILES_COUNT objetos)."
  echo "4. Catálogo del dump verificado."
  echo "5. RESTAURACIÓN DE BASE DE DATOS OMITIDA POR EL USUARIO (--skip-db-restore)."
  exit 0
fi

# PASO 6: Comprobación técnica objetiva de aislamiento del destino antes de cualquier acción destructiva
echo "[PASO 6/8] Ejecutando comprobación técnica objetiva de aislamiento en ${DB_HOST}:${DB_PORT}/${DB_NAME}..."
export PGPASSWORD="${PGPASSWORD:-}"

PROBE_OUTPUT=""
set +e
PROBE_OUTPUT="$(psql -v ON_ERROR_STOP=1 -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t -A -c \
  "SELECT current_database(), (current_database() ~* '(test|isolated|staging|drill|sandbox|pruebas)'), coalesce(inet_server_addr()::text, 'local'), (SELECT count(*) FROM pg_database WHERE datname ~* '(odontocloud|edunexus|escolaria|production|prod|clientes|live)'), (SELECT count(*) FROM pg_database WHERE datname NOT IN ('postgres', 'template0', 'template1', current_database()));" 2>&1)"
PROBE_STATUS=$?
set -e

if [[ $PROBE_STATUS -ne 0 ]]; then
  echo "ERROR CRÍTICO DE CONEXIÓN: No se pudo contactar el destino de pruebas especificado."
  echo "Detalle del error: $PROBE_OUTPUT"
  exit 1
fi

PROBE_DB="$(echo "$PROBE_OUTPUT" | cut -d'|' -f1 | tr -d '[:space:]')"
PROBE_IS_ISOLATED="$(echo "$PROBE_OUTPUT" | cut -d'|' -f2 | tr -d '[:space:]')"
PROBE_ADDR="$(echo "$PROBE_OUTPUT" | cut -d'|' -f3 | tr -d '[:space:]')"
PROBE_PROD_DBS="$(echo "$PROBE_OUTPUT" | cut -d'|' -f4 | tr -d '[:space:]')"
PROBE_EXTRA_DBS="$(echo "$PROBE_OUTPUT" | cut -d'|' -f5 | tr -d '[:space:]')"

if [[ "$PROBE_DB" != "$DB_NAME" ]]; then
  echo "ERROR CRÍTICO: La base de datos conectada ($PROBE_DB) no coincide con --db-name ($DB_NAME)."
  exit 1
fi

if [[ "$PROBE_IS_ISOLATED" != "t" ]]; then
  echo "ERROR CRÍTICO: La base de datos '$PROBE_DB' no superó el filtro técnico de aislamiento."
  echo "Abortando sin ejecutar ninguna modificación ni --clean."
  exit 1
fi

if [[ "$PROBE_ADDR" == "150.136.210.37" ]]; then
  echo "ERROR CRÍTICO FATAL: La conexión resolvió a la dirección IP del VPS de producción ($PROBE_ADDR)."
  echo "Abortando de inmediato."
  exit 1
fi

if [[ "$PROBE_PROD_DBS" -gt 0 ]]; then
  echo "ERROR CRÍTICO FATAL: El clúster PostgreSQL contiene $PROBE_PROD_DBS base(s) de datos productivas o de otros sistemas (OdontoCloud, Edunexus, Escolaria, etc.)."
  echo "El entorno es un clúster compartido. PROHIBIDO ejecutar la restauración destructiva en clústeres compartidos con producción."
  echo "Abortando sin ejecutar ninguna modificación ni --clean."
  exit 1
fi

if [[ "$PROBE_EXTRA_DBS" -gt 0 ]]; then
  echo "ERROR CRÍTICO FATAL: El clúster PostgreSQL contiene $PROBE_EXTRA_DBS base(s) de datos adicionales de usuario además de la de ensayo y las del sistema."
  echo "No se garantiza aislamiento absoluto. La restauración destructiva exige una instancia PostgreSQL desechable dedicada,"
  echo "creada e identificada expresamente para la prueba, sin bases de datos adicionales."
  echo "Abortando sin ejecutar ninguna modificación ni --clean."
  exit 1
fi

echo "✓ Destino validado técnicamente: Instancia desechable aislada ($PROBE_DB en $PROBE_ADDR, 0 bases productivas, 0 bases externas)."

# PASO 7: Verificación y restauración estricta de roles con ON_ERROR_STOP
if [[ -f "${EXTRACT_DIR}/roles.sql" ]]; then
  echo "[PASO 7/8] Aplicando roles en instancia desechable con ON_ERROR_STOP=1..."
  echo "  ADVERTENCIA DE SEGURIDAD: roles.sql modifica roles globales del clúster PostgreSQL (pg_roles),"
  echo "  afectando a toda la instancia. Esto confirma por qué el drill exige una instancia desechable dedicada."
  set +e
  psql -v ON_ERROR_STOP=1 -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
    -f "${EXTRACT_DIR}/roles.sql" > "${DEST_DIR}/roles_restore.log" 2>&1
  ROLES_EXIT=$?
  set -e

  if [[ $ROLES_EXIT -ne 0 ]]; then
    echo "ERROR CRÍTICO: Falló la aplicación de roles.sql (código $ROLES_EXIT)."
    echo "Últimas líneas del registro de error (${DEST_DIR}/roles_restore.log):"
    tail -n 25 "${DEST_DIR}/roles_restore.log" || true
    exit $ROLES_EXIT
  fi
  echo "✓ Roles globales del clúster restaurados y validados con éxito (código 0)."
else
  echo "[PASO 7/8] roles.sql no presente en el paquete. Continuando con dump..."
fi

# PASO 8: Restauración estricta con pg_restore --clean y validación exhaustiva
echo "[PASO 8/8] Inspeccionando catálogo del dump con pg_restore --list..."
pg_restore --list "$DATABASE_DUMP" > "${DEST_DIR}/dump_catalog.txt"
CATALOG_ITEMS="$(wc -l < "${DEST_DIR}/dump_catalog.txt")"
echo "✓ Dump PostgreSQL válido en formato binario ($CATALOG_ITEMS elementos en el catálogo)."

echo "Ejecutando pg_restore --clean --exit-on-error en base aislada verificada ($DB_NAME)..."
set +e
pg_restore --clean --if-exists --no-owner --exit-on-error \
  -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
  "$DATABASE_DUMP" > "${DEST_DIR}/pg_restore.log" 2>&1
RESTORE_EXIT=$?
set -e

if [[ $RESTORE_EXIT -ne 0 ]]; then
  echo "ERROR CRÍTICO: pg_restore falló con código de error $RESTORE_EXIT."
  echo "Últimas líneas del registro de error (${DEST_DIR}/pg_restore.log):"
  tail -n 25 "${DEST_DIR}/pg_restore.log" || true
  exit $RESTORE_EXIT
fi
echo "✓ pg_restore completado exitosamente en base aislada (código 0 exacto)."

# Verificación técnica post-restauración distinguiendo roles globales de privilegios GRANT por tabla
echo "Ejecutando auditoría técnica post-restauración en $DB_NAME..."
VERIFY_METRICS="$(psql -v ON_ERROR_STOP=1 -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t -A -c "
  SELECT
    (SELECT count(*) FROM pg_roles WHERE rolname IN ('authenticated', 'anon', 'service_role')) || '|' ||
    (SELECT count(*) FROM information_schema.table_privileges WHERE grantee IN ('authenticated', 'anon', 'service_role') AND table_schema = 'public') || '|' ||
    (SELECT count(*) FROM information_schema.tables WHERE table_schema = 'public') || '|' ||
    (SELECT count(*) FROM information_schema.table_constraints WHERE constraint_type = 'FOREIGN KEY') || '|' ||
    (SELECT count(*) FROM information_schema.routines WHERE routine_schema = 'public');
")"

ROLES_FOUND="$(echo "$VERIFY_METRICS" | cut -d'|' -f1)"
GRANTS_FOUND="$(echo "$VERIFY_METRICS" | cut -d'|' -f2)"
TABLES_FOUND="$(echo "$VERIFY_METRICS" | cut -d'|' -f3)"
FK_FOUND="$(echo "$VERIFY_METRICS" | cut -d'|' -f4)"
ROUTINES_FOUND="$(echo "$VERIFY_METRICS" | cut -d'|' -f5)"

echo "✓ Roles globales del clúster validados (pg_roles):                 $ROLES_FOUND"
echo "✓ Privilegios GRANT por tabla validados (table_privileges):        $GRANTS_FOUND"
echo "✓ Tablas restauradas en esquema public:                            $TABLES_FOUND"
echo "✓ Relaciones e integridad referencial (FK):                         $FK_FOUND"
echo "✓ Funciones y rutinas en esquema public:                           $ROUTINES_FOUND"
echo "✓ Objetos de Supabase Storage verificados:                         $STORAGE_FILES_COUNT"

if [[ "$TABLES_FOUND" -eq 0 ]]; then
  echo "ERROR CRÍTICO: No se detectaron tablas restauradas en el esquema public."
  exit 1
fi

echo ""
echo "======================================================================="
echo " DRILL DE RESTAURACIÓN CONCLUIDO CON ÉXITO ABSOLUTO"
echo "======================================================================="
echo "1. Cifrado age descifrado con clave privada offline y hashes verificados."
echo "2. Paquete de Storage verificado e indexado ($STORAGE_FILES_COUNT archivos)."
echo "3. Roles globales validados con ON_ERROR_STOP=1 (código 0) en instancia desechable."
echo "4. Privilegios GRANT por tabla auditados en information_schema.table_privileges."
echo "5. Aislamiento técnico de clúster comprobado (0 bases ajenas) antes de cualquier orden --clean."
echo "6. Base de datos restaurada y comprobada íntegramente en $DB_NAME."
exit 0
