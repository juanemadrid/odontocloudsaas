#!/usr/bin/env bash
# ==============================================================================
# ODONTOCLOUD — RESPALDO EXTERNO CIFRADO ASIMÉTRICO (AGE) + INMUTABILIDAD STRICT
# ==============================================================================
# Este script es COMPLEMENTARIO y NO modifica ni interrumpe el respaldo local diario.
# Utiliza criptografía moderna de clave pública 'age' (RFC / https://age-encryption.org).
#
# PRINCIPIOS DE SEGURIDAD CRIPTOGRÁFICA Y PROTECCIÓN CONTRA SOBRESCRITURA:
#   1. El servidor (VPS) SOLO posee la CLAVE PÚBLICA (age1...).
#   2. La CLAVE PRIVADA (AGE-SECRET-KEY-1...) NUNCA reside en el VPS.
#      Si el VPS llegase a ser vulnerado, el atacante NO PUEDE descifrar
#      ningún respaldo anterior ni actual almacenado en el servidor o en la nube.
#   3. GESTIÓN DE DÍAS PENDIENTES (SIN OMISIÓN ANTE CAÍDAS DE RED):
#      - No procesa únicamente el último archivo: busca todos los respaldos locales
#        odontocloud-*.tgz que no hayan sido transmitidos a Cloudflare R2 todavía.
#   4. PROTECCIÓN CONTRA CIFRADOS ALEATORIZADOS DE AGE Y MANIFIESTOS INCOMPATIBLES:
#      - 'age' genera cifrados no deterministas (nonces y claves efímeras únicas por ejecución).
#      - Dos ejecuciones de age sobre el mismo archivo producen idéntico tamaño pero distinto SHA-256.
#      - Se prohíbe taxativamente reparar un manifiesto ausente re-cifrando el archivo si no se demuestra
#        correspondencia criptográfica estricta con el objeto remoto existente.
#      - Los artefactos cifrados se conservan en un spool local persistente (.staging_r2) para reintentos.
#      - Si un .age remoto existe sin manifiesto y no coincide byte a byte y por SHA-256 con el artefacto
#        en staging comprobado, se genera alerta crítica y se deja como INCOMPLETO.
#   5. VALIDACIÓN EXHAUSTIVA DE INTEGRIDAD (OBJETO, METADATOS Y HASH REAL):
#      - No basta comprobar que los archivos existan ni que tengan tamaño positivo.
#      - Se valida que las respuestas de rclone sean JSON no vacíos y válidos.
#      - Se compara obligatoriamente el SHA-256 real calculado del objeto remoto frente al hash declarado.
#   6. MANEJO ESTRICTO DE ESTADO DE SALIDA:
#      - Si queda cualquier respaldo incompleto, corrupto o no sincronizado, el script emite una alerta
#        identificable [R2_SYNC_INCOMPLETE] y finaliza obligatoriamente con código de salida distinto de cero.
#   7. CERO PRIVILEGIOS DESTRUCTIVOS:
#      - El script no contiene 'delete', 'rm' hacia la nube ni órdenes de purga.
#      - La retención es gobernada por Bucket Lock en Cloudflare R2.
# ==============================================================================

set -euo pipefail

BACKUP_LOCAL_DIR="${BACKUP_LOCAL_DIR:-/data/backups/odontocloud-daily}"
CONFIG_ENV_FILE="${CONFIG_ENV_FILE:-/etc/odontocloud/r2-backup.env}"
LOG_FILE="${R2_LOG_FILE:-/var/log/odontocloud-r2-backup.log}"

log() {
  printf '[%s] [AGE-R2-BACKUP] %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*" | tee -a "$LOG_FILE" 2>/dev/null || printf '[%s] [AGE-R2-BACKUP] %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*"
}

log "Iniciando proceso secundario de sincronización a Cloudflare R2 (cifrado age)..."

# 1. Cargar variables si existe archivo de configuración
if [[ -f "$CONFIG_ENV_FILE" ]]; then
  # shellcheck source=/dev/null
  source "$CONFIG_ENV_FILE"
fi

BACKUP_LOCAL_DIR="${BACKUP_LOCAL_DIR:-/data/backups/odontocloud-daily}"
AGE_PUBKEY="${AGE_RECIPIENT_PUBKEY:-}"
R2_BUCKET="${R2_BUCKET_NAME:-odontocloud-backups-colombia}"
RCLONE_REMOTE="${RCLONE_REMOTE_NAME:-r2-odontocloud}"
STAGING_SPOOL_DIR="${R2_STAGING_DIR:-${BACKUP_LOCAL_DIR}/.staging_r2}"

mkdir -p "$STAGING_SPOOL_DIR"

# 2. Validación de dependencias requeridas en el host
if ! command -v rclone >/dev/null 2>&1; then
  log "ERROR CRÍTICO: 'rclone' no está instalado en el sistema."
  exit 2
fi

if ! command -v age >/dev/null 2>&1; then
  log "ERROR CRÍTICO: 'age' no está instalado en el sistema."
  exit 2
fi

if ! command -v jq >/dev/null 2>&1; then
  log "ERROR CRÍTICO: 'jq' no está instalado en el sistema para parseo JSON estricto."
  exit 2
fi

# 3. Validación de clave pública
if [[ -z "$AGE_PUBKEY" ]]; then
  if [[ -f "/etc/odontocloud/backup_recipient.pub" ]]; then
    AGE_PUBKEY="$(cat /etc/odontocloud/backup_recipient.pub | tr -d '[:space:]')"
  fi
fi

if [[ -z "$AGE_PUBKEY" || ! "$AGE_PUBKEY" =~ ^age1[a-z0-9]+$ ]]; then
  log "ERROR CRÍTICO: No se proporcionó una clave pública 'age' válida (debe iniciar con 'age1...')."
  log "Instrucción: Generar par de claves FUERA DEL SERVIDOR con: age-keygen -o odontocloud_offline.key"
  log "Colocar únicamente la clave pública en: /etc/odontocloud/backup_recipient.pub"
  exit 1
fi

# 4. Comprobar conectividad básica y autenticación con Cloudflare R2
log "Verificando acceso al bucket remoto ${RCLONE_REMOTE}:${R2_BUCKET}..."
REMOTE_PROBE_OUTPUT=""
REMOTE_PROBE_STATUS=0
REMOTE_PROBE_OUTPUT="$(rclone lsd "${RCLONE_REMOTE}:${R2_BUCKET}" 2>&1)" || REMOTE_PROBE_STATUS=$?

if [[ $REMOTE_PROBE_STATUS -ne 0 ]]; then
  log "ERROR CRÍTICO AL CONTACTAR BUCKET R2: $REMOTE_PROBE_OUTPUT"
  log "Abortando sincronización externa. El respaldo local de las 03:15 UTC continúa seguro e intacto."
  exit 3
fi

# 5. Localizar todos los respaldos locales válidos existentes (procesa cola de días pendientes)
mapfile -t LOCAL_BACKUPS < <(find "$BACKUP_LOCAL_DIR" -maxdepth 1 -type f -name 'odontocloud-*.tgz' | sort)

if [[ ${#LOCAL_BACKUPS[@]} -eq 0 ]]; then
  log "ESTADO VERIFICABLE [R2_NO_LOCAL_BACKUPS]: Cero archivos de respaldo (*.tgz) encontrados en $BACKUP_LOCAL_DIR. Nada que sincronizar."
  exit 2
fi

log "Se detectaron ${#LOCAL_BACKUPS[@]} respaldos locales. Verificando estado en R2..."

PROCESSED_COUNT=0
UPLOADED_COUNT=0
COMPLETED_PARTIAL_COUNT=0
INCOMPLETE_COUNT=0

for LATEST_BACKUP in "${LOCAL_BACKUPS[@]}"; do
  PROCESSED_COUNT=$((PROCESSED_COUNT + 1))
  BACKUP_FILENAME="$(basename "$LATEST_BACKUP")"
  ENCRYPTED_FILENAME="${BACKUP_FILENAME}.age"
  MANIFEST_FILENAME="${ENCRYPTED_FILENAME}.manifest.json"
  LATEST_SHA_FILE="${LATEST_BACKUP}.sha256"
  STAGED_AGE_FILE="${STAGING_SPOOL_DIR}/${ENCRYPTED_FILENAME}"
  STAGED_MANIFEST_FILE="${STAGING_SPOOL_DIR}/${MANIFEST_FILENAME}"

  # Verificar existencia del sha256 local
  if [[ ! -f "$LATEST_SHA_FILE" ]]; then
    log "ADVERTENCIA: Saltando $BACKUP_FILENAME porque no tiene archivo .sha256 asociado."
    INCOMPLETE_COUNT=$((INCOMPLETE_COUNT + 1))
    continue
  fi

  # Validar integridad del archivo local antes de cualquier operación
  (cd "$BACKUP_LOCAL_DIR" && sha256sum -c "$LATEST_SHA_FILE") >/dev/null 2>&1 || {
    log "ERROR CRÍTICO: El checksum SHA256 local de $BACKUP_FILENAME no coincide. Omitiendo este archivo."
    INCOMPLETE_COUNT=$((INCOMPLETE_COUNT + 1))
    continue
  }

  ORIGINAL_SHA256="$(cat "$LATEST_SHA_FILE" | awk '{print $1}')"
  ORIGINAL_BYTES="$(stat -c %s "$LATEST_BACKUP")"

  # Consultar estado remoto de ambos artefactos (.age Y .manifest.json)
  CHECK_STATUS=0
  CHECK_OUTPUT="$(rclone lsjson "${RCLONE_REMOTE}:${R2_BUCKET}" \
    --include "${ENCRYPTED_FILENAME}" \
    --include "${MANIFEST_FILENAME}" 2>&1)" || CHECK_STATUS=$?

  if [[ $CHECK_STATUS -ne 0 ]]; then
    log "ERROR AL CONSULTAR OBJETOS REMOTOS EN R2: $CHECK_OUTPUT. Abortando por seguridad."
    exit 4
  fi

  # Validar que rclone devuelva un JSON array válido y no vacío
  if [[ -z "${CHECK_OUTPUT//[[:space:]]/}" ]] || ! echo "$CHECK_OUTPUT" | jq -e 'type == "array"' >/dev/null 2>&1; then
    log "ERROR CRÍTICO: Respuesta vacía, corrupta o no parseable devuelta por rclone lsjson: '$CHECK_OUTPUT'"
    exit 4
  fi

  # Extraer tamaños numéricos verificando nombre exacto e IsDir == false con jq
  REMOTE_AGE_SIZE="$(echo "$CHECK_OUTPUT" | jq -r --arg fn "$ENCRYPTED_FILENAME" \
    '[.[] | select((.Path == $fn or .Name == $fn) and .IsDir == false and (.Size | type == "number") and .Size > 0)] | .[0].Size // empty')"

  REMOTE_MANIFEST_SIZE="$(echo "$CHECK_OUTPUT" | jq -r --arg fn "$MANIFEST_FILENAME" \
    '[.[] | select((.Path == $fn or .Name == $fn) and .IsDir == false and (.Size | type == "number") and .Size > 0)] | .[0].Size // empty')"

  # ----------------------------------------------------------------------------
  # CASO 1: AMBOS ARTEFACTOS PRESENTES EN R2 (.age Y .manifest.json)
  # Regla de Integridad Estricta:
  #   Nivel 1: Objeto presente y tamaño positivo.
  #   Nivel 2: Metadatos del manifiesto coherentes con el respaldo local.
  #   Nivel 3: Contenido criptográficamente verificado (SHA-256 real calculado == declarado).
  # ----------------------------------------------------------------------------
  if [[ -n "$REMOTE_AGE_SIZE" && -n "$REMOTE_MANIFEST_SIZE" ]]; then
    log "Inspeccionando manifiesto remoto existente para $ENCRYPTED_FILENAME..."
    REMOTE_MAN_RAW="$(rclone cat "${RCLONE_REMOTE}:${R2_BUCKET}/${MANIFEST_FILENAME}" 2>/dev/null || true)"

    if [[ -z "${REMOTE_MAN_RAW//[[:space:]]/}" ]] || ! echo "$REMOTE_MAN_RAW" | jq -e 'type == "object"' >/dev/null 2>&1; then
      log "ALERTA CRÍTICA: Manifiesto remoto $MANIFEST_FILENAME vacío, corrupto o no parseable en R2. Respaldo marcado como INCOMPLETO."
      INCOMPLETE_COUNT=$((INCOMPLETE_COUNT + 1))
      continue
    fi

    REMOTE_MAN_ORIG_SHA="$(echo "$REMOTE_MAN_RAW" | jq -r '.original_sha256 // empty')"
    REMOTE_MAN_ENC_BYTES="$(echo "$REMOTE_MAN_RAW" | jq -r '.encrypted_bytes // empty')"
    REMOTE_MAN_ENC_SHA="$(echo "$REMOTE_MAN_RAW" | jq -r '.encrypted_sha256 // empty')"
    REMOTE_MAN_SOURCE="$(echo "$REMOTE_MAN_RAW" | jq -r '.source_file // empty')"

    if [[ "$REMOTE_MAN_ORIG_SHA" != "$ORIGINAL_SHA256" || \
          "$REMOTE_MAN_SOURCE" != "$BACKUP_FILENAME" || \
          "$REMOTE_MAN_ENC_BYTES" -ne "$REMOTE_AGE_SIZE" || \
          ! "$REMOTE_MAN_ENC_SHA" =~ ^[a-f0-9]{64}$ ]]; then
      log "ALERTA CRÍTICA: Manifiesto remoto inconsistente para $BACKUP_FILENAME (SHA original coincidente: $([ "$REMOTE_MAN_ORIG_SHA" == "$ORIGINAL_SHA256" ] && echo SI || echo NO), bytes coincidentes: $([ "$REMOTE_MAN_ENC_BYTES" -eq "$REMOTE_AGE_SIZE" ] && echo SI || echo NO)). Respaldo marcado como INCOMPLETO."
      INCOMPLETE_COUNT=$((INCOMPLETE_COUNT + 1))
      continue
    fi

    # Comprobación criptográfica del contenido real del objeto remoto
    log "Verificando criptográficamente hash SHA-256 real del objeto remoto $ENCRYPTED_FILENAME..."
    REMOTE_AGE_ACTUAL_SHA="$(rclone cat "${RCLONE_REMOTE}:${R2_BUCKET}/${ENCRYPTED_FILENAME}" 2>/dev/null | sha256sum | awk '{print $1}')"

    if [[ "$REMOTE_AGE_ACTUAL_SHA" != "$REMOTE_MAN_ENC_SHA" ]]; then
      log "ALERTA CRÍTICA DE CORRUPCIÓN [R2_HASH_MISMATCH]: El SHA-256 real del objeto remoto ($REMOTE_AGE_ACTUAL_SHA) NO coincide con el hash declarado en su manifiesto ($REMOTE_MAN_ENC_SHA). Respaldo marcado como INCOMPLETO/CORRUPTO."
      INCOMPLETE_COUNT=$((INCOMPLETE_COUNT + 1))
      continue
    fi

    log "ÉXITO: Respaldo $ENCRYPTED_FILENAME validado al 100% en R2 (Objeto existente: $REMOTE_AGE_SIZE B, Metadatos coherentes, Hash criptográfico verificado: $REMOTE_AGE_ACTUAL_SHA). Omitiendo subida para preservar Bucket Lock."
    rm -f "$STAGED_AGE_FILE" 2>/dev/null || true
    continue
  fi

  # ----------------------------------------------------------------------------
  # CASO 2: CARGA PARCIAL (.age presente pero .manifest.json ausente)
  # Regla: Prohibido regenerar cifrado age aleatorizado y asociarlo ciegamente.
  #        Se debe comprobar correspondencia criptográfica SHA-256 exacta.
  # ----------------------------------------------------------------------------
  if [[ -n "$REMOTE_AGE_SIZE" && -z "$REMOTE_MANIFEST_SIZE" ]]; then
    log "ADVERTENCIA: Se detectó carga parcial en R2 ($ENCRYPTED_FILENAME presente, pero manifiesto ausente)."

    PROVEN_MATCH=false

    # Verificar si conservamos en staging el artefacto cifrado original pendiente
    if [[ -f "$STAGED_AGE_FILE" && -f "$STAGED_MANIFEST_FILE" ]]; then
      LOCAL_STAGED_BYTES="$(stat -c %s "$STAGED_AGE_FILE")"
      if [[ "$LOCAL_STAGED_BYTES" -eq "$REMOTE_AGE_SIZE" ]]; then
        LOCAL_STAGED_ENC_SHA="$(sha256sum "$STAGED_AGE_FILE" | awk '{print $1}')"
        LOCAL_STAGED_MAN_ENC_SHA="$(jq -r '.encrypted_sha256 // empty' "$STAGED_MANIFEST_FILE")"
        LOCAL_STAGED_MAN_ORIG_SHA="$(jq -r '.original_sha256 // empty' "$STAGED_MANIFEST_FILE")"

        if [[ "$LOCAL_STAGED_ENC_SHA" == "$LOCAL_STAGED_MAN_ENC_SHA" && "$LOCAL_STAGED_MAN_ORIG_SHA" == "$ORIGINAL_SHA256" ]]; then
          log "Comprobando hash SHA-256 del objeto remoto existente en R2..."
          REMOTE_CALCULATED_SHA="$(rclone cat "${RCLONE_REMOTE}:${R2_BUCKET}/${ENCRYPTED_FILENAME}" 2>/dev/null | sha256sum | awk '{print $1}')"

          if [[ "$REMOTE_CALCULATED_SHA" == "$LOCAL_STAGED_ENC_SHA" ]]; then
            log "Correspondencia criptográfica DEMOSTRADA: Hash remoto ($REMOTE_CALCULATED_SHA) coincide con artefacto en staging."
            PROVEN_MATCH=true
          else
            log "ALERTA CRÍTICA: Discrepancia SHA-256 entre objeto remoto ($REMOTE_CALCULATED_SHA) y staging ($LOCAL_STAGED_ENC_SHA)."
          fi
        fi
      fi
    fi

    if [[ "$PROVEN_MATCH" == "true" ]]; then
      log "Completando respaldo: Subiendo manifiesto verificado $MANIFEST_FILENAME a R2..."
      rclone copyto "$STAGED_MANIFEST_FILE" "${RCLONE_REMOTE}:${R2_BUCKET}/${MANIFEST_FILENAME}" --immutable --checksum

      # 1. Comprobación de tamaño post-subida
      POST_CHECK="$(rclone lsjson "${RCLONE_REMOTE}:${R2_BUCKET}" --include "${MANIFEST_FILENAME}" 2>/dev/null || echo "[]")"
      POST_MANIFEST_SIZE="$(echo "$POST_CHECK" | jq -r --arg fn "$MANIFEST_FILENAME" \
        '[.[] | select((.Path == $fn or .Name == $fn) and .IsDir == false)] | .[0].Size // empty')"
      EXPECTED_MAN_BYTES="$(stat -c %s "$STAGED_MANIFEST_FILE")"

      if [[ "$POST_MANIFEST_SIZE" != "$EXPECTED_MAN_BYTES" ]]; then
        log "ERROR CRÍTICO POST-SUBIDA [R2_PARTIAL_MANIFEST_SIZE_MISMATCH]: Discrepancia de tamaño del manifiesto subido (esperado: $EXPECTED_MAN_BYTES B, remoto: $POST_MANIFEST_SIZE B)."
        exit 5
      fi

      # 2. Comprobación de integridad criptográfica SHA-256 del manifiesto remoto
      log "Verificando criptográficamente hash SHA-256 del manifiesto remoto recién subido ($MANIFEST_FILENAME)..."
      LOCAL_STAGED_MAN_RAW_SHA="$(sha256sum "$STAGED_MANIFEST_FILE" | awk '{print $1}')"
      REMOTE_UPLOADED_MAN_SHA="$(rclone cat "${RCLONE_REMOTE}:${R2_BUCKET}/${MANIFEST_FILENAME}" 2>/dev/null | sha256sum | awk '{print $1}')"

      REMOTE_UPLOADED_MAN_RAW="$(rclone cat "${RCLONE_REMOTE}:${R2_BUCKET}/${MANIFEST_FILENAME}" 2>/dev/null || true)"

      if [[ -z "${REMOTE_UPLOADED_MAN_RAW//[[:space:]]/}" ]] || ! echo "$REMOTE_UPLOADED_MAN_RAW" | jq -e 'type == "object"' >/dev/null 2>&1; then
        log "ALERTA CRÍTICA DE CORRUPCIÓN [R2_PARTIAL_MANIFEST_CORRUPTION]: Manifiesto remoto subido no es un JSON válido o está vacío."
        exit 5
      fi

      REMOTE_UPLOADED_MAN_ENC_SHA="$(echo "$REMOTE_UPLOADED_MAN_RAW" | jq -r '.encrypted_sha256 // empty')"
      REMOTE_UPLOADED_MAN_ORIG_SHA="$(echo "$REMOTE_UPLOADED_MAN_RAW" | jq -r '.original_sha256 // empty')"
      REMOTE_UPLOADED_MAN_ENC_BYTES="$(echo "$REMOTE_UPLOADED_MAN_RAW" | jq -r '.encrypted_bytes // empty')"

      if [[ "$REMOTE_UPLOADED_MAN_SHA" != "$LOCAL_STAGED_MAN_RAW_SHA" ]]; then
        log "ALERTA CRÍTICA DE CORRUPCIÓN [R2_PARTIAL_MANIFEST_CORRUPTION]: El SHA-256 real del manifiesto remoto ($REMOTE_UPLOADED_MAN_SHA) NO coincide con el manifiesto local en staging ($LOCAL_STAGED_MAN_RAW_SHA)."
        exit 5
      fi

      # 3. Comprobar que encrypted_sha256 en el manifiesto remoto coincide con el .age remoto ya verificado
      if [[ "$REMOTE_UPLOADED_MAN_ENC_SHA" != "$REMOTE_CALCULATED_SHA" || \
            "$REMOTE_UPLOADED_MAN_ORIG_SHA" != "$ORIGINAL_SHA256" || \
            "$REMOTE_UPLOADED_MAN_ENC_BYTES" -ne "$REMOTE_AGE_SIZE" ]]; then
        log "ALERTA CRÍTICA DE CORRUPCIÓN [R2_PARTIAL_MANIFEST_MISMATCH]: Los campos del manifiesto remoto no corresponden al .age verificado en R2."
        exit 5
      fi

      log "ÉXITO: Respaldo parcial completado y verificado criptográficamente al 100% en R2 ($MANIFEST_FILENAME comprobado contra $ENCRYPTED_FILENAME)."
      COMPLETED_PARTIAL_COUNT=$((COMPLETED_PARTIAL_COUNT + 1))
      rm -f "$STAGED_AGE_FILE" 2>/dev/null || true
    else
      log "ALERTA CRÍTICA DE SEGURIDAD [R2_PARTIAL_UNPROVEN]: El objeto remoto $ENCRYPTED_FILENAME no cuenta con manifiesto y NO se puede demostrar correspondencia criptográfica."
      log "REGLA TÉCNICA: Se prohíbe re-cifrar con age para asociar un manifiesto con hash incompatible. El respaldo permanece MARCADO COMO INCOMPLETO."
      INCOMPLETE_COUNT=$((INCOMPLETE_COUNT + 1))
    fi
    continue
  fi

  # ----------------------------------------------------------------------------
  # CASO 3: NUEVO RESPALDO COMPLETO (Ni .age ni .manifest.json presentes en R2)
  # ----------------------------------------------------------------------------
  NEED_NEW_ENCRYPT=true

  if [[ -f "$STAGED_AGE_FILE" && -f "$STAGED_MANIFEST_FILE" ]]; then
    STAGED_MAN_ORIG_SHA="$(jq -r '.original_sha256 // empty' "$STAGED_MANIFEST_FILE")"
    if [[ "$STAGED_MAN_ORIG_SHA" == "$ORIGINAL_SHA256" ]]; then
      STAGED_ENC_SHA="$(sha256sum "$STAGED_AGE_FILE" | awk '{print $1}')"
      STAGED_MAN_ENC_SHA="$(jq -r '.encrypted_sha256 // empty' "$STAGED_MANIFEST_FILE")"
      if [[ "$STAGED_ENC_SHA" == "$STAGED_MAN_ENC_SHA" ]]; then
        log "Reutilizando artefacto cifrado válido preexistente en staging ($STAGED_AGE_FILE)..."
        NEED_NEW_ENCRYPT=false
      fi
    fi
  fi

  if [[ "$NEED_NEW_ENCRYPT" == "true" ]]; then
    log "Generando artefacto cifrado asimétrico con 'age' para $BACKUP_FILENAME en staging..."
    age -r "$AGE_PUBKEY" -o "$STAGED_AGE_FILE" "$LATEST_BACKUP"

    ENCRYPTED_SHA256="$(sha256sum "$STAGED_AGE_FILE" | awk '{print $1}')"
    ENCRYPTED_BYTES="$(stat -c %s "$STAGED_AGE_FILE")"

    cat <<EOF > "$STAGED_MANIFEST_FILE"
{
  "system": "OdontoCloud",
  "source_file": "${BACKUP_FILENAME}",
  "original_bytes": ${ORIGINAL_BYTES},
  "original_sha256": "${ORIGINAL_SHA256}",
  "encrypted_file": "${ENCRYPTED_FILENAME}",
  "encrypted_bytes": ${ENCRYPTED_BYTES},
  "encrypted_sha256": "${ENCRYPTED_SHA256}",
  "cipher": "age-x25519-chacha20poly1305",
  "recipient_pubkey": "${AGE_PUBKEY}",
  "created_at_utc": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
EOF
  fi

  ENCRYPTED_SHA256="$(sha256sum "$STAGED_AGE_FILE" | awk '{print $1}')"
  ENCRYPTED_BYTES="$(stat -c %s "$STAGED_AGE_FILE")"
  MANIFEST_BYTES="$(stat -c %s "$STAGED_MANIFEST_FILE")"

  log "Subiendo paquete cifrado $ENCRYPTED_FILENAME con --immutable a Cloudflare R2..."
  rclone copyto "$STAGED_AGE_FILE" "${RCLONE_REMOTE}:${R2_BUCKET}/${ENCRYPTED_FILENAME}" --immutable --checksum

  log "Subiendo manifiesto de verificación $MANIFEST_FILENAME con --immutable a Cloudflare R2..."
  rclone copyto "$STAGED_MANIFEST_FILE" "${RCLONE_REMOTE}:${R2_BUCKET}/${MANIFEST_FILENAME}" --immutable --checksum

  # Verificación estricta post-subida de AMBOS archivos mediante jq
  POST_CHECK="$(rclone lsjson "${RCLONE_REMOTE}:${R2_BUCKET}" \
    --include "${ENCRYPTED_FILENAME}" \
    --include "${MANIFEST_FILENAME}" 2>/dev/null || echo "[]")"

  if [[ -z "${POST_CHECK//[[:space:]]/}" ]] || ! echo "$POST_CHECK" | jq -e 'type == "array"' >/dev/null 2>&1; then
    log "ERROR: Salida corrupta o inválida en verificación post-subida."
    exit 5
  fi

  POST_AGE_SIZE="$(echo "$POST_CHECK" | jq -r --arg fn "$ENCRYPTED_FILENAME" \
    '[.[] | select((.Path == $fn or .Name == $fn) and .IsDir == false)] | .[0].Size // empty')"

  POST_MANIFEST_SIZE="$(echo "$POST_CHECK" | jq -r --arg fn "$MANIFEST_FILENAME" \
    '[.[] | select((.Path == $fn or .Name == $fn) and .IsDir == false)] | .[0].Size // empty')"

  # 1. Comprobación de tamaños post-subida
  if [[ "$POST_AGE_SIZE" != "$ENCRYPTED_BYTES" || "$POST_MANIFEST_SIZE" != "$MANIFEST_BYTES" ]]; then
    log "ERROR CRÍTICO POST-SUBIDA [R2_SIZE_MISMATCH]: Discrepancia de tamaño (age esperado: $ENCRYPTED_BYTES B, remoto: $POST_AGE_SIZE B; manifest esperado: $MANIFEST_BYTES B, remoto: $POST_MANIFEST_SIZE B)."
    exit 5
  fi

  # 2. Comprobación de integridad y contenido del manifiesto remoto
  log "Verificando contenido del manifiesto remoto $MANIFEST_FILENAME en R2..."
  POST_MAN_ACTUAL_SHA="$(rclone cat "${RCLONE_REMOTE}:${R2_BUCKET}/${MANIFEST_FILENAME}" 2>/dev/null | sha256sum | awk '{print $1}')"
  LOCAL_MAN_RAW_SHA="$(sha256sum "$STAGED_MANIFEST_FILE" | awk '{print $1}')"

  if [[ "$POST_MAN_ACTUAL_SHA" != "$LOCAL_MAN_RAW_SHA" ]]; then
    log "ALERTA CRÍTICA DE CORRUPCIÓN POST-SUBIDA [R2_POST_UPLOAD_CORRUPTION]: El SHA-256 real del manifiesto remoto ($POST_MAN_ACTUAL_SHA) NO coincide con el manifiesto local ($LOCAL_MAN_RAW_SHA)."
    exit 5
  fi

  POST_MAN_RAW="$(rclone cat "${RCLONE_REMOTE}:${R2_BUCKET}/${MANIFEST_FILENAME}" 2>/dev/null || true)"

  if [[ -z "${POST_MAN_RAW//[[:space:]]/}" ]] || ! echo "$POST_MAN_RAW" | jq -e 'type == "object"' >/dev/null 2>&1; then
    log "ERROR CRÍTICO POST-SUBIDA [R2_MANIFEST_CORRUPT]: Manifiesto remoto subido no es un JSON válido o está vacío."
    exit 5
  fi

  POST_REMOTE_ENC_SHA="$(echo "$POST_MAN_RAW" | jq -r '.encrypted_sha256 // empty')"
  POST_REMOTE_ORIG_SHA="$(echo "$POST_MAN_RAW" | jq -r '.original_sha256 // empty')"
  POST_REMOTE_ENC_BYTES="$(echo "$POST_MAN_RAW" | jq -r '.encrypted_bytes // empty')"

  if [[ "$POST_REMOTE_ENC_SHA" != "$ENCRYPTED_SHA256" || \
        "$POST_REMOTE_ORIG_SHA" != "$ORIGINAL_SHA256" || \
        "$POST_REMOTE_ENC_BYTES" -ne "$ENCRYPTED_BYTES" ]]; then
    log "ERROR CRÍTICO POST-SUBIDA [R2_MANIFEST_MISMATCH]: El contenido del manifiesto remoto no corresponde exactamente al manifiesto local enviado."
    exit 5
  fi

  # 3. Comprobación criptográfica del contenido real del objeto remoto cifrado
  log "Verificando criptográficamente hash SHA-256 del objeto remoto recién subido ($ENCRYPTED_FILENAME)..."
  POST_AGE_ACTUAL_SHA="$(rclone cat "${RCLONE_REMOTE}:${R2_BUCKET}/${ENCRYPTED_FILENAME}" 2>/dev/null | sha256sum | awk '{print $1}')"

  if [[ -z "$POST_AGE_ACTUAL_SHA" || "$POST_AGE_ACTUAL_SHA" != "$ENCRYPTED_SHA256" ]]; then
    log "ALERTA CRÍTICA DE CORRUPCIÓN POST-SUBIDA [R2_POST_UPLOAD_CORRUPTION]: El SHA-256 real del objeto remoto ($POST_AGE_ACTUAL_SHA) NO coincide con el cifrado local ($ENCRYPTED_SHA256). Fallo de integridad grave."
    exit 5
  fi

  log "ÉXITO TOTAL: Respaldo $ENCRYPTED_FILENAME y su manifiesto subidos y verificados criptográficamente al 100% en R2 (age: $POST_AGE_SIZE B, SHA-256 confirmado: $POST_AGE_ACTUAL_SHA, manifest verificado)."
  UPLOADED_COUNT=$((UPLOADED_COUNT + 1))
  rm -f "$STAGED_AGE_FILE" 2>/dev/null || true
done

log "Proceso finalizado. Total analizados: $PROCESSED_COUNT, Nuevos respaldos sincronizados: $UPLOADED_COUNT, Incompletos subsanados: $COMPLETED_PARTIAL_COUNT, Incompletos pendientes: $INCOMPLETE_COUNT."

# Si queda cualquier respaldo incompleto, corrupto o fallido, finalizar con código de error
if [[ "$INCOMPLETE_COUNT" -gt 0 ]]; then
  log "ALERTA CRÍTICA IDENTIFICABLE [R2_SYNC_INCOMPLETE]: Se detectaron $INCOMPLETE_COUNT respaldos con fallos de integridad, incompletitud o no demostrables. Finalizando con error."
  exit 6
fi

exit 0
