# POLÍTICA DE RETENCIÓN E INMUTABILIDAD EN CLOUDFLARE R2
**Sistema:** OdontoCloud SaaS  
**Principio:** Arquitectura de solo anexado (`Append-Only`) en el cliente y protección criptográfica contra eliminación mediante `Bucket Lock (Object Retention)` en Cloudflare R2  
**Administración:** Reglas de ciclo de vida nativas y retención inmutable en la nube

---

## 1. DISTINCIÓN CRÍTICA: RESPALDOS DE INFRAESTRUCTURA VS. CONSERVACIÓN DE HISTORIAS CLÍNICAS

Es indispensable delimitar el alcance de la retención de 90 días en Cloudflare R2 frente a las obligaciones normativas del sector salud en Colombia:

1. **Retención de Respaldos de Infraestructura (90 Días en Cloudflare R2):**
   - **Objetivo:** Recuperación Operativa y Continuidad del Negocio (Disaster Recovery).
   - **Mecanismo:** Snapshots diarios completos (`database.dump` + `roles.sql` + `storage.tgz`) cifrados asimétricamente con `age`.
   - **Ciclo:** Ventana móvil de 90 días protegida por Bucket Lock para mitigar ransomware y fallos catastróficos del VPS. Pasados los 90 días, la regla de ciclo de vida purga automáticamente el snapshot obsoleto.

2. **Conservación Legal de Historias Clínicas (15 a 20 Años - Normativa Sanitaria):**
   - **Marco Legal:** **Resolución 839 de 2017** del Ministerio de Salud y Protección Social (que modificó la Resolución 1995 de 1999) y Ley Estatutaria 1581 de 2012.
   - **Exigencia:** La historia clínica debe conservarse por un período mínimo de **15 años**: 5 años en el archivo de gestión y 10 años en el archivo central. Para casos de víctimas de violaciones a DDHH o investigaciones, el término se extiende a 20 años.
   - **Garantía en OdontoCloud:** La conservación legal de historias clínicas **reside de forma permanente en la base de datos PostgreSQL** (donde las evoluciones, adendas, consentimientos y fichas tienen inmutabilidad lógica estricta y prohibición absoluta de borrado físico) y en los archivos maestros de cierre anual, **no en la rotación de 90 días de copias operativas de DR**.

---

## 2. POLÍTICA DE OPERACIÓN EN EL CLIENTE (VPS)

El script del servidor `r2_offsite_backup_age.sh`:
- **NUNCA ejecuta órdenes destructivas:** No incluye `delete`, `purge`, `rm` ni banderas de expiración.
- **Sube exclusivamente con `--immutable`:** Rechaza la sobreescritura de cualquier archivo existente.
- **Comprueba la completitud del respaldo:** Exige la existencia tanto del paquete `.age` como de su `.manifest.json` mediante consultas parseadas con `jq`. Si un respaldo está incompleto, sube únicamente los artefactos faltantes sin violar la inmutabilidad.

---

## 3. LIMITACIÓN DE LOS API TOKENS DE CLOUDFLARE R2 Y EXIGENCIA DE BUCKET LOCK

### Limitación Real de la API de Cloudflare R2:
- Los perfiles de API Tokens predefinidos en Cloudflare R2 agrupan permisos en:
  - *Admin-Read & Write*
  - *Object Read & Write*
  - *Object Read Only*
- **Importante:** La plantilla *Object Read & Write* de Cloudflare R2 confiere permisos compatibles con S3 (`PutObject`, `GetObject`, `HeadObject`), pero **también incluye la capacidad técnica de emitir llamadas `DeleteObject`**. No existe en la interfaz de tokens de R2 una casilla nativa para deshabilitar exclusivamente `DeleteObject` sin afectar `PutObject`.
- **Conclusión de seguridad:** Restringir el token a *Object Read & Write* **NO ES SUFICIENTE** por sí solo para garantizar la inmutabilidad si el token llega a ser sustraído del servidor.

### Exigencia Obligatoria: Cloudflare R2 Bucket Lock (Object Retention)
Para neutralizar de raíz cualquier riesgo de borrado (incluso ante un compromiso total del VPS), es **ESTRICTAMENTE OBLIGATORIO** activar **Bucket Lock** en Cloudflare R2:

1. **Configuración en Cloudflare Dashboard:**
   - Navegar a **R2 > Overview > odontocloud-backups-colombia**.
   - Ir a **Settings > Bucket Lock (Object Retention)**.
   - Habilitar Bucket Lock definiendo el período de retención: **90 días**.
2. **Efecto Vinculante:** Durante los 90 días posteriores a la creación de cada archivo, el motor de Cloudflare R2 **bloquea y rechaza a nivel de hardware/almacenamiento** cualquier solicitud de `DeleteObject` o sobreescritura, sin importar qué credencial o API Token la intente ejecutar.

---

## 4. CONFIGURACIÓN DEL CICLO DE VIDA (OBJECT LIFECYCLE)

La purga de respaldos de DR caducados se delega con total autonomía a la infraestructura de Cloudflare:

### Configuración en el panel de Cloudflare R2:
1. Acceder a **Cloudflare Dashboard > R2 > Overview > odontocloud-backups-colombia**.
2. Navegar a **Settings > Object Lifecycle Rules**.
3. Crear regla de expiración programada:
   - **Rule name:** `Retencion-90-Dias-OdontoCloud-DR`
   - **Prefix:** `odontocloud-`
   - **Action:** `Delete objects older than 90 days`
4. Esta regla actúa únicamente cuando el período de Bucket Lock de 90 días ha finalizado, garantizando rotación automática sin comandos remotos en el VPS.

---

## 5. RESUMEN DE RESPONSABILIDADES Y BARRERAS DE SEGURIDAD

| Componente | Nivel | Comportamiento | Garantía |
| :--- | :--- | :--- | :--- |
| **Script VPS** | Cliente | Solo lectura local y subida `copyto --immutable`. | No contiene rutinas de eliminación (`Append-Only`). |
| **API Token R2** | Transporte | Alcance limitado exclusivamente al bucket de respaldos. | No tiene acceso a otros buckets ni a la cuenta global. |
| **Bucket Lock** | Almacenamiento | Retención estricta inmutable por 90 días. | Rechaza llamadas de borrado incluso si el token es vulnerado. |
| **Object Lifecycle** | Proveedor | Expiración automática a nivel Cloudflare tras 90 días. | Purga snapshots de DR caducados sin intervención humana. |
| **Base de Datos** | Aplicación | RLS y tablas clínicas con cero DELETE físico. | Conservación legal permanente (15+ años) de historias clínicas. |
