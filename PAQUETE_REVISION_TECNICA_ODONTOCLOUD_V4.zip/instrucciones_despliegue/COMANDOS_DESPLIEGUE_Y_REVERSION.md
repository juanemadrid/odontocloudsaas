# ODONTOCLOUD — PROCEDIMIENTOS DE DESPLIEGUE Y REVERSIÓN POR FASE (V4)

> [!WARNING]
> **ESTE DOCUMENTO ES DE CARÁCTER INFORMATIVO Y DE PLANIFICACIÓN TÉCNICA.**
> **LOS COMANDOS LISTADOS A CONTINUACIÓN NO ESTÁN AUTORIZADOS PARA SU EJECUCIÓN.**
> **NINGUNA ACCIÓN DEBE REALIZARSE EN PRODUCCIÓN SIN AUTORIZACIÓN EXPRESA PREVIA.**
> **LA RAMA MAIN SE MANTIENE INTACTA Y NO SE REALIZAN DESPLIEGUES AUTOMÁTICOS.**

---

## ESTRUCTURA DEL PAQUETE TÉCNICO V4

Este paquete contiene los 6 componentes requeridos para la revisión técnica independiente, incorporando las soluciones a los tres problemas bloqueantes:

1. `respaldos/r2_offsite_backup_age.sh`:
   - Incorpora spool local persistente (`.staging_r2`) para conservar artefactos cifrados originales ante reintentos.
   - Protege contra el no-determinismo criptográfico de `age` (cifrados con claves efímeras únicas por ejecución).
   - Prohíbe reconstruir manifiestos re-cifrando archivos sin correspondencia criptográfica demostrada.
   - Si se detecta un objeto `.age` en R2 sin manifiesto, verifica su hash SHA-256 en tiempo real mediante `rclone cat ... | sha256sum`. Solo si coincide exactamente con el artefacto en staging se autoriza la subida del manifiesto; de lo contrario, genera alerta crítica y marca el respaldo como INCOMPLETO.
   - Valida exhaustivamente el contenido del manifiesto existente (`jq`) en lugar de limitarse a comprobar tamaños mayores a 0.

2. `respaldos/restore_drill_isolated.sh`:
   - Exige parámetros de conexión explícitos y obligatorios (`--db-host`, `--db-port`, `--db-user`, `--db-name`, `--confirm-isolated-db`), eliminando valores por defecto implícitos (`localhost:5432`).
   - Bloquea hosts productivos (incluyendo la IP `150.136.210.37`) y nombres de base de datos productivos o reservados.
   - Ejecuta una comprobación técnica previa mediante consulta SQL para verificar objetivamente que el destino es un entorno de pruebas autorizado antes de emitir cualquier orden destructiva o ejecutar `pg_restore --clean`.
   - Aplica `roles.sql` con `-v ON_ERROR_STOP=1` y comprueba de forma estricta que el código de salida sea 0.
   - Realiza auditoría técnica post-restauración en catálogo: conteo de roles Supabase, tablas en esquema public, integridad referencial (claves foráneas), rutinas/funciones y extracción de objetos en Supabase Storage.

3. `respaldos/R2_RETENCION_E_INMUTABILIDAD.md`:
   - Manual técnico distinguiendo la retención de 90 días de copias DR frente a la conservación de 15 a 20 años de historias clínicas (**Resolución 839 de 2017** del Ministerio de Salud).
   - Especifica la activación obligatoria de **Bucket Lock (Object Retention)** y reglas de ciclo de vida (`Object Lifecycle`) en Cloudflare R2.

4. `seguridad_rls/20261011_clinical_data_least_privilege.sql`:
   - Migración quirúrgica RLS de mínimo privilegio.
   - Remueve el bypass de superadmin en tablas clínicas (`pacientes`, `evoluciones`, `odontogramas`, `treatment_plans`, `consentimientos`, `documentos_clinicos`, `formulaciones`).
   - Limita la lectura y escritura clínica exclusivamente al personal asistencial (`is_clinical_staff()`) de la misma clínica.
   - Revoca la eliminación física (`DELETE`) en `pacientes` y `formulaciones` para salvaguardar la trazabilidad legal.
   - Restringe la función de Storage `can_access_private_attachment` a personal asistencial autenticado.

5. `seguridad_rls/20261011_rollback_clinical_data_least_privilege.sql`:
   - Reversión 100% simétrica con garantía matemática de igualdad (`Snapshot 0 === Snapshot 1`, 0 diffs en `pg_policies`).
   - Restaura exactamente las políticas originales de `formulaciones` (`formulaciones_select`, `formulaciones_insert`, `formulaciones_update`, `formulaciones_delete`).
   - Restaura todas las políticas `DELETE` clínicas preexistentes (`pacientes_tenant_delete`, `evoluciones_tenant_delete`, `odontogramas_tenant_delete`, etc.).
   - Restablece `can_access_private_attachment` y elimina de forma limpia la función auxiliar `is_clinical_staff()`.

6. `instrucciones_despliegue/COMANDOS_DESPLIEGUE_Y_REVERSION.md`:
   - Este manual operativo de despliegue controlado y reversión inmediata.

---

## FASE A — RESPALDOS EXTERNOS ASIMÉTRICOS (CLOUDFLARE R2)

### 1. Pre-requisitos en Estación Administrativa Segura (Fuera del Servidor):
1. Instalar `age` en la estación local del Oficial de Seguridad.
2. Generar el par de claves criptográficas asimétricas:
   ```bash
   age-keygen -o odontocloud_offline_master.key
   ```
   - La clave privada (`AGE-SECRET-KEY-1...`) permanece resguardada de forma offline en el almacén de claves corporativo.
   - La clave pública (`age1...`) es el único artefacto que se transfiere al VPS.

### 2. Configuración en Cloudflare R2:
1. En el bucket `odontocloud-backups-colombia`, activar **Bucket Lock (Object Retention)** con vigencia de **90 días**.
2. Configurar regla de ciclo de vida (`Object Lifecycle`) para expiración automática tras 90 días.
3. Generar API Token con alcance exclusivo al bucket de respaldos.

### 3. Instalación en el VPS (Servicio 2 - OdontoCloud):
```bash
# A. Instalar binarios requeridos en el host:
apt-get update && apt-get install -y age rclone jq

# B. Depositar exclusivamente la clave pública:
mkdir -p /etc/odontocloud
chmod 700 /etc/odontocloud
echo "age1tuclavepublica..." > /etc/odontocloud/backup_recipient.pub
chmod 400 /etc/odontocloud/backup_recipient.pub

# C. Configurar rclone (remoto 'r2-odontocloud', tipo s3, provider Cloudflare).

# D. Instalar script secundario de respaldo:
cp r2_offsite_backup_age.sh /usr/local/sbin/r2-backup-odontocloud.sh
chmod 700 /usr/local/sbin/r2-backup-odontocloud.sh
chown root:root /usr/local/sbin/r2-backup-odontocloud.sh

# E. Programar cron complementario (04:00 UTC, posterior al respaldo local de 03:15 UTC):
cat << 'EOF' > /etc/cron.d/odontocloud-r2-backup
0 4 * * * root /usr/local/sbin/r2-backup-odontocloud.sh >> /var/log/odontocloud-r2-backup.log 2>&1
EOF
chmod 644 /etc/cron.d/odontocloud-r2-backup
```

### 4. Procedimiento de Reversión (Fase A):
```bash
# Remover el cron secundario y el script complementario:
rm -f /etc/cron.d/odontocloud-r2-backup
rm -f /usr/local/sbin/r2-backup-odontocloud.sh
# El respaldo local nativo a las 03:15 UTC se mantiene completamente intacto y operativo.
```

---

## FASE B — SEGURIDAD RLS Y MÍNIMO PRIVILEGIO CLÍNICO

### 1. Pre-requisitos:
- Ejecutar en ventana de mantenimiento nocturna previamente autorizada.
- Verificar que el contenedor de PostgreSQL de OdontoCloud se encuentre saludable (`healthy`).

### 2. Comandos de Aplicación:
```bash
# Aplicación atómica dentro del contenedor PostgreSQL de OdontoCloud:
docker exec -i supabase-db-ueh7xuehxl9thmhre7fpk4xx psql -U postgres -d postgres -v ON_ERROR_STOP=1 \
  < 20261011_clinical_data_least_privilege.sql
```

### 3. Procedimiento de Reversión Inmediata (Fase B):
Si se requiere revertir el cambio de inmediato:
```bash
# Ejecutar script de reversión quirúrgica simétrica:
docker exec -i supabase-db-ueh7xuehxl9thmhre7fpk4xx psql -U postgres -d postgres -v ON_ERROR_STOP=1 \
  < 20261011_rollback_clinical_data_least_privilege.sql
```
