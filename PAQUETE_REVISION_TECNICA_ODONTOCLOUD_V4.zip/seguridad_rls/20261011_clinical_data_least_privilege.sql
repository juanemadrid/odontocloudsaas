-- ==============================================================================
-- ODONTOCLOUD — MIGRACIÓN QUIRÚRGICA: MÍNIMO PRIVILEGIO CLÍNICO
-- ==============================================================================
-- PRINCIPIOS DE DISEÑO ESTRICTOS:
--   1. NO modifica tablas que no tengan exposición indebida de superadmin.
--   2. NO elimina indiscriminadamente políticas existentes ni toca triggers,
--      inmutabilidad, firmas, adendas (20261003) ni RPCs de odontograma (20261005).
--   3. Corrige EXCLUSIVAMENTE las políticas de acceso general de las tablas
--      clínicas que contenían 'OR public.is_superadmin()'.
--   4. Corrige 'public.can_access_private_attachment()' para:
--      - Eliminar el bypass de superadmin.
--      - Limitar el acceso a personal clínico asistencial de la misma clínica.
--      - Impedir acceso administrativo general a radiografías y archivos de salud.
--   5. Es 100% transaccional y se detiene ante cualquier error (\set ON_ERROR_STOP on).
-- ==============================================================================

\set ON_ERROR_STOP on

BEGIN;

-- ------------------------------------------------------------------------------
-- 1. FUNCIÓN ASISTENCIAL (Distingue personal de salud de administrativo)
-- ------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.is_clinical_staff()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
SET row_security = off
AS $$
  SELECT lower(trim(coalesce(p.role, ''))) IN ('odontologo', 'doctor', 'especialista', 'odontologa')
  FROM public.profiles AS p
  WHERE p.id = auth.uid()
    AND p.activo IS TRUE;
$$;

REVOKE ALL ON FUNCTION public.is_clinical_staff() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_clinical_staff() TO authenticated;


-- ------------------------------------------------------------------------------
-- 2. CORRECCIÓN DE STORAGE: can_access_private_attachment
-- ------------------------------------------------------------------------------
-- Se remueve 'public.is_superadmin()' y se exige rol asistencial de la misma clínica.
CREATE OR REPLACE FUNCTION public.can_access_private_attachment(object_name text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT (
    public.is_active_user()
    AND public.is_clinical_staff()
    AND (
      split_part(object_name, '/', 1) = public.get_user_tenant_id()::text
      OR (
        split_part(object_name, '/', 1) = 'pacientes'
        AND (
          split_part(object_name, '/', 2) = public.get_user_tenant_id()::text
          OR EXISTS (
            SELECT 1
            FROM public.pacientes AS patient
            WHERE patient.id::text = split_part(object_name, '/', 2)
              AND patient.tenant_id::text = public.get_user_tenant_id()::text
          )
        )
      )
    )
  );
$$;

REVOKE ALL ON FUNCTION public.can_access_private_attachment(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_access_private_attachment(text) TO authenticated;


-- ------------------------------------------------------------------------------
-- 3. REMOCIÓN QUIRÚRGICA DEL BYPASS DE SUPERADMIN EN TABLAS CLÍNICAS
-- ------------------------------------------------------------------------------
-- Se sustituyen ÚNICAMENTE las políticas específicas generadas en el loop de
-- '20260801_security_hardening.sql' y '20250802_add_missing_columns.sql' que
-- otorgaban acceso indebido al superadmin:

-- A. TABLA PACIENTES: Demografía para personal de la clínica (excluye superadmin)
DROP POLICY IF EXISTS pacientes_tenant_select ON public.pacientes;
CREATE POLICY pacientes_tenant_select ON public.pacientes
FOR SELECT TO authenticated
USING (public.is_active_user() AND tenant_id::text = public.get_user_tenant_id()::text);

DROP POLICY IF EXISTS pacientes_tenant_insert ON public.pacientes;
CREATE POLICY pacientes_tenant_insert ON public.pacientes
FOR INSERT TO authenticated
WITH CHECK (public.is_active_user() AND tenant_id::text = public.get_user_tenant_id()::text);

DROP POLICY IF EXISTS pacientes_tenant_update ON public.pacientes;
CREATE POLICY pacientes_tenant_update ON public.pacientes
FOR UPDATE TO authenticated
USING (public.is_active_user() AND tenant_id::text = public.get_user_tenant_id()::text)
WITH CHECK (public.is_active_user() AND tenant_id::text = public.get_user_tenant_id()::text);

-- Eliminación física revocada en pacientes: Para preservar integridad clínica e histórico legal
-- (Resolución 839 de 2017), se prohíbe el borrado físico (DELETE) y se exige desactivación lógica (UPDATE).
DROP POLICY IF EXISTS pacientes_tenant_delete ON public.pacientes;


-- B. TABLA EVOLUCIONES: Acceso asistencial estricto (excluye superadmin y recepcionistas)
DROP POLICY IF EXISTS evoluciones_tenant_select ON public.evoluciones;
CREATE POLICY evoluciones_tenant_select ON public.evoluciones
FOR SELECT TO authenticated
USING (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text);

DROP POLICY IF EXISTS evoluciones_tenant_insert ON public.evoluciones;
CREATE POLICY evoluciones_tenant_insert ON public.evoluciones
FOR INSERT TO authenticated
WITH CHECK (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text);

DROP POLICY IF EXISTS evoluciones_tenant_update ON public.evoluciones;
CREATE POLICY evoluciones_tenant_update ON public.evoluciones
FOR UPDATE TO authenticated
USING (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text)
WITH CHECK (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text);

-- Se revoca la política de delete de evoluciones para garantizar inmutabilidad
DROP POLICY IF EXISTS evoluciones_tenant_delete ON public.evoluciones;


-- C. TABLA ODONTOGRAMAS
DROP POLICY IF EXISTS odontogramas_tenant_select ON public.odontogramas;
CREATE POLICY odontogramas_tenant_select ON public.odontogramas
FOR SELECT TO authenticated
USING (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text);

DROP POLICY IF EXISTS odontogramas_tenant_insert ON public.odontogramas;
CREATE POLICY odontogramas_tenant_insert ON public.odontogramas
FOR INSERT TO authenticated
WITH CHECK (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text);

DROP POLICY IF EXISTS odontogramas_tenant_update ON public.odontogramas;
CREATE POLICY odontogramas_tenant_update ON public.odontogramas
FOR UPDATE TO authenticated
USING (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text)
WITH CHECK (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text);

DROP POLICY IF EXISTS odontogramas_tenant_delete ON public.odontogramas;


-- D. TABLA TREATMENT_PLANS
DROP POLICY IF EXISTS treatment_plans_tenant_select ON public.treatment_plans;
CREATE POLICY treatment_plans_tenant_select ON public.treatment_plans
FOR SELECT TO authenticated
USING (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text);

DROP POLICY IF EXISTS treatment_plans_tenant_insert ON public.treatment_plans;
CREATE POLICY treatment_plans_tenant_insert ON public.treatment_plans
FOR INSERT TO authenticated
WITH CHECK (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text);

DROP POLICY IF EXISTS treatment_plans_tenant_update ON public.treatment_plans;
CREATE POLICY treatment_plans_tenant_update ON public.treatment_plans
FOR UPDATE TO authenticated
USING (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text)
WITH CHECK (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text);

DROP POLICY IF EXISTS treatment_plans_tenant_delete ON public.treatment_plans;


-- E. TABLA CONSENTIMIENTOS
DROP POLICY IF EXISTS consentimientos_tenant_select ON public.consentimientos;
CREATE POLICY consentimientos_tenant_select ON public.consentimientos
FOR SELECT TO authenticated
USING (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text);

DROP POLICY IF EXISTS consentimientos_tenant_insert ON public.consentimientos;
CREATE POLICY consentimientos_tenant_insert ON public.consentimientos
FOR INSERT TO authenticated
WITH CHECK (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text);

DROP POLICY IF EXISTS consentimientos_tenant_update ON public.consentimientos;
CREATE POLICY consentimientos_tenant_update ON public.consentimientos
FOR UPDATE TO authenticated
USING (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text)
WITH CHECK (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text);

DROP POLICY IF EXISTS consentimientos_tenant_delete ON public.consentimientos;


-- F. TABLA DOCUMENTOS_CLINICOS (Acceso asistencial estricto si la tabla existe en la instancia)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'documentos_clinicos') THEN
    DROP POLICY IF EXISTS documentos_clinicos_tenant_select ON public.documentos_clinicos;
    CREATE POLICY documentos_clinicos_tenant_select ON public.documentos_clinicos
      FOR SELECT TO authenticated
      USING (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text);

    DROP POLICY IF EXISTS documentos_clinicos_tenant_insert ON public.documentos_clinicos;
    CREATE POLICY documentos_clinicos_tenant_insert ON public.documentos_clinicos
      FOR INSERT TO authenticated
      WITH CHECK (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text);

    DROP POLICY IF EXISTS documentos_clinicos_tenant_update ON public.documentos_clinicos;
    CREATE POLICY documentos_clinicos_tenant_update ON public.documentos_clinicos
      FOR UPDATE TO authenticated
      USING (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text)
      WITH CHECK (public.is_active_user() AND public.is_clinical_staff() AND tenant_id::text = public.get_user_tenant_id()::text);

    DROP POLICY IF EXISTS documentos_clinicos_tenant_delete ON public.documentos_clinicos;
  END IF;
END
$$;


-- G. TABLA FORMULACIONES (Acceso asistencial estricto si la tabla existe en la instancia)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'formulaciones') THEN
    DROP POLICY IF EXISTS formulaciones_select ON public.formulaciones;
    DROP POLICY IF EXISTS formulaciones_tenant_select ON public.formulaciones;
    CREATE POLICY "formulaciones_select" ON public.formulaciones
      FOR SELECT TO authenticated
      USING (public.is_active_user() AND public.is_clinical_staff() AND tenant_id = public.get_user_tenant_id());

    DROP POLICY IF EXISTS formulaciones_insert ON public.formulaciones;
    DROP POLICY IF EXISTS formulaciones_tenant_insert ON public.formulaciones;
    CREATE POLICY "formulaciones_insert" ON public.formulaciones
      FOR INSERT TO authenticated
      WITH CHECK (public.is_active_user() AND public.is_clinical_staff() AND tenant_id = public.get_user_tenant_id());

    DROP POLICY IF EXISTS formulaciones_update ON public.formulaciones;
    DROP POLICY IF EXISTS formulaciones_tenant_update ON public.formulaciones;
    CREATE POLICY "formulaciones_update" ON public.formulaciones
      FOR UPDATE TO authenticated
      USING (public.is_active_user() AND public.is_clinical_staff() AND tenant_id = public.get_user_tenant_id())
      WITH CHECK (public.is_active_user() AND public.is_clinical_staff() AND tenant_id = public.get_user_tenant_id());

    -- Se revoca la política de eliminación física de formulaciones
    DROP POLICY IF EXISTS formulaciones_delete ON public.formulaciones;
    DROP POLICY IF EXISTS formulaciones_tenant_delete ON public.formulaciones;
  END IF;
END
$$;

COMMIT;
