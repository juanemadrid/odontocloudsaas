# PAQUETE CONSOLIDADO DE INTEROPERABILIDAD IHCE — ODONTOCLOUD SAAS
Fecha de Generación: 2026-10-11
Versión del Módulo: 2.1.0-hardened
Normativa Aplicable: Ley 2015/2020, Resolución 866/2021, Resolución 1888/2025, Resolución 1799/2026, Manual Operativo v1.3 MinSalud

## CONTENIDO DEL PAQUETE
1. /src/components/ihce/ : Componentes React UI (Configuración, Outbox, Break-Glass, Visor RDA, Firma PIN).
2. /src/pages/IhceDashboard.jsx : Dashboard de control general de interoperabilidad para la clínica.
3. /src/services/ihce/ : Conectores y generadores FHIR R4 para cliente.
4. /server/ihce/ : Worker asíncrono, servicio de reconciliación y simulador ministerial local.
5. /supabase/migrations/ : Migraciones PostgreSQL con cifrado AES-256 (pgp_sym_encrypt), firma bcrypt y RLS multi-tenant.
6. /scripts/ : Suite de auditoría correctiva con 34 pruebas positivas y negativas reproducibles.
7. /scripts/samples/ : Bundles FHIR R4 sintéticos para Consulta Odontológica y Paciente.
8. /docs/ihce/ : Documentación arquitectónica, técnica, operacional y jurídica.

## REGLAS CRÍTICAS DE SEGURIDAD
- Red Real: La constante IHCE_LIVE_ENABLED se encuentra en false. Ninguna conexión externa hacia MinSalud está activa.
- Cifrado: Los secretos de cliente y claves APIM se almacenan exclusivamente en BYTEA mediante pgp_sym_encrypt y no se exponen al frontend.
- Firma Clínica: verify_and_close_evolution exige validación estricta de PIN contra hash bcrypt del profesional.
- Break-Glass: Requiere aprobación del administrador de la clínica y prohíbe la autoaprobación.
