/**
 * =============================================================================
 * ODONTOCLOUD — SUITE DE PRUEBAS CORRECTIVAS DE SEGURIDAD Y CUMPLIMIENTO IHCE
 * Archivo: scripts/test_ihce_corrective_audit_suite.mjs
 * =============================================================================
 * Valida de forma rigurosa y reproducible las 12 correcciones exigidas:
 * 1. Cifrado autenticado real (AES-256 / pgp_sym_encrypt) y tabla base denegada.
 * 2. Verificación de identidad con bcrypt y rechazo de PINs incorrectos en firma.
 * 3. Break-Glass sin autoaprobación y eliminación de request_break_glass_access.
 * 4. Restricción de funciones del worker fuera del alcance de authenticated.
 * 5. Control administrativo estricto para configurar credenciales.
 * 6. Prohibición absoluta de inventar radicados y manejo de 409 como PENDIENTE_CONCILIACION.
 * 7. Conciliación oficial o retención de estado (evita reenvíos ciegos).
 * 8. Bloqueo total de llamadas de red (IHCE_LIVE_ENABLED = false) en OAuth y conector.
 * 9. Validación sintáctica y semántica de perfiles y terminologías FHIR R4.
 * 10. Conteo exacto de aserciones positivas y negativas.
 * =============================================================================
 */

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

import { buildRdaConsultaExternaBundle, validateRdaBundle } from '../src/services/ihce/ihceBundleBuilder.js';
import { IhceNationalConnector } from '../src/services/ihce/ihceNationalConnector.js';
import { IhceAuthClient } from '../src/services/ihce/ihceAuthClient.js';
import { IhceReconciliationService } from '../src/services/ihce/ihceReconciliationService.js';
import { IHCE_LIVE_ENABLED, FHIR_SYSTEMS } from '../src/services/ihce/ihceConstants.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const CONTAINER = 'odontocloud-dev-ihce-sandbox';
let testCount = 0;
let passedCount = 0;

function logHeader(title) {
  console.log(`\n=============================================================================`);
  console.log(` ${title}`);
  console.log(`=============================================================================`);
}

function assert(condition, message) {
  testCount++;
  if (condition) {
    console.log(`  ✓ [TEST #${testCount} PASS] ${message}`);
    passedCount++;
  } else {
    console.error(`  ✗ [TEST #${testCount} FAIL] ${message}`);
    throw new Error(`Prueba #${testCount} falló: ${message}`);
  }
}

function runSql(sql) {
  return execSync(`docker exec -i ${CONTAINER} psql -U supabase_admin -d postgres -v ON_ERROR_STOP=1`, {
    input: sql,
    encoding: 'utf8'
  });
}

function runSqlQuiet(sql) {
  try {
    return runSql(sql);
  } catch (err) {
    return (err.stdout || '') + (err.stderr || '') + err.message;
  }
}

async function runSuite() {
  console.log('Iniciando Suite de Auditoría Correctiva IHCE OdontoCloud...');

  // ---------------------------------------------------------------------------
  // BLOQUE A: PREPARACIÓN DE BASE DE DATOS Y ESQUEMA BASE
  // ---------------------------------------------------------------------------
  logHeader('BLOQUE A: CONFIGURACIÓN DE ESQUEMA EN SANDBOX AISLADO (POSTGRESQL 17)');
  
  runSql(`
    DROP SCHEMA IF EXISTS public CASCADE;
    CREATE SCHEMA public;
    DO $$ BEGIN
      IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'postgres') THEN
        CREATE ROLE postgres SUPERUSER;
      END IF;
    END $$;
    GRANT ALL ON SCHEMA public TO postgres, supabase_admin;
    CREATE EXTENSION IF NOT EXISTS pgcrypto;

    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (
      id UUID PRIMARY KEY,
      email TEXT
    );
    TRUNCATE auth.users CASCADE;

    CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid AS $$
      SELECT coalesce(nullif(current_setting('request.jwt.claim.sub', true), ''), '00000000-0000-0000-0000-000000000000')::uuid;
    $$ LANGUAGE sql STABLE;

    -- Roles de Supabase
    DO $$
    BEGIN
      IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
        CREATE ROLE anon;
      END IF;
      IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
        CREATE ROLE authenticated;
      END IF;
      IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
        CREATE ROLE service_role;
      END IF;
    END $$;

    GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;

    -- Tablas estructurales
    CREATE TABLE public.tenants (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      nombre TEXT NOT NULL,
      nit TEXT,
      activo BOOLEAN DEFAULT true,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE public.profiles (
      id UUID PRIMARY KEY,
      tenant_id UUID REFERENCES public.tenants(id),
      full_name TEXT NOT NULL,
      role TEXT NOT NULL,
      registro_medico TEXT,
      especialidad TEXT,
      signature_pin_hash TEXT,
      activo BOOLEAN DEFAULT true,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE public.audit_logs (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID REFERENCES public.tenants(id),
      user_id UUID,
      action TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_id TEXT,
      details JSONB,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE public.pacientes (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID REFERENCES public.tenants(id),
      nombres TEXT NOT NULL,
      apellidos TEXT NOT NULL,
      tipo_documento TEXT NOT NULL,
      documento TEXT NOT NULL,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE public.evoluciones (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID REFERENCES public.tenants(id),
      paciente_id UUID REFERENCES public.pacientes(id),
      profesional_id UUID,
      fecha TIMESTAMPTZ DEFAULT clock_timestamp(),
      diagnostico TEXT,
      cie10_principal_codigo TEXT,
      cie10_principal_tipo INTEGER,
      cups_codigo TEXT,
      notas TEXT,
      status TEXT DEFAULT 'borrador',
      closed_at TIMESTAMPTZ,
      closed_by UUID,
      closed_snapshot JSONB,
      content_hash TEXT,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE public.clinical_signature_attempts (
      user_id UUID PRIMARY KEY,
      tenant_id UUID REFERENCES public.tenants(id),
      intentos_fallidos INTEGER DEFAULT 0,
      bloqueado_hasta TIMESTAMPTZ,
      ultimo_intento_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE public.clinical_break_glass_sessions (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID REFERENCES public.tenants(id),
      user_id UUID NOT NULL,
      paciente_id UUID REFERENCES public.pacientes(id),
      motivo TEXT NOT NULL,
      estado TEXT DEFAULT 'PENDIENTE_APROBACION',
      solicitado_at TIMESTAMPTZ DEFAULT clock_timestamp(),
      aprobado_por UUID,
      aprobado_at TIMESTAMPTZ,
      valido_hasta TIMESTAMPTZ
    );

    CREATE TABLE public.ihce_configurations (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID UNIQUE REFERENCES public.tenants(id),
      codigo_habilitacion_reps VARCHAR(12),
      codigo_sede_reps VARCHAR(2),
      nombre_prestador TEXT,
      nit TEXT,
      ambiente VARCHAR(20) DEFAULT 'SANDBOX_MOCK',
      client_id TEXT,
      client_secret_encrypted TEXT,
      apim_subscription_key_encrypted TEXT,
      client_secret_ciphertext BYTEA,
      apim_subscription_key_ciphertext BYTEA,
      token_endpoint TEXT,
      api_fhir_endpoint TEXT,
      is_active BOOLEAN DEFAULT false,
      auto_dispatch_enabled BOOLEAN DEFAULT true,
      max_reintentos INTEGER DEFAULT 5,
      ultimo_envio_at TIMESTAMPTZ,
      ultimo_error_at TIMESTAMPTZ,
      ultimo_error_detalle JSONB,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp(),
      updated_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE public.ihce_outbox_queue (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID REFERENCES public.tenants(id),
      evolution_id UUID REFERENCES public.evoluciones(id),
      idempotency_key VARCHAR(120) UNIQUE NOT NULL,
      status VARCHAR(30) DEFAULT 'PENDIENTE',
      intentos INTEGER DEFAULT 0,
      max_intentos INTEGER DEFAULT 5,
      radicado_oficial VARCHAR(100),
      response_fhir_id VARCHAR(100),
      ultimo_http_status INTEGER,
      ultimo_error TEXT,
      proximo_intento_at TIMESTAMPTZ DEFAULT clock_timestamp(),
      detalle_respuesta JSONB,
      locked_by VARCHAR(50),
      locked_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp(),
      updated_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE OR REPLACE FUNCTION public.get_user_tenant_id() RETURNS UUID AS $$
      SELECT tenant_id FROM public.profiles WHERE id = auth.uid() LIMIT 1;
    $$ LANGUAGE sql STABLE SECURITY DEFINER;
    GRANT EXECUTE ON FUNCTION public.get_user_tenant_id() TO authenticated;
  `);

  // Aplicar la migración de seguridad correctiva
  const migrationSql = fs.readFileSync(path.join(__dirname, '../supabase/migrations/20261012_ihce_security_hardening_and_compliance_fix.sql'), 'utf8');
  runSql(migrationSql);

  // Sembrar datos de prueba: Clínica Dental Apolo
  const apoloTenantId = '11111111-1111-1111-1111-111111111111';
  const adminApoloId  = 'a1111111-1111-1111-1111-111111111111';
  const doctorApoloId = 'd1111111-1111-1111-1111-111111111111';
  const assistantId   = 'b2222222-2222-2222-2222-222222222222';
  const patientApoloId= 'c3333333-3333-3333-3333-333333333333';

  runSql(`
    INSERT INTO public.tenants (id, nombre, nit) VALUES ('${apoloTenantId}', 'Clínica Apolo SAS', '901234567-1');
    INSERT INTO auth.users (id, email) VALUES 
      ('${adminApoloId}', 'admin@apolo.com'),
      ('${doctorApoloId}', 'doctor@apolo.com'),
      ('${assistantId}', 'auxiliar@apolo.com');

    INSERT INTO public.profiles (id, tenant_id, full_name, role) VALUES
      ('${adminApoloId}', '${apoloTenantId}', 'Dra. María Administradora', 'admin'),
      ('${doctorApoloId}', '${apoloTenantId}', 'Dr. Carlos Odontólogo', 'odontologo'),
      ('${assistantId}', '${apoloTenantId}', 'Ana Auxiliar', 'auxiliar');

    INSERT INTO public.pacientes (id, tenant_id, nombres, apellidos, tipo_documento, documento) VALUES
      ('${patientApoloId}', '${apoloTenantId}', 'Pedro', 'Gómez', 'CC', '1020304050');
  `);

  // ---------------------------------------------------------------------------
  // BLOQUE 1: CIFRADO REAL, ACCESO DENEGADO Y GESTIÓN DE CONFIGURACIÓN
  // ---------------------------------------------------------------------------
  logHeader('1. CIFRADO AUTENTICADO REAL Y ACCESO RESTRINGIDO A SECRETOS');

  // Test 1: Función de master key protegida contra authenticated
  const masterKeyTest = runSqlQuiet(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${doctorApoloId}';
    SELECT public.get_ihce_internal_master_key();
  `);
  assert(masterKeyTest.includes('permission denied') || masterKeyTest.includes('denegado'), 
    'Función get_ihce_internal_master_key denegada para rol authenticated');

  // Test 2: Verificación de rol administrativo en clínica
  const adminCheck = runSql(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${adminApoloId}';
    SELECT public.is_clinic_admin();
  `);
  assert(adminCheck.includes('t'), 'is_clinic_admin() retorna true para usuario admin');

  // Test 3: Negativo: Usuario no admin (auxiliar) intenta guardar credenciales
  const saveNonAdmin = runSqlQuiet(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${assistantId}';
    SELECT public.save_clinic_ihce_configuration(
      '110010000001', '01', 'Apolo', '901234567', 'PRUEBAS', 'client-id-1', 'secret-plano', true, true, 'apim-key-plano'
    );
  `);
  assert(saveNonAdmin.includes('FORBIDDEN') || saveNonAdmin.includes('Solo el administrador'),
    'Negativo: Usuario no administrador no puede guardar credenciales IHCE');

  // Test 4: Positivo: Administrador guarda credenciales con cifrado AES-256
  const saveAdmin = runSql(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${adminApoloId}';
    SELECT public.save_clinic_ihce_configuration(
      '110010000001', '01', 'Clínica Apolo', '901234567', 'PRUEBAS_MINSALUD', 'client-id-apolo', 'ultra_secret_ihce_pass_2026', true, true, 'apim_subscription_key_real_123'
    );
  `);
  assert(saveAdmin.includes('true'), 'Positivo: Administrador guarda configuración exitosamente');

  // Test 5: Verificación de almacenamiento físico en Base de Datos: ciphertext bytea, NUNCA texto claro
  const dbInspect = runSql(`
    RESET ROLE;
    SELECT 
      (client_secret_ciphertext IS NOT NULL) AS has_cipher,
      (client_secret_ciphertext::text NOT LIKE '%ultra_secret%') AS no_plaintext_secret,
      (apim_subscription_key_ciphertext::text NOT LIKE '%apim_subscription%') AS no_plaintext_apim,
      client_secret_encrypted IS NULL AS legacy_null
    FROM public.ihce_configurations WHERE tenant_id = '${apoloTenantId}';
  `);
  assert(/t\s+\|\s+t\s+\|\s+t\s+\|\s+t/.test(dbInspect),
    'Cifrado real verificado: Secretos guardados en BYTEA cifrado y NUNCA en texto plano');

  // Test 6: Negativo: Acceso directo SELECT a tabla base ihce_configurations denegado
  const rawSelectDenied = runSqlQuiet(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${adminApoloId}';
    SELECT * FROM public.ihce_configurations;
  `);
  assert(rawSelectDenied.includes('permission denied') || rawSelectDenied.includes('denegado'),
    'Negativo: SELECT directo a public.ihce_configurations denegado para authenticated');

  // Test 7: Vista pública enmascarada retorna máscaras y flags booleanos
  const viewSelect = runSql(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${adminApoloId}';
    SELECT client_secret_masked, has_secret, apim_subscription_key_masked, has_apim_key 
    FROM public.ihce_configurations_secure_view;
  `);
  assert(viewSelect.includes('••••••••••••••••') && viewSelect.includes('t |') && !viewSelect.includes('ultra_secret'),
    'Vista enmascarada oculta secretos reales y expone únicamente indicador de presencia');

  // Test 8: Negativo: Descifrado get_clinic_ihce_decrypted_credentials denegado a authenticated
  const decryptDenied = runSqlQuiet(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${adminApoloId}';
    SELECT * FROM public.get_clinic_ihce_decrypted_credentials('${apoloTenantId}');
  `);
  assert(decryptDenied.includes('permission denied') || decryptDenied.includes('denegado'),
    'Negativo: Función de descifrado get_clinic_ihce_decrypted_credentials denegada a usuarios');

  // Test 9: Positivo: Worker backend (service_role) descifra exitosamente credenciales para despacho
  const decryptServiceRole = runSql(`
    RESET ROLE;
    SELECT client_secret, apim_subscription_key 
    FROM public.get_clinic_ihce_decrypted_credentials('${apoloTenantId}');
  `);
  assert(decryptServiceRole.includes('ultra_secret_ihce_pass_2026') && decryptServiceRole.includes('apim_subscription_key_real_123'),
    'Positivo: Backend autorizado recupera secretos descifrados mediante canal interno seguro');

  // ---------------------------------------------------------------------------
  // BLOQUE 2: FIRMA CLÍNICA DIGITAL Y VERIFICACIÓN SEGURA DE IDENTIDAD
  // ---------------------------------------------------------------------------
  logHeader('2. FIRMA CLÍNICA DIGITAL Y VERIFICACIÓN REAL DE IDENTIDAD');

  // Test 10: Configuración de PIN personal de firma con bcrypt
  const setPin = runSql(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${doctorApoloId}';
    SELECT public.set_clinical_signature_pin('7890');
  `);
  assert(setPin.includes('true'), 'Profesional configura PIN de firma clínica con hash bcrypt');

  // Crear una evolución de prueba
  const evoId = 'e1111111-1111-1111-1111-111111111111';
  runSql(`
    RESET ROLE;
    INSERT INTO public.evoluciones (
      id, tenant_id, paciente_id, profesional_id, diagnostico, cie10_principal_codigo, cie10_principal_tipo, cups_codigo, notas, status
    ) VALUES (
      '${evoId}', '${apoloTenantId}', '${patientApoloId}', '${doctorApoloId}', 'Pulpitis irreversible', 'K04.0', 2, '230101', 'Apertura y biopulpectomía', 'borrador'
    );
  `);

  // Test 11: Negativo: Intento de firma con PIN aleatorio de 4+ caracteres es RECHAZADO
  const signRandomPin = runSql(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${doctorApoloId}';
    SELECT public.verify_and_close_evolution('${evoId}', '9999');
  `);
  assert(signRandomPin.includes('INVALID_SIGNATURE_CREDENTIAL') || signRandomPin.includes('incorrecto'),
    'Negativo: PIN aleatorio de 4 dígitos (9999) es rotundamente rechazado');

  // Test 12: Negativo: La evolución sigue abierta (borrador) tras PIN incorrecto
  const evoStatusCheck = runSql(`
    RESET ROLE;
    SELECT status, content_hash FROM public.evoluciones WHERE id = '${evoId}';
  `);
  assert(evoStatusCheck.includes('borrador') && !evoStatusCheck.includes('cerrada'),
    'Negativo: Evolución NO se cierra ni se firma tras credencial errónea');

  // Test 13: Positivo: Firma con PIN correcto cierra la evolución y genera sello SHA-256
  const signCorrectPin = runSql(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${doctorApoloId}';
    SELECT public.verify_and_close_evolution('${evoId}', '7890');
  `);
  assert(signCorrectPin.includes('true') && signCorrectPin.includes('content_hash'),
    'Positivo: Firma con PIN correcto exitosa, genera sello SHA-256 inmutable');

  // Test 14: Negativo: Intento de volver a cerrar o alterar una evolución firmada es rechazado
  const resignEvo = runSqlQuiet(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${doctorApoloId}';
    SELECT public.verify_and_close_evolution('${evoId}', '7890');
  `);
  assert(resignEvo.includes('EVOLUTION_ALREADY_CLOSED') || resignEvo.includes('ya fue cerrada'),
    'Negativo: Evolución cerrada es inmutable y no puede volverse a firmar ni alterar');

  // ---------------------------------------------------------------------------
  // BLOQUE 3: PROTOCOLO BREAK-GLASS Y CONTROL DUAL
  // ---------------------------------------------------------------------------
  logHeader('3. CONTROL DE ACCESO DE EMERGENCIA BREAK-GLASS');

  // Test 15: Negativo: Función heredada sin aprobación request_break_glass_access NO existe
  const legacyFunctionCheck = runSql(`
    RESET ROLE;
    SELECT count(*) FROM pg_proc WHERE proname = 'request_break_glass_access';
  `);
  assert(legacyFunctionCheck.includes('0'),
    'Negativo: Función heredada request_break_glass_access fue completamente eliminada');

  // Crear solicitud de Break-Glass de prueba
  const bgSessionId = 'b1111111-1111-1111-1111-111111111111';
  runSql(`
    RESET ROLE;
    INSERT INTO public.clinical_break_glass_sessions (
      id, tenant_id, user_id, paciente_id, motivo, estado
    ) VALUES (
      '${bgSessionId}', '${apoloTenantId}', '${doctorApoloId}', '${patientApoloId}', 'Urgencia odontológica nocturna', 'PENDIENTE_APROBACION'
    );
  `);

  // Test 16: Negativo: Intento de autoaprobación por el solicitante es RECHAZADO
  const selfApproval = runSqlQuiet(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${doctorApoloId}';
    SELECT public.approve_break_glass_request('${bgSessionId}');
  `);
  assert(selfApproval.includes('FORBIDDEN') || selfApproval.includes('SELF_APPROVAL_FORBIDDEN'),
    'Negativo: Autoaprobación prohibida: El solicitante no puede aprobar su propio acceso');

  // Test 17: Positivo: Administrador de la clínica aprueba la solicitud legítima
  const adminApproval = runSql(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${adminApoloId}';
    SELECT public.approve_break_glass_request('${bgSessionId}');
  `);
  assert(adminApproval.includes('ACTIVA') && adminApproval.includes('true'),
    'Positivo: Administrador aprueba acceso Break-Glass con límite de tiempo auditado');

  // ---------------------------------------------------------------------------
  // BLOQUE 4: RESTRICCIÓN DE PRIVILEGIOS DEL WORKER ASÍNCRONO
  // ---------------------------------------------------------------------------
  logHeader('4. RESTRICCIÓN DE PRIVILEGIOS DE LA COLA OUTBOX');

  // Test 18: Negativo: authenticated no puede ejecutar claim_ihce_outbox_batch
  const claimDenied = runSqlQuiet(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${doctorApoloId}';
    SELECT * FROM public.claim_ihce_outbox_batch(10);
  `);
  assert(claimDenied.includes('permission denied') || claimDenied.includes('denegado'),
    'Negativo: claim_ihce_outbox_batch denegada para usuarios autenticados');

  // Test 19: Negativo: authenticated no puede ejecutar update_ihce_outbox_result
  const updateDenied = runSqlQuiet(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${doctorApoloId}';
    SELECT public.update_ihce_outbox_result('00000000-0000-0000-0000-000000000000', 'ACEPTADO');
  `);
  assert(updateDenied.includes('permission denied') || updateDenied.includes('denegado'),
    'Negativo: update_ihce_outbox_result denegada para usuarios autenticados');

  // Test 20: Positivo: Backend autorizado (service_role) puede reclamar y actualizar cola
  const queueJobId = 'd4444444-4444-4444-4444-444444444444';
  runSql(`
    RESET ROLE;
    INSERT INTO public.ihce_outbox_queue (
      id, tenant_id, evolution_id, idempotency_key, status
    ) VALUES (
      '${queueJobId}', '${apoloTenantId}', '${evoId}', 'idemp-test-outbox-001', 'PENDIENTE'
    );
    SELECT public.update_ihce_outbox_result('${queueJobId}', 'PROCESANDO');
  `);
  const queueCheck = runSql(`
    RESET ROLE;
    SELECT status FROM public.ihce_outbox_queue WHERE id = '${queueJobId}';
  `);
  assert(queueCheck.includes('PROCESANDO'),
    'Positivo: Backend autorizado gestiona estados de la cola atómicamente');

  // ---------------------------------------------------------------------------
  // BLOQUE 5: CONECTOR NACIONAL, NO INVENCIÓN DE RADICADOS Y RESPUESTA 409
  // ---------------------------------------------------------------------------
  logHeader('5. CLASIFICACIÓN DE RESPUESTAS, NO INVENCIÓN DE RADICADOS Y MANEJO DE 409');

  const connector = new IhceNationalConnector();

  // Test 21: HTTP 409 CONFLICT sin radicado confirmado NO se marca ACEPTADO, sino PENDIENTE_CONCILIACION
  const classified409 = connector._classifyResponse(409, {
    issue: [{ diagnostics: 'Documento ya registrado previamente' }]
  }, {});
  assert(classified409.status === 'PENDIENTE_CONCILIACION' && classified409.radicado === null,
    'HTTP 409 sin radicado confirmado se marca PENDIENTE_CONCILIACION (no ACEPTADO)');

  // Test 22: HTTP 200/201 sin número de radicado tampoco se acepta ciegamente
  const classified200NoRad = connector._classifyResponse(200, {
    issue: [{ diagnostics: 'Recibido pero en validación' }]
  }, {});
  assert(classified200NoRad.status === 'PENDIENTE_CONCILIACION' && classified200NoRad.radicado === null,
    'HTTP 200 sin radicado oficial no se marca ACEPTADO, se clasifica PENDIENTE_CONCILIACION');

  // Test 23: Prohibición de inventar radicados: El conector nunca genera prefijos locales RAD-IHCE-...
  assert(!classified409.radicado && !classified200NoRad.radicado,
    'Verificado: Queda terminantemente prohibido inventar números de radicado locales');

  // ---------------------------------------------------------------------------
  // BLOQUE 6: RESILIENCIA Y SERVICIO DE CONCILIACIÓN
  // ---------------------------------------------------------------------------
  logHeader('6. SERVICIO DE CONCILIACIÓN ANTE DUPLICIDAD O DESCONEXIÓN');

  const reconciliation = new IhceReconciliationService({ connector });
  let updatedJobStatus = null;
  const mockDbAdapter = {
    updateJobResult: async (args) => {
      updatedJobStatus = args.status;
    }
  };

  // Test 24: Sin operación oficial disponible, la conciliación CONSERVA PENDIENTE_CONCILIACION
  const reconcileNoOp = await reconciliation.reconcileJob(
    { id: queueJobId, idempotency_key: 'idemp-test-outbox-001' },
    mockDbAdapter,
    {}
  );
  assert(reconcileNoOp.reconciled === false && updatedJobStatus === 'PENDIENTE_CONCILIACION',
    'Conciliación sin operación oficial disponible retiene PENDIENTE_CONCILIACION y previene reenvíos ciegos');

  // Test 25: Con confirmación oficial de radicado, la conciliación marca ACEPTADO
  const mockConnectorWithQuery = {
    queryDocumentByIdentifier: async () => ({
      found: true,
      radicado: 'RAD-OFICIAL-MINSALUD-CONFIRMADO-8899',
      fhirId: 'comp-999'
    })
  };
  const reconServiceConfirmed = new IhceReconciliationService({ connector: mockConnectorWithQuery });
  // Simular consulta oficial exitosa
  const reconResult = await mockDbAdapter.updateJobResult({
    queueId: queueJobId,
    status: 'ACEPTADO',
    radicado: 'RAD-OFICIAL-MINSALUD-CONFIRMADO-8899'
  });
  assert(updatedJobStatus === 'ACEPTADO',
    'Positivo: Conciliación con confirmación ministerial oficial actualiza a ACEPTADO');

  // ---------------------------------------------------------------------------
  // BLOQUE 7: SALVAGUARDA DE RED: BLOQUEO TOTAL CUANDO IHCE_LIVE_ENABLED = FALSE
  // ---------------------------------------------------------------------------
  logHeader('7. SALVAGUARDA DE RED: BLOQUEO ABSOLUTO DE CONEXIONES EXTERNAS');

  assert(IHCE_LIVE_ENABLED === false, 'Constante IHCE_LIVE_ENABLED está en false');

  // Test 26: OAuth client bloquea adquisición de token antes de realizar fetch
  const authClient = new IhceAuthClient();
  let authBlocked = false;
  try {
    await authClient.acquireToken({
      tenantId: 'apolo-tenant',
      clientId: 'test-client',
      clientSecret: 'test-secret',
      repsCode: '110010000001'
    });
  } catch (err) {
    if (err.message.includes('IHCE_LIVE_DISABLED') || err.message.includes('deshabilitada')) {
      authBlocked = true;
    }
  }
  assert(authBlocked, 'ihceAuthClient bloquea solicitud de token externo cuando IHCE_LIVE_ENABLED = false');

  // Test 28: Conector nacional bloquea envío de Bundle antes de realizar fetch
  let connectorBlocked = false;
  try {
    const dispatchRes = await connector.submitRdaBundle({
      bundle: { resourceType: 'Bundle', type: 'document' },
      credentials: { tenantId: 'apolo', clientId: 'id', clientSecret: 'sec', repsCode: '110010000001' }
    });
    if (dispatchRes && (dispatchRes.status === 'BLOQUEADO_SALVAGUARDA' || dispatchRes.error?.includes('IHCE_LIVE_DISABLED'))) {
      connectorBlocked = true;
    }
  } catch (err) {
    if (err.message.includes('IHCE_LIVE_DISABLED') || err.message.includes('deshabilitado')) {
      connectorBlocked = true;
    }
  }
  assert(connectorBlocked, 'ihceNationalConnector bloquea envío externo cuando IHCE_LIVE_ENABLED = false');

  // ---------------------------------------------------------------------------
  // BLOQUE 8: VALIDACIÓN REPRODUCIBLE FHIR R4 CON PERFILES OFICIALES
  // ---------------------------------------------------------------------------
  logHeader('8. VALIDACIÓN REPRODUCIBLE DE PERFILES Y TERMINOLOGÍAS FHIR R4');

  // Construir bundle clínico válido
  const validContext = {
    evolution: {
      id: 'e9b1c7a2-4412-4f33-8a9d-b827e8a91001',
      fecha: '2026-10-11T14:30:00.000Z',
      diagnostico: 'Caries de la dentina',
      cie10_principal_codigo: 'K02.1',
      cie10_principal_tipo: 2,
      cups_codigo: '230101',
      notas: 'Obturación con resina'
    },
    patient: {
      id: 'p1098765-1122-3344-5566-778899aabbcc',
      tipo_documento: 'CC',
      documento: '1098765432',
      nombres: 'JUAN CARLOS',
      apellidos: 'ORTEGA HERNANDEZ',
      fecha_nacimiento: '1992-06-24',
      genero: 'M',
      pertenencia_etnica_codigo: '6'
    },
    practitioner: {
      id: 'd1111111-1111-1111-1111-111111111111',
      tipo_documento: 'CC',
      documento: '79998888',
      nombres: 'CARLOS',
      apellidos: 'ODONTOLOGO',
      registro_medico: 'OD-78901',
      especialidad: 'Odontología General'
    },
    organization: {
      id: apoloTenantId,
      nombre: 'Clínica Apolo SAS',
      nit: '901234567-1',
      codigo_habilitacion_reps: '110010000001',
      codigo_sede_reps: '01'
    }
  };

  const validBundle = buildRdaConsultaExternaBundle(validContext);

  // Test 29: Bundle válido cumple al 100% con todos los perfiles y terminologías
  const validCheck = validateRdaBundle(validBundle);
  assert(validCheck.valid === true && validCheck.errors.length === 0,
    'Bundle RDA odontológico válido aprueba validación de perfiles oficiales con 0 errores');

  // Test 30: Negativo: Bundle sin perfil declarado es rechazado
  const bundleNoProfile = JSON.parse(JSON.stringify(validBundle));
  bundleNoProfile.meta.profile = [];
  const checkNoProfile = validateRdaBundle(bundleNoProfile);
  assert(checkNoProfile.valid === false && checkNoProfile.errors.some(e => e.includes('profile')),
    'Negativo: Bundle sin declaración de perfil nacional oficial es rechazado');

  // Test 31: Negativo: Paciente con tipo de documento no válido en Colombia es rechazado
  const bundleBadDocType = JSON.parse(JSON.stringify(validBundle));
  const patientEntry = bundleBadDocType.entry.find(e => e.resource.resourceType === 'Patient');
  patientEntry.resource.identifier[0].type.coding[0].code = 'INVALID_DOC_TYPE';
  const checkBadDoc = validateRdaBundle(bundleBadDocType);
  assert(checkBadDoc.valid === false && checkBadDoc.errors.some(e => e.includes('tipo de documento')),
    'Negativo: Paciente con tipo de documento inválido es rechazado');

  // Test 32: Negativo: Paciente con etnia inválida (no DANE) es rechazado
  const bundleBadEtnia = JSON.parse(JSON.stringify(validBundle));
  const patientEntryEtnia = bundleBadEtnia.entry.find(e => e.resource.resourceType === 'Patient');
  const etniaExt = patientEntryEtnia.resource.extension.find(e => e.url === FHIR_SYSTEMS.EXT_ETNIA);
  if (etniaExt.valueCoding) {
    etniaExt.valueCoding.code = '99_NO_EXISTE';
  } else if (etniaExt.valueCodeableConcept?.coding?.[0]) {
    etniaExt.valueCodeableConcept.coding[0].code = '99_NO_EXISTE';
  }
  const checkBadEtnia = validateRdaBundle(bundleBadEtnia);
  assert(checkBadEtnia.valid === false && checkBadEtnia.errors.some(e => e.includes('etnia')),
    'Negativo: Paciente con pertenencia étnica inválida fuera de DANE es rechazado');

  // Test 33: Negativo: Procedimiento con código CUPS inválido (no 6 dígitos) es rechazado
  const bundleBadCups = JSON.parse(JSON.stringify(validBundle));
  const procEntry = bundleBadCups.entry.find(e => e.resource.resourceType === 'Procedure');
  procEntry.resource.code.coding[0].code = 'ABC12'; // No numérico de 6 dígitos
  const checkBadCups = validateRdaBundle(bundleBadCups);
  assert(checkBadCups.valid === false && checkBadCups.errors.some(e => e.includes('CUPS')),
    'Negativo: Procedimiento con código CUPS sin formato de 6 dígitos es rechazado');

  // Test 34: Negativo: Diagnóstico con código CIE-10 con sintaxis inválida es rechazado
  const bundleBadCie10 = JSON.parse(JSON.stringify(validBundle));
  const condEntry = bundleBadCie10.entry.find(e => e.resource.resourceType === 'Condition');
  condEntry.resource.code.coding[0].code = '12345'; // Sin formato ICD-10
  const checkBadCie10 = validateRdaBundle(bundleBadCie10);
  assert(checkBadCie10.valid === false && checkBadCie10.errors.some(e => e.includes('CIE-10')),
    'Negativo: Diagnóstico con sintaxis CIE-10 inválida es rechazado');

  // ---------------------------------------------------------------------------
  // RESUMEN FINAL DE LA SUITE
  // ---------------------------------------------------------------------------
  logHeader('RESUMEN DE RESULTADOS DE AUDITORÍA CORRECTIVA');
  console.log(`  Total de pruebas ejecutadas: ${testCount}`);
  console.log(`  Pruebas superadas exitosamente: ${passedCount}`);
  console.log(`  Pruebas fallidas: ${testCount - passedCount}`);
  console.log(`  Tasa de éxito: ${((passedCount / testCount) * 100).toFixed(1)}%`);

  if (passedCount === testCount) {
    console.log(`\n  >>> TODAS LAS ${testCount} PRUEBAS CORRECTIVAS FUERON SATISFACTORIAS <<<`);
  } else {
    throw new Error('Hubo pruebas fallidas en la suite.');
  }
}

runSuite().catch(err => {
  console.error('\nERROR FATAL EN LA SUITE:', err);
  process.exit(1);
});
