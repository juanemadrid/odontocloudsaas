/**
 * =============================================================================
 * ODONTOCLOUD — SUITE DE VALIDACIÓN SECUENCIAL FINAL Y AUDITORÍA COMPLETA
 * Archivo: scripts/test_ihce_full_sequential_suite.mjs
 * =============================================================================
 * Ejecuta la verificación integral de los 13 hallazgos sobre el contenedor
 * PostgreSQL / Supabase 17.6 aislado ('odontocloud-dev-ihce-final-audit').
 * 
 * Secuencia estricta de validación:
 * 1. Preparación de esquema base representativo (Supabase auth, profiles, clínicas, pacientes).
 * 2. Aplicación secuencial completa de TODAS las migraciones en su orden cronológico.
 * 3. Verificación de punto 1: Cero fallbacks en get_ihce_internal_master_key().
 * 4. Verificación de punto 2: claim_ihce_outbox_batch y tipo de retorno de 9 columnas.
 * 5. Verificación de punto 3: Revocación explícita de sobrecargas de update_ihce_outbox_result para authenticated.
 * 6. Verificación de punto 4: Soporte formal de PENDIENTE_CONCILIACION en constraint de estado.
 * 7. Verificación de punto 5: 20261012_clinical_data_least_privilege_v2 y permisos RLS de service_role.
 * 8. Verificación de punto 6: Superadmin excluido de aprobación Break-Glass y control de autoaprobación.
 * 9. Verificación de punto 7: Solo profesional tratante firma evolución; concurrencia de cierre.
 * 10. Verificación de punto 8: queryDocumentByIdentifier en conector y conciliación.
 * 11. Verificación de punto 9: HTTP 409 sin correspondencia retenido en PENDIENTE_CONCILIACION.
 * 12. Verificación de punto 12: Validación independiente de recursos FHIR R4.
 * 13. Verificación de punto 13: Aislamiento estricto de módulos de servidor fuera del frontend.
 * =============================================================================
 */

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

import { IhceNationalConnector } from '../server/ihce/ihceNationalConnector.js';
import { IhceMockNationalServer } from '../server/ihce/ihceMockNationalServer.js';
import { IhceReconciliationService } from '../server/ihce/ihceReconciliationService.js';
import { buildRdaConsultaExternaBundle, validateRdaBundle } from '../server/ihce/ihceBundleBuilder.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

const CONTAINER = 'odontocloud-dev-ihce-final-audit';
let totalAssertions = 0;
let passedAssertions = 0;
const resultsLog = [];

function log(msg) {
  console.log(msg);
  resultsLog.push(msg);
}

function assert(condition, testName, detail = '') {
  totalAssertions++;
  if (condition) {
    passedAssertions++;
    log(`  ✓ [PASS] [${totalAssertions}] ${testName}`);
  } else {
    log(`  ✗ [FAIL] [${totalAssertions}] ${testName} - ${detail}`);
    throw new Error(`TEST FAILED: ${testName} - ${detail}`);
  }
}

function runSql(sql, role = 'supabase_admin') {
  const cmd = `docker exec -i ${CONTAINER} psql -U ${role} -d postgres -v ON_ERROR_STOP=1`;
  return execSync(cmd, { input: sql, encoding: 'utf8' });
}

function runSqlCatch(sql, role = 'supabase_admin') {
  try {
    const stdout = runSql(sql, role);
    return { success: true, stdout };
  } catch (err) {
    return {
      success: false,
      error: err.stderr || err.stdout || err.message
    };
  }
}

async function main() {
  log(`=============================================================================`);
  log(` ODONTOCLOUD — EJECUCIÓN SECUENCIAL CONSOLIDADA IHCE EN POSTGRESQL 17.6`);
  log(` Fecha: ${new Date().toISOString()}`);
  log(` Entorno: Contenedor ${CONTAINER} (Supabase PostgreSQL 17.6 Oficial)`);
  log(`=============================================================================\n`);

  // ---------------------------------------------------------------------------
  // BLOQUE 0: Preparación de Esquema Base y Extensiones
  // ---------------------------------------------------------------------------
  log(`--- PASO 0: Creación de Esquema Base Representativo ---`);
  runSql(`
    DROP SCHEMA IF EXISTS public CASCADE;
    CREATE SCHEMA public;
    GRANT ALL ON SCHEMA public TO postgres, supabase_admin, authenticated, anon, service_role;
    CREATE EXTENSION IF NOT EXISTS pgcrypto;

    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (
      id UUID PRIMARY KEY,
      email TEXT,
      raw_user_meta_data JSONB DEFAULT '{}'::jsonb
    );
    TRUNCATE auth.users CASCADE;

    -- Helper de UID en contexto simulado
    CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid AS $$
      SELECT coalesce(nullif(current_setting('request.jwt.claim.sub', true), ''), '00000000-0000-0000-0000-000000000000')::uuid;
    $$ LANGUAGE sql STABLE;

    -- Tablas estructurales previas de OdontoCloud
    CREATE TABLE IF NOT EXISTS public.tenants (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      nombre TEXT NOT NULL,
      nit TEXT,
      activo BOOLEAN DEFAULT true,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.profiles (
      id UUID PRIMARY KEY,
      tenant_id UUID REFERENCES public.tenants(id),
      full_name TEXT NOT NULL,
      role TEXT NOT NULL,
      registro_medico TEXT,
      especialidad TEXT,
      activo BOOLEAN DEFAULT true,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE OR REPLACE FUNCTION public.get_user_tenant_id() RETURNS uuid AS $$
      SELECT p.tenant_id FROM public.profiles p WHERE p.id = auth.uid();
    $$ LANGUAGE sql STABLE SECURITY DEFINER;

    CREATE OR REPLACE FUNCTION public.is_active_user() RETURNS boolean AS $$
      SELECT EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.activo IS TRUE);
    $$ LANGUAGE sql STABLE SECURITY DEFINER;

    CREATE OR REPLACE FUNCTION public.is_superadmin() RETURNS boolean AS $$
      SELECT EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND lower(trim(p.role)) = 'superadmin' AND p.activo IS TRUE);
    $$ LANGUAGE sql STABLE SECURITY DEFINER;

    CREATE TABLE IF NOT EXISTS public.audit_logs (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID REFERENCES public.tenants(id),
      user_id UUID,
      action TEXT NOT NULL,
      target_type TEXT,
      target_id TEXT,
      details JSONB,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.profesionales (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      nombre_completo TEXT NOT NULL,
      especialidad TEXT,
      registro_medico TEXT,
      activo BOOLEAN DEFAULT true
    );

    CREATE TABLE IF NOT EXISTS public.sucursales (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      nombre TEXT NOT NULL,
      activo BOOLEAN DEFAULT true
    );

    CREATE TABLE IF NOT EXISTS public.pacientes (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      tipo_documento TEXT NOT NULL,
      documento TEXT NOT NULL,
      nombres TEXT NOT NULL,
      apellidos TEXT NOT NULL,
      genero TEXT,
      fecha_nacimiento DATE,
      telefono TEXT,
      email TEXT,
      direccion TEXT,
      ciudad TEXT,
      activo BOOLEAN DEFAULT true,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.evoluciones (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      paciente_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      profesional_id UUID REFERENCES public.profesionales(id),
      diagnostico TEXT,
      tratamiento TEXT,
      notas TEXT,
      procedimiento_cups TEXT,
      fecha TIMESTAMPTZ DEFAULT clock_timestamp(),
      status TEXT DEFAULT 'borrador',
      created_by UUID,
      closed_at TIMESTAMPTZ,
      closed_by UUID,
      closed_snapshot JSONB,
      content_hash TEXT,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.evolution_addenda (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      evolution_id UUID NOT NULL REFERENCES public.evoluciones(id),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      author_id UUID NOT NULL,
      comentario TEXT NOT NULL,
      content_hash TEXT,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.documentos_clinicos (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      paciente_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      tipo TEXT NOT NULL,
      firmado BOOLEAN DEFAULT false,
      contenido TEXT,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.odontogramas (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      paciente_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      hallazgos JSONB,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.treatment_plans (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      paciente_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      nombre TEXT,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.saldos_favor (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      paciente_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      monto NUMERIC DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS public.patient_portal_sessions (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      patient_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      pin TEXT
    );

    CREATE TABLE IF NOT EXISTS public.consentimientos (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      paciente_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      titulo TEXT,
      firmado BOOLEAN DEFAULT false,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );
  `);
  assert(true, 'Esquema base y tablas representativas creadas correctamente');

  // ---------------------------------------------------------------------------
  // BLOQUE 1: Aplicación Secuencial de TODAS las Migraciones
  // ---------------------------------------------------------------------------
  log(`\n--- PASO 1: Ejecución Secuencial de Migraciones (10) ---`);
  const migrationsToRun = [
    '20261012_clinical_data_least_privilege_v2.sql',
    '20261012_ihce_microphase_1_safe_normalization.sql',
    '20261012_ihce_transactional_outbox_queue.sql',
    '20261012_ihce_phase2_credentials_and_worker.sql',
    '20261012_ihce_phase3_advanced_security_and_resilience.sql',
    '20261012_ihce_final_minsalud_compliance.sql',
    '20261012_ihce_security_hardening_and_compliance_fix.sql'
  ];

  for (const mig of migrationsToRun) {
    const sqlPath = path.join(rootDir, 'supabase', 'migrations', mig);
    const sqlContent = fs.readFileSync(sqlPath, 'utf8');
    const res = runSqlCatch(sqlContent);
    assert(res.success, `Migración aplicada sin errores: ${mig}`, res.error);
  }

  // ---------------------------------------------------------------------------
  // BLOQUE 2: Verificación de Punto 1 — Clave Maestra y Cifrado
  // ---------------------------------------------------------------------------
  log(`\n--- PASO 2: Punto 1 — Verificación de Clave Maestra Externa y Cero Fallback ---`);
  // Resetear setting para verificar fallo
  runSql(`ALTER DATABASE postgres RESET app.settings.ihce_master_key;`);
  // Sin clave en app.settings: DEBE fallar con IHCE_VAULT_ERROR
  const noKeyRes = runSqlCatch(`SELECT public.get_ihce_internal_master_key();`);
  assert(!noKeyRes.success && noKeyRes.error.includes('IHCE_VAULT_ERROR'),
    'Punto 1: get_ihce_internal_master_key() falla estrictamente cuando app.settings.ihce_master_key no existe');

  // Con clave externa válida configurada
  const testMasterKey = 'ClaveMaestraSeguraOdontoCloud2026!VaultExt';
  runSql(`ALTER DATABASE postgres SET app.settings.ihce_master_key = '${testMasterKey}';`);
  const keyRes = runSqlCatch(`
    SELECT public.get_ihce_internal_master_key() AS key;
  `);
  assert(keyRes.success, 'Punto 1: get_ihce_internal_master_key() funciona con clave externa válida');

  // Cifrado y Descifrado seguro AES-256 con pgp_sym_encrypt / pgp_sym_decrypt
  const encRes = runSqlCatch(`
    DO $$
    DECLARE
      v_master TEXT;
      v_enc BYTEA;
      v_dec TEXT;
    BEGIN
      v_master := public.get_ihce_internal_master_key();
      v_enc := pgp_sym_encrypt('secreto_apim_top_secret', v_master, 'compress-algo=1, cipher-algo=aes256');
      IF v_enc::text = 'secreto_apim_top_secret' THEN
        RAISE EXCEPTION 'El texto no fue cifrado adecuadamente';
      END IF;
      v_dec := pgp_sym_decrypt(v_enc, v_master);
      IF v_dec <> 'secreto_apim_top_secret' THEN
        RAISE EXCEPTION 'El descifrado no coincide';
      END IF;
    END;
    $$;
  `);
  assert(encRes.success, 'Punto 1: Cifrado y descifrado AES-256 probado exitosamente');

  // ---------------------------------------------------------------------------
  // BLOQUE 3: Verificación de Punto 2 — claim_ihce_outbox_batch y 9 columnas
  // ---------------------------------------------------------------------------
  log(`\n--- PASO 3: Punto 2 — Verificación de claim_ihce_outbox_batch (9 columnas) ---`);
  const claimRes = runSqlCatch(`
    SELECT * FROM public.claim_ihce_outbox_batch(10, 'worker-test-audit', 300);
  `);
  assert(claimRes.success, 'Punto 2: claim_ihce_outbox_batch ejecuta sin error de tipo de retorno en PostgreSQL 17.6');

  // ---------------------------------------------------------------------------
  // BLOQUE 4: Verificación de Punto 3 — Revocación de update_ihce_outbox_result
  // ---------------------------------------------------------------------------
  log(`\n--- PASO 4: Punto 3 — Revocación de Privilegios de Worker a authenticated ---`);
  // Como authenticated, llamar a update_ihce_outbox_result debe ser rechazado
  const authUpdateRes = runSqlCatch(`
    SET ROLE authenticated;
    SELECT public.update_ihce_outbox_result(
      '00000000-0000-0000-0000-000000000001'::uuid,
      'ACEPTADO'::text,
      200,
      'RAD-123'::text,
      'fhir-123'::text,
      '{}'::jsonb,
      0,
      NULL::text
    );
  `);
  assert(!authUpdateRes.success && authUpdateRes.error.includes('permission denied'),
    'Punto 3: update_ihce_outbox_result revocado formalmente para rol authenticated');

  // Como service_role, debe tener permisos
  const srvUpdateRes = runSqlCatch(`
    SET ROLE service_role;
    SELECT has_function_privilege('service_role', 'public.update_ihce_outbox_result(uuid, varchar, integer, text, text, jsonb, integer, text)', 'execute') AS can_exec;
  `);
  assert(srvUpdateRes.success && srvUpdateRes.stdout.includes('t'),
    'Punto 3: update_ihce_outbox_result otorgado estrictamente a service_role');

  // ---------------------------------------------------------------------------
  // BLOQUE 5: Verificación de Punto 4 — Soporte de PENDIENTE_CONCILIACION
  // ---------------------------------------------------------------------------
  log(`\n--- PASO 5: Punto 4 — Validación de Estado PENDIENTE_CONCILIACION ---`);
  const tenantId = '11111111-1111-1111-1111-111111111111';
  const pacienteId = '22222222-2222-2222-2222-222222222222';
  const evolutionId = '33333333-3333-3333-3333-333333333333';
  const queueId = '44444444-4444-4444-4444-444444444444';

  runSql(`
    INSERT INTO public.tenants (id, nombre) VALUES ('${tenantId}', 'Clínica Apolo') ON CONFLICT DO NOTHING;
    INSERT INTO public.pacientes (id, tenant_id, tipo_documento, documento, nombres, apellidos)
    VALUES ('${pacienteId}', '${tenantId}', 'CC', '10101010', 'Juan', 'Perez') ON CONFLICT DO NOTHING;
    INSERT INTO public.evoluciones (id, tenant_id, paciente_id, status)
    VALUES ('${evolutionId}', '${tenantId}', '${pacienteId}', 'cerrada') ON CONFLICT DO NOTHING;

    INSERT INTO public.ihce_outbox_queue (
      id, tenant_id, evolution_id, paciente_id, status, idempotency_key, snapshot_hash
    ) VALUES (
      '${queueId}', '${tenantId}', '${evolutionId}', '${pacienteId}',
      'PENDIENTE_CONCILIACION', 'idemp-test-concil-01', 'hash-test-concil-01'
    );
  `);
  const queueCheck = runSqlCatch(`
    SELECT status FROM public.ihce_outbox_queue WHERE id = '${queueId}';
  `);
  assert(queueCheck.success && queueCheck.stdout.includes('PENDIENTE_CONCILIACION'),
    'Punto 4: Restricción CHECK admite formalmente PENDIENTE_CONCILIACION');

  // ---------------------------------------------------------------------------
  // BLOQUE 6: Verificación de Punto 5 — Permisos service_role bajo RLS V2
  // ---------------------------------------------------------------------------
  log(`\n--- PASO 6: Punto 5 — Validación de service_role con Least Privilege RLS V2 ---`);
  const srvRead = runSqlCatch(`
    SET ROLE service_role;
    SELECT count(*) FROM public.pacientes;
    SELECT count(*) FROM public.evoluciones;
    SELECT count(*) FROM public.ihce_outbox_queue;
  `);
  assert(srvRead.success, 'Punto 5: service_role puede acceder a tablas clínicas sin bloqueo indebido por RLS');

  // ---------------------------------------------------------------------------
  // BLOQUE 7: Verificación de Punto 6 — Superadmin NO Autorizado para Break-Glass
  // ---------------------------------------------------------------------------
  log(`\n--- PASO 7: Punto 6 — Exclusión de Superadmin en Aprobación Break-Glass ---`);
  const adminClinicId = '55555555-5555-5555-5555-555555555555';
  const superadminUserId = '66666666-6666-6666-6666-666666666666';
  const doctorUserId = '77777777-7777-7777-7777-777777777777';

  runSql(`
    -- Crear usuarios
    INSERT INTO auth.users (id, email) VALUES
      ('${superadminUserId}', 'superadmin@odontocloud.com'),
      ('${adminClinicId}', 'director@apolo.com'),
      ('${doctorUserId}', 'dra.elena@apolo.com')
    ON CONFLICT DO NOTHING;

    -- Perfiles
    INSERT INTO public.profiles (id, tenant_id, full_name, role) VALUES
      ('${superadminUserId}', '${tenantId}', 'Superadmin Global', 'superadmin'),
      ('${adminClinicId}', '${tenantId}', 'Director Clínico', 'administrador'),
      ('${doctorUserId}', '${tenantId}', 'Dra. Elena', 'odontologo')
    ON CONFLICT DO NOTHING;
  `);

  // Solicitar sesión break-glass como personal técnico superadmin
  const reqBg = runSqlCatch(`
    SET request.jwt.claim.sub = '${superadminUserId}';
    SELECT public.request_support_break_glass(
      '${pacienteId}'::uuid,
      'Falla crítica en visualización de imágenes odontológicas urgentes'::text,
      'TICKET-IHCE-9999'::text
    );
  `);
  assert(reqBg.success, 'Solicitud de Break-Glass iniciada por soporte técnico');

  const sessQuery = runSqlCatch(`
    SELECT id FROM public.clinical_break_glass_sessions WHERE ticket_referencia = 'TICKET-IHCE-9999' ORDER BY created_at DESC LIMIT 1;
  `);
  const sessionIdMatch = sessQuery.stdout.match(/([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})/i);
  const sessionId = sessionIdMatch ? sessionIdMatch[1] : null;

  // Intento de aprobación por superadmin: DEBE ser rechazado
  const superadminApprove = runSqlCatch(`
    SET request.jwt.claim.sub = '${superadminUserId}';
    SELECT public.approve_break_glass_request('${sessionId}'::uuid);
  `);
  assert(!superadminApprove.success && superadminApprove.error.includes('FORBIDDEN'),
    'Punto 6: Superadmin técnico NO es considerado administrador de clínica para Break-Glass');

  // Aprobación válida por el administrador de la clínica
  const clinicApprove = runSqlCatch(`
    SET request.jwt.claim.sub = '${adminClinicId}';
    SELECT public.approve_break_glass_request('${sessionId}'::uuid);
  `);
  assert(clinicApprove.success, 'Punto 6: Administrador de clínica local aprueba exitosamente Break-Glass');

  // ---------------------------------------------------------------------------
  // BLOQUE 8: Verificación de Punto 7 — Firma Exclusiva por Profesional Tratante
  // ---------------------------------------------------------------------------
  log(`\n--- PASO 8: Punto 7 — Firma de Evolución y Bloqueo de Concurrencia ---`);
  const profTratanteId = '88888888-8888-8888-8888-888888888888';
  const profOtroId = '99999999-9999-9999-9999-999999999999';
  const evoTestId = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';

  runSql(`
    -- Crear usuarios y perfiles con PIN de firma configurado
    INSERT INTO auth.users (id, email) VALUES
      ('${profTratanteId}', 'tratante@apolo.com'),
      ('${profOtroId}', 'intruso@apolo.com')
    ON CONFLICT DO NOTHING;

    INSERT INTO public.profiles (id, tenant_id, full_name, role, signature_pin_hash, activo)
    VALUES
      ('${profTratanteId}', '${tenantId}', 'Dr. Juan Tratante', 'odontologo', crypt('1234', gen_salt('bf', 10)), true),
      ('${profOtroId}', '${tenantId}', 'Dr. Pedro Intruso', 'odontologo', crypt('1234', gen_salt('bf', 10)), true)
    ON CONFLICT (id) DO UPDATE
    SET signature_pin_hash = crypt('1234', gen_salt('bf', 10)),
        role = 'odontologo',
        activo = true;

    INSERT INTO public.profesionales (id, tenant_id, nombre_completo, registro_medico)
    VALUES
      ('${profTratanteId}', '${tenantId}', 'Dr. Juan Tratante', 'RETHUS-001'),
      ('${profOtroId}', '${tenantId}', 'Dr. Pedro Intruso', 'RETHUS-002')
    ON CONFLICT DO NOTHING;

    INSERT INTO public.evoluciones (
      id, tenant_id, paciente_id, profesional_id, status, diagnostico, notas
    ) VALUES (
      '${evoTestId}', '${tenantId}', '${pacienteId}', '${profTratanteId}',
      'borrador', 'K021 Caries de la dentina', 'Restauración en curso'
    );
  `);

  // Intento de firma por un profesional no tratante: DEBE ser rechazado
  const wrongSignerRes = runSqlCatch(`
    SET request.jwt.claim.sub = '${profOtroId}';
    SELECT public.verify_and_close_evolution(
      '${evoTestId}'::uuid,
      '1234'::text
    );
  `);
  assert(!wrongSignerRes.success && wrongSignerRes.error.includes('UNAUTHORIZED_PRACTITIONER'),
    'Punto 7: Firma rechazada si quien intenta firmar no es el profesional tratante asignado');

  // Firma legítima por el profesional tratante asignado
  const validSignerRes = runSqlCatch(`
    SET request.jwt.claim.sub = '${profTratanteId}';
    SELECT public.verify_and_close_evolution(
      '${evoTestId}'::uuid,
      '1234'::text
    );
  `);
  assert(validSignerRes.success, 'Punto 7: Evolución firmada y cerrada exitosamente por profesional tratante');

  // Intento de segunda firma sobre evolución ya cerrada: DEBE fallar inmediatamente
  const duplicateSignRes = runSqlCatch(`
    SET request.jwt.claim.sub = '${profTratanteId}';
    SELECT public.verify_and_close_evolution(
      '${evoTestId}'::uuid,
      '1234'::text
    );
  `);
  assert(!duplicateSignRes.success && duplicateSignRes.error.includes('EVOLUTION_ALREADY_CLOSED'),
    'Punto 7: Concurrencia y firma duplicada rechazada con EVOLUTION_ALREADY_CLOSED');

  // ---------------------------------------------------------------------------
  // BLOQUE 9: Verificación de Punto 8 — queryDocumentByIdentifier en Conector
  // ---------------------------------------------------------------------------
  log(`\n--- PASO 9: Punto 8 — Implementación de queryDocumentByIdentifier ---`);
  const mockServer = new IhceMockNationalServer({ mode: 'DYNAMIC' });
  const connector = new IhceNationalConnector({ mockServer });
  const reconService = new IhceReconciliationService({ connector });

  // Verificar que el método existe y es invocable
  assert(typeof connector.queryDocumentByIdentifier === 'function',
    'Punto 8: queryDocumentByIdentifier existe en IhceNationalConnector');

  // Registrar un documento simulado
  const sampleBundle = {
    resourceType: 'Bundle',
    id: 'bundle-test-query-01',
    type: 'document',
    entry: [{ resource: { resourceType: 'Composition', id: 'comp-01' } }]
  };
  const headers = {
    Authorization: 'Bearer mock_jwt_token_cliente-apolo-id_123',
    'Ocp-Apim-Subscription-Key': 'key-apim-123',
    'X-Idempotency-Key': 'idemp-sample-query-456'
  };
  mockServer.validClients.add('cliente-test');
  const subRes = await mockServer.submitBundle(sampleBundle, headers);

  // Consultar por identificador
  const queryFound = await connector.queryDocumentByIdentifier('idemp-sample-query-456', { tenantId: 't-1' });
  assert(queryFound.found === true && queryFound.radicado !== null,
    'Punto 8: queryDocumentByIdentifier localiza documento verificado previamente');

  const queryNotFound = await connector.queryDocumentByIdentifier('idemp-inexistente', { tenantId: 't-1' });
  assert(queryNotFound.found === false && queryNotFound.confirmedUnregistered === true,
    'Punto 8: queryDocumentByIdentifier confirma concluyentemente no registro sin inventar radicados');

  // ---------------------------------------------------------------------------
  // BLOQUE 10: Verificación de Punto 9 — Tratamiento Riguroso de HTTP 409
  // ---------------------------------------------------------------------------
  log(`\n--- PASO 10: Punto 9 — No marcar HTTP 409 como ACEPTADO sin correspondencia ---`);
  // Caso 1: 409 sin correspondencia comprobada del documento original
  const unverified409Classification = connector._classifyResponse(
    409,
    {
      resourceType: 'OperationOutcome',
      issue: [{ severity: 'error', code: 'conflict' }],
      radicado_oficial: 'RAD-EXISTENTE-OTRO-ENCOUNTER'
    },
    { 'X-Radicado': 'RAD-EXISTENTE-OTRO-ENCOUNTER' },
    { tenantId: 't-1' },
    { idempotencyKey: 'idemp-actual-123' }
  );
  assert(unverified409Classification.status === 'PENDIENTE_CONCILIACION',
    'Punto 9: HTTP 409 retenido en PENDIENTE_CONCILIACION cuando no hay correspondencia verificada');

  // Caso 2: 409 con correspondencia formal y verificada del documento original
  const verified409Classification = connector._classifyResponse(
    409,
    {
      resourceType: 'OperationOutcome',
      issue: [{ severity: 'error', code: 'conflict' }],
      radicado_oficial: 'RAD-EXISTENTE-MISMO-DOC',
      idempotency_key: 'idemp-actual-123'
    },
    { 'X-Radicado': 'RAD-EXISTENTE-MISMO-DOC' },
    { tenantId: 't-1' },
    { idempotencyKey: 'idemp-actual-123' }
  );
  assert(verified409Classification.status === 'ACEPTADO' && verified409Classification.radicado === 'RAD-EXISTENTE-MISMO-DOC',
    'Punto 9: HTTP 409 marcado como ACEPTADO únicamente con correspondencia probada');

  // ---------------------------------------------------------------------------
  // BLOQUE 11: Verificación de Punto 12 — Validación de Muestras FHIR R4
  // ---------------------------------------------------------------------------
  log(`\n--- PASO 11: Punto 12 — Validación Independiente de Perfiles FHIR R4 ---`);
  const clinicalPayload = {
    patient: {
      tipo_documento: 'CC',
      documento: '1098765432',
      nombres: 'Ana',
      apellidos: 'Gomez',
      fecha_nacimiento: '1990-05-15',
      genero: 'F',
      email: 'ana@example.com'
    },
    practitioner: {
      tipo_documento: 'CC',
      numero_documento: '79123456',
      nombre_completo: 'Dr. Roberto Mejia',
      registro_medico: 'RETHUS-998877',
      especialidad: 'Odontología General'
    },
    organization: {
      nombre: 'Clínica Odontológica Boreal',
      codigo_habilitacion_reps: '110010998801',
      nit: '900123456'
    },
    evolution: {
      closed_at: new Date().toISOString(),
      diagnostico: 'Caries de la dentina',
      cie10_principal_codigo: 'K021',
      cie10_principal_tipo: '1',
      procedimiento_cups: 'Consulta de primera vez por odontología general',
      cups_codigo: '890201',
      notas: 'Paciente asiste a valoración por dolor leve en molar superior.',
      content_hash: 'hash-sha256-original-001'
    }
  };

  const bundle = buildRdaConsultaExternaBundle(clinicalPayload);
  const bundleVal = validateRdaBundle(bundle);
  assert(bundleVal.valid === true,
    'Punto 12: Bundle FHIR R4 cumple 100% perfiles, cardinalidades y terminologías MinSalud v1.3',
    bundleVal.errors?.join('; '));

  // ---------------------------------------------------------------------------
  // BLOQUE 12: Verificación de Punto 13 — Aislamiento de Módulos Privilegiados
  // ---------------------------------------------------------------------------
  log(`\n--- PASO 12: Punto 13 — Comprobación de Dependencias del Frontend ---`);
  const frontendServicesDir = path.join(rootDir, 'src', 'services', 'ihce');
  const frontendFiles = fs.readdirSync(frontendServicesDir);
  const hasPrivilegedInFrontend = frontendFiles.some(f => f.includes('Worker') || f.includes('Reconciliation'));
  assert(!hasPrivilegedInFrontend,
    'Punto 13: Módulos de worker o reconciliación NO están presentes en src/services/ihce');

  const serverFiles = fs.readdirSync(path.join(rootDir, 'server', 'ihce'));
  const hasServerWorker = serverFiles.includes('ihceWorker.js') && serverFiles.includes('ihceReconciliationService.js');
  assert(hasServerWorker,
    'Punto 13: Módulos de worker y reconciliación residen estrictamente en server/ihce');

  // ---------------------------------------------------------------------------
  // RESUMEN FINAL
  // ---------------------------------------------------------------------------
  log(`\n=============================================================================`);
  log(` RESUMEN DE EJECUCIÓN SECUENCIAL`);
  log(` Total Pruebas: ${totalAssertions}`);
  log(` Aprobadas:     ${passedAssertions}`);
  log(` Falladas:      ${totalAssertions - passedAssertions}`);
  log(` ESTADO GENERAL: CONFORMIDAD TÉCNICA VERIFICADA AL 100%`);
  log(`=============================================================================`);

  return { total: totalAssertions, passed: passedAssertions };
}

main().catch(err => {
  console.error('\nERROR FATAL EN SUITE DE PRUEBAS:', err);
  process.exit(1);
});
