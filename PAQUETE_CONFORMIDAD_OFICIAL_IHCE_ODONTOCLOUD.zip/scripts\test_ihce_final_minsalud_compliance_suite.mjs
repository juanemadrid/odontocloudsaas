/**
 * SUITE INTEGRAL DE CIERRE TÉCNICO Y CONFORMIDAD MINSALUD IHCE
 * OdontoCloud SaaS — Manual de Operaciones IHCE v1.3 / Res. 1888/2025
 * 
 * Ejecución aislada sobre PostgreSQL 17.6 en contenedor Docker local.
 * NO toca producción, NO toca VPS ni otros servicios.
 */

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

import { IhceNationalConnector, IHCE_LIVE_ENABLED } from '../src/services/ihce/ihceNationalConnector.js';
import { IhceMockNationalServer } from '../src/services/ihce/ihceMockNationalServer.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const CONTAINER = 'odontocloud-dev-final-compliance-sandbox';
const PORT = 54398;

let totalTests = 0;
let passedTests = 0;

function logHeader(title) {
  console.log(`\n=============================================================================`);
  console.log(` ${title}`);
  console.log(`=============================================================================`);
}

function assert(condition, message) {
  totalTests++;
  if (condition) {
    console.log(`  ✓ [PASS] ${message}`);
    passedTests++;
  } else {
    console.error(`  ✗ [FAIL] ${message}`);
    throw new Error(`Fallo de prueba: ${message}`);
  }
}

function runSql(sql) {
  return execSync(`docker exec -i ${CONTAINER} psql -U supabase_admin -d postgres -v ON_ERROR_STOP=1`, {
    input: sql,
    encoding: 'utf8'
  });
}

function runSqlQuiet(sql) {
  try {
    return runSql(sql);
  } catch (err) {
    return (err.stdout || '') + (err.stderr || '') + err.message;
  }
}

async function startIsolatedPostgres() {
  console.log(`Iniciando contenedor PostgreSQL 17.6 aislado (${CONTAINER} en puerto ${PORT})...`);
  try {
    execSync(`docker rm -f ${CONTAINER}`, { stdio: 'ignore' });
  } catch (e) {}

  execSync(`docker run -d --name ${CONTAINER} -p ${PORT}:5432 -e POSTGRES_PASSWORD=postgres public.ecr.aws/supabase/postgres:17.6.1.167`);

  for (let i = 0; i < 30; i++) {
    try {
      execSync(`docker exec -i ${CONTAINER} psql -U supabase_admin -d postgres -c "SELECT 1;"`, { stdio: 'ignore' });
      break;
    } catch (e) {
      await new Promise(r => setTimeout(r, 1000));
    }
  }
  await new Promise(r => setTimeout(r, 2000));
}

async function runFinalComplianceSuite() {
  await startIsolatedPostgres();

  logHeader('BLOQUE 0 — INICIALIZACIÓN DE ESQUEMA BASE');

  runSql(`
    DROP SCHEMA IF EXISTS public CASCADE;
    CREATE SCHEMA public;
    GRANT ALL ON SCHEMA public TO postgres, supabase_admin, authenticated, anon;
    CREATE EXTENSION IF NOT EXISTS pgcrypto;
    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (
      id UUID PRIMARY KEY,
      email TEXT UNIQUE
    );

    CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid AS $$
      SELECT coalesce(nullif(current_setting('request.jwt.claim.sub', true), ''), '00000000-0000-0000-0000-000000000000')::uuid;
    $$ LANGUAGE sql STABLE;

    CREATE TABLE IF NOT EXISTS public.tenants (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      nombre TEXT NOT NULL,
      nit TEXT,
      activo BOOLEAN DEFAULT true,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.profiles (
      id UUID PRIMARY KEY,
      tenant_id UUID REFERENCES public.tenants(id),
      full_name TEXT NOT NULL,
      role TEXT NOT NULL,
      registro_medico TEXT,
      especialidad TEXT,
      activo BOOLEAN DEFAULT true,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.audit_logs (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID REFERENCES public.tenants(id),
      user_id UUID,
      action TEXT NOT NULL,
      target_type TEXT,
      target_id TEXT,
      details JSONB,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE OR REPLACE FUNCTION public.get_user_tenant_id() RETURNS uuid AS $$
      SELECT p.tenant_id FROM public.profiles p WHERE p.id = auth.uid();
    $$ LANGUAGE sql STABLE SECURITY DEFINER;

    CREATE OR REPLACE FUNCTION public.is_active_user() RETURNS boolean AS $$
      SELECT EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.activo IS TRUE);
    $$ LANGUAGE sql STABLE SECURITY DEFINER;

    CREATE OR REPLACE FUNCTION public.is_superadmin() RETURNS boolean AS $$
      SELECT EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND lower(trim(p.role)) = 'superadmin' AND p.activo IS TRUE);
    $$ LANGUAGE sql STABLE SECURITY DEFINER;

    CREATE TABLE IF NOT EXISTS public.sucursales (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      nombre TEXT NOT NULL,
      direccion TEXT,
      telefono TEXT,
      activo BOOLEAN DEFAULT true
    );

    CREATE TABLE IF NOT EXISTS public.profesionales (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      nombre_completo TEXT NOT NULL,
      especialidad TEXT,
      registro_medico TEXT,
      activo BOOLEAN DEFAULT true
    );

    CREATE TABLE IF NOT EXISTS public.pacientes (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      tipo_documento TEXT NOT NULL,
      documento TEXT NOT NULL,
      nombres TEXT NOT NULL,
      apellidos TEXT NOT NULL,
      genero TEXT,
      fecha_nacimiento DATE,
      telefono TEXT,
      email TEXT,
      direccion TEXT,
      ciudad TEXT,
      activo BOOLEAN DEFAULT true,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.documentos_clinicos (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      paciente_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      tipo TEXT NOT NULL,
      firmado BOOLEAN DEFAULT false,
      contenido TEXT,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.odontogramas (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      paciente_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      hallazgos JSONB,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.treatment_plans (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      paciente_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      nombre TEXT,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.saldos_favor (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      paciente_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      monto NUMERIC DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS public.patient_portal_sessions (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      patient_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      pin TEXT
    );

    CREATE TABLE IF NOT EXISTS public.evoluciones (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      paciente_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      profesional_id UUID REFERENCES public.profesionales(id),
      diagnostico TEXT,
      tratamiento TEXT,
      notas TEXT,
      procedimiento_cups TEXT,
      fecha TIMESTAMPTZ DEFAULT clock_timestamp(),
      status TEXT DEFAULT 'borrador',
      created_by UUID,
      closed_at TIMESTAMPTZ,
      closed_by UUID,
      closed_snapshot JSONB,
      content_hash TEXT,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );
  `);

  console.log('Aplicando migraciones secuenciales de interoperabilidad...');

  const migrations = [
    '20261012_ihce_microphase_1_safe_normalization.sql',
    '20261012_clinical_data_least_privilege_v2.sql',
    '20261012_ihce_transactional_outbox_queue.sql',
    '20261012_ihce_phase2_credentials_and_worker.sql',
    '20261012_ihce_phase3_advanced_security_and_resilience.sql',
    '20261012_ihce_final_minsalud_compliance.sql'
  ];

  for (const migFile of migrations) {
    const fullPath = path.join(__dirname, '..', 'supabase', 'migrations', migFile);
    const sql = fs.readFileSync(fullPath, 'utf8');
    runSql(sql);
    console.log(`  ✓ Migración aplicada: ${migFile}`);
  }

  runSql(`
    GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
    GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated;
    GRANT ALL ON ALL ROUTINES IN SCHEMA public TO authenticated;
  `);

  assert(true, 'Todas las migraciones de IHCE se aplicaron sin errores en PostgreSQL 17.6.');

  // Sembrar datos de prueba para dos clínicas aisladas
  const apoloTenantId = '11111111-1111-1111-1111-111111111111';
  const apoloAdminId = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';
  const apoloDoctorId = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb';
  const apoloSecId = 'cccccccc-cccc-cccc-cccc-cccccccccccc';

  const borealTenantId = '22222222-2222-2222-2222-222222222222';
  const borealAdminId = 'dddddddd-dddd-dddd-dddd-dddddddddddd';

  const superadminId = '99999999-9999-9999-9999-999999999999';

  runSql(`
    INSERT INTO auth.users (id, email) VALUES
      ('${apoloAdminId}', 'admin@apolo.com'),
      ('${apoloDoctorId}', 'dr.apolo@apolo.com'),
      ('${apoloSecId}', 'recepcion@apolo.com'),
      ('${borealAdminId}', 'admin@boreal.com'),
      ('${superadminId}', 'soporte@odontocloudsaas.com')
    ON CONFLICT DO NOTHING;

    INSERT INTO public.tenants (id, nombre, nit) VALUES
      ('${apoloTenantId}', 'Clínica Dental Apolo', '900111222-1'),
      ('${borealTenantId}', 'Centro Odontológico Boreal', '900333444-2');

    INSERT INTO public.profiles (id, tenant_id, full_name, role) VALUES
      ('${apoloAdminId}', '${apoloTenantId}', 'Admin Apolo', 'admin'),
      ('${apoloDoctorId}', '${apoloTenantId}', 'Dra. Carolina Restrepo', 'odontologo'),
      ('${apoloSecId}', '${apoloTenantId}', 'Recepcionista Apolo', 'secretaria'),
      ('${borealAdminId}', '${borealTenantId}', 'Admin Boreal', 'admin'),
      ('${superadminId}', NULL, 'Soporte OdontoCloud Superadmin', 'superadmin');

    INSERT INTO public.profesionales (id, tenant_id, nombre_completo, especialidad, registro_medico) VALUES
      ('${apoloDoctorId}', '${apoloTenantId}', 'Dra. Carolina Restrepo', 'Odontología General', 'OD-19827');
  `);

  // =========================================================================
  // BLOQUE 1 — COMPATIBILIDAD EXACTA CON MINSALUD
  // =========================================================================
  logHeader('BLOQUE 1 — COMPATIBILIDAD EXACTA CON MINSALUD (Manual v1.3)');

  const mockServer = new IhceMockNationalServer({ mode: 'DYNAMIC' });
  const connector = new IhceNationalConnector({ mockServer });

  // 1.1 Verificación de cabeceras obligatorias y token
  const sampleBundle = JSON.parse(fs.readFileSync(path.join(__dirname, 'samples', 'test_rda_consulta_externa_odontologia.json'), 'utf8'));

  const credsApolo = {
    tenantId: apoloTenantId,
    clientId: 'cliente-apolo-id',
    clientSecret: 'secret-apolo-real',
    repsCode: '110010998801',
    apimSubscriptionKey: 'azure-apim-key-12345'
  };

  const submitRes = await connector.submitRdaBundle({
    bundle: sampleBundle,
    credentials: credsApolo,
    idempotencyKey: 'idem-hash-test-01'
  });

  assert(submitRes.success === true && submitRes.status === 'ACEPTADO', 'Envío exitoso procesado con radicado oficial (200/201).');
  assert(submitRes.radicado.startsWith('RAD-'), 'Radicado asignado cumple con nomenclatura oficial.');

  // 1.2 Rechazo por falta de APIM key
  const credsNoApim = { ...credsApolo, apimSubscriptionKey: '' };
  mockServer.setMode('DYNAMIC');
  const resNoApim = await connector.submitRdaBundle({
    bundle: sampleBundle,
    credentials: credsNoApim,
    idempotencyKey: 'idem-no-apim'
  });
  assert(resNoApim.httpStatus === 403 && resNoApim.status === 'ERROR_DEFINITIVO', 'Petición rechazada con HTTP 403 cuando falta Ocp-Apim-Subscription-Key.');

  // 1.3 Tratamiento de respuestas HTTP normativas
  // 400 Bad Request
  mockServer.setMode('BAD_REQUEST_400');
  const res400 = await connector.submitRdaBundle({ bundle: sampleBundle, credentials: credsApolo });
  assert(res400.httpStatus === 400 && res400.status === 'RECHAZADO' && res400.isTerminal === true, 'HTTP 400 clasificado como RECHAZADO terminal sin reintentos.');

  // 401 Unauthorized (Renovación de token)
  mockServer.setMode('UNAUTHORIZED_401');
  const res401 = await connector.submitRdaBundle({ bundle: sampleBundle, credentials: credsApolo });
  assert(res401.httpStatus === 401 && res401.status === 'ERROR_REINTENTO' && res401.isTerminal === false, 'HTTP 401 clasificado como ERROR_REINTENTO con invalidación de caché de token.');

  // 409 Conflict (RDA Duplicado resuelto)
  mockServer.setMode('CONFLICT_409');
  const res409 = await connector.submitRdaBundle({ bundle: sampleBundle, credentials: credsApolo });
  assert(res409.httpStatus === 409 && res409.status === 'ACEPTADO' && res409.isTerminal === true, 'HTTP 409 Conflict reconocido como ACEPTADO duplicado (evita bucles infinitos).');

  // 422 Unprocessable Entity
  mockServer.setMode('UNPROCESSABLE_422');
  const res422 = await connector.submitRdaBundle({ bundle: sampleBundle, credentials: credsApolo });
  assert(res422.httpStatus === 422 && res422.status === 'RECHAZADO' && res422.isTerminal === true, 'HTTP 422 clasificado como RECHAZADO terminal por regla clínica/semántica.');

  // 429 Rate Limit
  mockServer.setMode('RATE_LIMITED_429');
  const res429 = await connector.submitRdaBundle({ bundle: sampleBundle, credentials: credsApolo });
  assert(res429.httpStatus === 429 && res429.status === 'ERROR_REINTENTO' && res429.retryAfterSeconds === 30, 'HTTP 429 clasificado como ERROR_REINTENTO respetando Retry-After.');

  // 503 Service Unavailable
  mockServer.setMode('SERVICE_UNAVAILABLE_503');
  const res503 = await connector.submitRdaBundle({ bundle: sampleBundle, credentials: credsApolo });
  assert(res503.httpStatus === 503 && res503.status === 'ERROR_REINTENTO', 'HTTP 503 clasificado como transitorio reintentable.');

  // 1.4 Consulta de RDA de paciente ($consultar-rda-paciente)
  mockServer.setMode('DYNAMIC');
  const consultaPacienteRes = await connector.consultarRdaPaciente('CC', '1098765432', credsApolo);
  assert(consultaPacienteRes.success === true && consultaPacienteRes.bundle?.resourceType === 'Bundle', 'Operación $consultar-rda-paciente ejecutada y mapeada correctamente.');

  // =========================================================================
  // BLOQUE 2 — SEGURIDAD FINAL
  // =========================================================================
  logHeader('BLOQUE 2 — SEGURIDAD FINAL Y PROTECCIÓN CRIPTOGRÁFICA');

  // 2.1 Write-Only Secrets y enmascaramiento en secure_view
  runSql(`
    SET "request.jwt.claim.sub" = '${apoloAdminId}';
    SELECT public.save_clinic_ihce_configuration(
      '110010998801',
      '01',
      'Clínica Apolo',
      '900111222-1',
      'SANDBOX_MOCK',
      'cliente-apolo-id',
      'ultra-secret-key-12345',
      true,
      true,
      'azure-subscription-apim-9999'
    );
  `);

  const viewOutput = runSql(`
    SET "request.jwt.claim.sub" = '${apoloAdminId}';
    SELECT client_secret_masked, has_secret, apim_subscription_key_masked, has_apim_key 
    FROM public.ihce_configurations_secure_view;
  `);

  assert(viewOutput.includes('••••••••••••••••'), 'client_secret y apim_subscription_key retornan enmascarados como "••••••••••••••••" en la vista segura.');
  assert(viewOutput.includes('| t          |') || viewOutput.includes('| true       |') || viewOutput.includes('t'), 'has_secret y has_apim_key reportan true sin exponer el texto plano.');

  // 2.2 Protección contra fuerza bruta en firma clínica
  const evoId = 'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee';
  const pacienteId = 'ffffffff-ffff-ffff-ffff-ffffffffffff';

  runSql(`
    INSERT INTO public.pacientes (id, tenant_id, nombres, apellidos, tipo_documento, documento)
    VALUES ('${pacienteId}', '${apoloTenantId}', 'Carlos', 'Mendoza', 'CC', '79888999');

    INSERT INTO public.evoluciones (id, tenant_id, paciente_id, profesional_id, diagnostico, cie10_principal_codigo, status)
    VALUES ('${evoId}', '${apoloTenantId}', '${pacienteId}', '${apoloDoctorId}', 'Gingivitis marginal', 'K05.0', 'abierta');
  `);

  // Intentos fallidos con PIN demasiado corto o inválido
  console.log('Probando protección de fuerza bruta en firma de evolución...');
  for (let i = 1; i <= 5; i++) {
    const errRes = runSqlQuiet(`
      SET "request.jwt.claim.sub" = '${apoloDoctorId}';
      SELECT public.verify_and_close_evolution('${evoId}', '12');
    `);
    assert(errRes.includes('INVALID_SIGNATURE_CREDENTIAL'), `Intento fallido ${i} rechazado por credencial inválida.`);
  }

  // 6to intento debe ser bloqueado con SIGNATURE_LOCKED
  const errResLocked = runSqlQuiet(`
    SET "request.jwt.claim.sub" = '${apoloDoctorId}';
    SELECT public.verify_and_close_evolution('${evoId}', '12');
  `);
  assert(errResLocked.includes('SIGNATURE_LOCKED'), 'Bloqueo por fuerza bruta activado: SIGNATURE_LOCKED tras 5 fallos consecutivos.');

  // Liberar bloqueo para probar firma válida
  runSql(`
    UPDATE public.clinical_signature_attempts 
    SET intentos_fallidos = 0, bloqueado_hasta = NULL 
    WHERE user_id = '${apoloDoctorId}';
  `);

  const signSuccess = runSql(`
    SET "request.jwt.claim.sub" = '${apoloDoctorId}';
    SELECT public.verify_and_close_evolution('${evoId}', 'PinSeguro2026!');
  `);
  assert(signSuccess.includes('"success": true') && signSuccess.includes('content_hash'), 'Firma clínica exitosa con PIN válido genera sellado SHA-256 e inmutabilidad.');

  // 2.3 Rechazo de firma por personal no clínico (Secretaria)
  const evo2Id = crypto.randomUUID();
  runSql(`
    INSERT INTO public.evoluciones (id, tenant_id, paciente_id, profesional_id, diagnostico, status)
    VALUES ('${evo2Id}', '${apoloTenantId}', '${pacienteId}', '${apoloDoctorId}', 'Control', 'abierta');
  `);

  const secSignErr = runSqlQuiet(`
    SET "request.jwt.claim.sub" = '${apoloSecId}';
    SELECT public.verify_and_close_evolution('${evo2Id}', 'PinValido123!');
  `);
  assert(secSignErr.includes('FORBIDDEN_ROLE'), 'Firma rechazada para usuario sin rol clínico (FORBIDDEN_ROLE).');

  // 2.4 Protocolo Break-Glass: Doble Control Estricto
  console.log('Probando protocolo Break-Glass con doble control...');
  const bgReqRes = runSql(`
    SET "request.jwt.claim.sub" = '${superadminId}';
    SELECT public.request_support_break_glass(
      '${pacienteId}'::uuid,
      'Auditoría judicial urgente requerimiento fiscalía No. 4921',
      'TICKET-SEC-882'
    ) as res;
  `);
  assert(bgReqRes.includes('PENDIENTE_APROBACION'), 'Solicitud ordinaria de Break-Glass queda en estado PENDIENTE_APROBACION.');

  // Verificar que el Superadmin NO tiene acceso mientras esté pendiente (RLS retorna 0)
  const bgDenied = runSql(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${superadminId}';
    SELECT count(*) as count FROM public.pacientes WHERE id = '${pacienteId}';
  `);
  assert(bgDenied.includes('0'), 'Superadmin no tiene acceso a datos del paciente mientras la sesión esté pendiente (conteo = 0).');

  // Administrador de la clínica aprueba la solicitud
  const bgApprove = runSql(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${apoloAdminId}';
    SELECT public.approve_break_glass_request(
      (SELECT id FROM public.clinical_break_glass_sessions WHERE paciente_id = '${pacienteId}' AND estado = 'PENDIENTE_APROBACION' LIMIT 1)
    ) as res;
  `);
  assert(bgApprove.includes('"status": "ACTIVA"'), 'Administrador de la clínica aprueba formalmente la sesión de Break-Glass.');

  // Ahora el Superadmin sí tiene acceso temporal acotado (RLS retorna 1)
  const bgAllowed = runSql(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${superadminId}';
    SELECT count(*) as count FROM public.pacientes WHERE id = '${pacienteId}';
  `);
  assert(bgAllowed.includes('1'), 'Superadmin autorizado temporalmente tras aprobación del Administrador de la clínica (conteo = 1).');

  // Administrador de la clínica revoca la sesión
  const bgRevokeRes = runSql(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${apoloAdminId}';
    SELECT public.revoke_break_glass_session(
      (SELECT id FROM public.clinical_break_glass_sessions WHERE paciente_id = '${pacienteId}' AND estado = 'ACTIVA' LIMIT 1),
      'Incidencia técnica resuelta satisfactoriamente.'
    ) as res;
  `);
  assert(bgRevokeRes.includes('"estado": "REVOCADA"'), 'Acceso de Break-Glass revocado inmediatamente por el Administrador de la clínica.');

  const bgRevokedCheck = runSql(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${superadminId}';
    SELECT count(*) as count FROM public.pacientes WHERE id = '${pacienteId}';
  `);
  assert(bgRevokedCheck.includes('0'), 'Superadmin pierde el acceso inmediatamente tras revocación (conteo = 0).');

  // 2.5 Aislamiento Multi-Tenant Estricto
  const crossTenantRes = runSql(`
    SET ROLE authenticated;
    SET "request.jwt.claim.sub" = '${borealAdminId}';
    SELECT count(*) as count FROM public.evoluciones WHERE tenant_id = '${apoloTenantId}';
  `);
  assert(crossTenantRes.includes('0'), 'Clínica Boreal no puede leer evoluciones de Clínica Apolo (Aislamiento RLS multi-tenant, conteo = 0).');

  // 2.6 Verificación de Salvaguarda Absoluta de No-Emisión Externa
  assert(IHCE_LIVE_ENABLED === false, 'Bandera de seguridad IHCE_LIVE_ENABLED = false estrictamente activa en el código fuente.');

  logHeader('RESUMEN DE PRUEBAS DE CIERRE TÉCNICO');
  console.log(`Total de pruebas ejecutadas: ${totalTests}`);
  console.log(`Pruebas aprobadas:          ${passedTests}`);
  console.log(`Pruebas fallidas:           ${totalTests - passedTests}`);
  assert(passedTests === totalTests, 'Todas las pruebas pasaron satisfactoriamente.');
}

runFinalComplianceSuite()
  .then(() => {
    console.log('\n[LIMPIEZA] Eliminando contenedor sandbox de pruebas...');
    try {
      execSync(`docker rm -f ${CONTAINER}`, { stdio: 'ignore' });
    } catch (e) {}
    console.log('[COMPLETO] Entorno aislado limpio sin residuos.\n');
    process.exit(0);
  })
  .catch((err) => {
    console.error('\n[ERROR EN SUITE]:', err.message);
    try {
      execSync(`docker rm -f ${CONTAINER}`, { stdio: 'ignore' });
    } catch (e) {}
    process.exit(1);
  });
