/**
 * Script de Generación y Validación de Ejemplos Sintéticos FHIR R4 para MinSalud IHCE
 * 
 * Genera:
 * 1. scripts/samples/test_rda_consulta_externa_odontologia.json
 * 2. scripts/samples/test_rda_paciente.json
 * 
 * Ejecuta la validación sintáctica y semántica oficial local con validateRdaBundle.
 */

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

import {
  buildRdaConsultaExternaBundle,
  validateRdaBundle
} from '../src/services/ihce/ihceBundleBuilder.js';
import { FHIR_SYSTEMS } from '../src/services/ihce/ihceConstants.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SAMPLES_DIR = path.join(__dirname, 'samples');

console.log('=============================================================================');
console.log(' GENERADOR Y VALIDADOR DE MUESTRAS SINTÉTICAS FHIR R4 / RDA MINSALUD');
console.log('=============================================================================');

// 1. DATOS SINTÉTICOS DE CONSULTA EXTERNA ODONTOLÓGICA
const syntheticEvolution = {
  id: 'e9b1c7a2-4412-4f33-8a9d-b827e8a91001',
  fecha: '2026-10-11T14:30:00.000Z',
  closed_at: '2026-10-11T14:45:00.000Z',
  diagnostico: 'Caries de la dentina en órgano dental 46',
  cie10_principal_codigo: 'K02.1',
  cie10_principal_tipo: 2, // Confirmado nuevo
  cups_codigo: '230101', // Obturación dental con resina de fotocurado
  causa_externa: '13', // Enfermedad general
  finalidad_consulta: '10', // No aplica / Diagnóstica y terapéutica
  modalidad_atencion: '01', // Intramural
  notas: 'Paciente acude por molestia a estímulos térmicos en pieza 46. Se realiza apertura cavitaria, remoción de tejido cariado y obturación con resina compuesta nano-híbrida con grabado total. Oclusión ajustada y pulido finalizado.'
};

const syntheticPatient = {
  id: 'p1098765-1122-3344-5566-778899aabbcc',
  tipo_documento: 'CC',
  documento: '1098765432',
  nombres: 'JUAN CARLOS',
  apellidos: 'ORTEGA HERNANDEZ',
  fecha_nacimiento: '1992-06-24',
  genero: 'M',
  telefono: '3128901234',
  direccion: 'Calle 127 # 19-35 Apto 402',
  ciudad_codigo: '11001',
  departamento_codigo: '11',
  pertenencia_etnica_codigo: '6'
};

const syntheticPractitioner = {
  id: 'dr5289012-aabb-ccdd-eeff-001122334455',
  nombres: 'CAROLINA',
  apellidos: 'RESTREPO CARDONA',
  tipo_documento: 'CC',
  numero_documento: '52890123',
  registro_medico: 'OD-19827-BOG',
  especialidad: 'Odontología General',
  codigo_rethus: 'RETHUS-OD-52890123'
};

const syntheticOrganization = {
  id: 'org-110010998801',
  nombre: 'CENTRO ODONTOLÓGICO ODONTOCLOUD IPS SAS',
  nit: '901456789-2',
  reps_codigo: '110010998801'
};

const syntheticBranch = {
  codigo_sede: '01',
  nombre_sede: 'Sede Principal Chicó Navarra',
  direccion: 'Carrera 15 # 98-40 Consultorio 402',
  municipio_codigo: '11001'
};

const syntheticMedications = [
  {
    codigo_cum: '19928192-1',
    nombre: 'Ibuprofeno 400mg cápsulas blandas',
    forma_farmaceutica: 'Cápsula',
    dosis: '400 mg cada 8 horas por 3 días si hay dolor'
  }
];

const syntheticAllergies = [
  {
    codigo: 'Z88.0',
    descripcion: 'Alergia a la Penicilina',
    criticidad: 'high'
  }
];

// Generar RDA Consulta Externa
console.log('\n[1/2] Generando RDA de Consulta Externa Odontológica...');
const rdaConsultaBundle = buildRdaConsultaExternaBundle({
  evolution: syntheticEvolution,
  patient: syntheticPatient,
  practitioner: syntheticPractitioner,
  organization: syntheticOrganization,
  branch: syntheticBranch,
  medications: syntheticMedications,
  allergies: syntheticAllergies
});

const validationConsulta = validateRdaBundle(rdaConsultaBundle);
console.log(`  - Resultado Validación Consulta Externa: ${validationConsulta.valid ? 'VALIDO' : 'INVALIDO'}`);
if (!validationConsulta.valid) {
  console.error('  - Errores:', validationConsulta.errors);
  process.exit(1);
}

const consultaPath = path.join(SAMPLES_DIR, 'test_rda_consulta_externa_odontologia.json');
fs.writeFileSync(consultaPath, JSON.stringify(rdaConsultaBundle, null, 2), 'utf8');
console.log(`  ✓ Guardado: ${consultaPath} (${fs.statSync(consultaPath).size} bytes, ${rdaConsultaBundle.entry.length} recursos FHIR)`);

// 2. GENERAR RDA DE PACIENTE SINTÉTICO (Resumen Digital de Historia del Paciente)
console.log('\n[2/2] Generando RDA de Paciente Sintético...');

const patientUrn = `urn:uuid:${crypto.randomUUID()}`;
const practitionerUrn = `urn:uuid:${crypto.randomUUID()}`;
const orgUrn = `urn:uuid:${crypto.randomUUID()}`;
const compositionUrn = `urn:uuid:${crypto.randomUUID()}`;

const rdaPacienteBundle = {
  resourceType: 'Bundle',
  id: 'bundle-rda-paciente-1098765432',
  meta: {
    profile: [
      'https://minsalud.gov.co/fhir/StructureDefinition/Bundle-Rda-Paciente-Co'
    ],
    lastUpdated: new Date().toISOString()
  },
  identifier: {
    system: 'https://odontocloudcolombia.com/ihce/rda-paciente',
    value: `RDA-PACIENTE-${syntheticPatient.documento}`
  },
  type: 'document',
  timestamp: new Date().toISOString(),
  entry: [
    {
      fullUrl: compositionUrn,
      resource: {
        resourceType: 'Composition',
        id: 'comp-rda-paciente-01',
        meta: {
          profile: [
            'https://minsalud.gov.co/fhir/StructureDefinition/Composition-Rda-Paciente-Co'
          ]
        },
        status: 'final',
        type: {
          coding: [
            {
              system: FHIR_SYSTEMS.LOINC,
              code: '81217-2',
              display: 'Dental Summary note'
            }
          ],
          text: 'Resumen Digital de Atención Odontológica del Paciente'
        },
        category: [
          {
            coding: [
              {
                system: 'http://hl7.org/fhir/us/core/CodeSystem/us-core-documentreference-category',
                code: 'clinical-note'
              }
            ]
          }
        ],
        subject: {
          reference: patientUrn
        },
        date: new Date().toISOString(),
        author: [
          {
            reference: practitionerUrn
          }
        ],
        title: 'RDA Paciente Odontológico - Histórico Consolidado',
        custodian: {
          reference: orgUrn
        },
        section: [
          {
            title: 'Antecedentes Alérgicos',
            code: {
              coding: [{
                system: FHIR_SYSTEMS.LOINC,
                code: '48765-2',
                display: 'Allergies and adverse reactions'
              }]
            },
            text: {
              status: 'generated',
              div: '<div xmlns="http://www.w3.org/1999/xhtml"><p>Alergia confirmada a la Penicilina.</p></div>'
            }
          },
          {
            title: 'Plan de Tratamiento Activo',
            code: {
              coding: [{
                system: FHIR_SYSTEMS.LOINC,
                code: '18776-5',
                display: 'Plan of care note'
              }]
            },
            text: {
              status: 'generated',
              div: '<div xmlns="http://www.w3.org/1999/xhtml"><p>Fase 1: Higiene y profilaxis. Fase 2: Restauraciones 46 y 37.</p></div>'
            }
          }
        ]
      }
    },
    {
      fullUrl: patientUrn,
      resource: {
        resourceType: 'Patient',
        id: syntheticPatient.id,
        meta: {
          profile: [FHIR_SYSTEMS.PROFILE_PATIENT]
        },
        identifier: [
          {
            use: 'official',
            system: FHIR_SYSTEMS.IDENTIFICACION_USUARIO,
            type: {
              coding: [{
                system: FHIR_SYSTEMS.TIPO_DOCUMENTO_MINSALUD,
                code: syntheticPatient.tipo_documento,
                display: 'Cédula de Ciudadanía'
              }]
            },
            value: syntheticPatient.documento
          }
        ],
        active: true,
        name: [
          {
            use: 'official',
            text: `${syntheticPatient.nombres} ${syntheticPatient.apellidos}`,
            family: syntheticPatient.apellidos,
            given: [syntheticPatient.nombres]
          }
        ],
        gender: 'male',
        birthDate: syntheticPatient.fecha_nacimiento
      }
    },
    {
      fullUrl: practitionerUrn,
      resource: {
        resourceType: 'Practitioner',
        id: syntheticPractitioner.id,
        meta: {
          profile: [FHIR_SYSTEMS.PROFILE_PRACTITIONER]
        },
        identifier: [
          {
            system: FHIR_SYSTEMS.IDENTIFICACION_USUARIO,
            value: syntheticPractitioner.numero_documento
          }
        ],
        name: [
          {
            text: `${syntheticPractitioner.nombres} ${syntheticPractitioner.apellidos}`
          }
        ]
      }
    },
    {
      fullUrl: orgUrn,
      resource: {
        resourceType: 'Organization',
        id: syntheticOrganization.id,
        meta: {
          profile: [FHIR_SYSTEMS.PROFILE_ORGANIZATION]
        },
        identifier: [
          {
            system: FHIR_SYSTEMS.CODIGO_HABILITACION_REPS,
            value: syntheticOrganization.reps_codigo
          }
        ],
        name: syntheticOrganization.nombre
      }
    }
  ]
};

const validationPaciente = validateRdaBundle(rdaPacienteBundle);
console.log(`  - Resultado Validación Paciente: ${validationPaciente.valid ? 'VALIDO' : 'INVALIDO'}`);
if (!validationPaciente.valid) {
  console.error('  - Errores:', validationPaciente.errors);
  process.exit(1);
}

const pacientePath = path.join(SAMPLES_DIR, 'test_rda_paciente.json');
fs.writeFileSync(pacientePath, JSON.stringify(rdaPacienteBundle, null, 2), 'utf8');
console.log(`  ✓ Guardado: ${pacientePath} (${fs.statSync(pacientePath).size} bytes, ${rdaPacienteBundle.entry.length} recursos FHIR)`);

console.log('\n=============================================================================');
console.log(' VALIDACIÓN FHIR COMPLETADA EXITOSAMENTE');
console.log(' Ambos archivos generados cumplen con las reglas HL7 FHIR R4 de Documento.');
console.log(' NOTA DE CONFORMIDAD: La validación interna garantiza compatibilidad sintáctica,');
console.log(' pero NO reemplaza la certificación oficial ministerial en Vulcano.');
console.log('=============================================================================');
