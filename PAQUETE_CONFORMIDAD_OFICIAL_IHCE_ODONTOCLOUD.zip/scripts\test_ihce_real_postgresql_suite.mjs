/**
 * =============================================================================
 * ODONTOCLOUD — SUITE DE PRUEBAS INTEGRAL DE FASE 1 EN POSTGRESQL 17.6 REAL
 * Archivo: scripts/test_ihce_real_postgresql_suite.mjs
 * =============================================================================
 * Ejecuta la suite de pruebas completa sobre el contenedor aislado y nuevo
 * 'odontocloud-dev-ihce-sandbox' (PostgreSQL 17.6 Oficial de Supabase).
 * 
 * COBERTURA DE PRUEBAS OBLIGATORIAS:
 *   1. Aplicación de las 3 migraciones de Fase 1.
 *   2. Creación de 2 clínicas ficticias aisladas (Apolo y Boreal).
 *   3. Pruebas de permisos RLS y aislamiento multi-tenant estricto.
 *   4. Bloqueo de Superadmin a datos clínicos (Least Privilege).
 *   5. Protocolo de acceso de emergencia Break-Glass auditado en audit_logs.
 *   6. Protección contra DELETE de pacientes con historia clínica (RESTRICT).
 *   7. Cierre clínico inmutable con hash SHA-256 de firma.
 *   8. Encolamiento atómico en ihce_outbox_queue vía trigger.
 *   9. Idempotencia y prevención de duplicados.
 *   10. Simulación de respuestas de Minsalud (Aceptado 201, Rechazado 422, Reintento 503).
 *   11. Generación y validación del Bundle HL7 FHIR R4 oficial de Consulta Odontológica.
 * 
 * SEGURIDAD ABSOLUTA:
 * - Cero conexiones al VPS de producción.
 * - Cero impacto en Escolaria ni en contenedores existentes.
 * - Cero datos reales de pacientes (100% datos sintéticos).
 * =============================================================================
 */

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { buildRdaConsultaExternaBundle, validateRdaBundle } from '../src/services/ihce/ihceBundleBuilder.js';
import { processQueueItem, MockVulcanoClient } from '../src/services/ihce/ihceQueueService.js';

const CONTAINER = 'odontocloud-dev-ihce-sandbox';
let totalTests = 0;
let passedTests = 0;

function logHeader(title) {
  console.log(`\n=============================================================================`);
  console.log(` ${title}`);
  console.log(`=============================================================================`);
}

function assert(condition, message) {
  totalTests++;
  if (condition) {
    console.log(`  ✓ [PASS] ${message}`);
    passedTests++;
  } else {
    console.error(`  ✗ [FAIL] ${message}`);
    throw new Error(`Fallo de prueba: ${message}`);
  }
}

function runSql(sql) {
  // Ejecuta SQL directamente contra el contenedor aislado como superuser supabase_admin
  return execSync(`docker exec -i ${CONTAINER} psql -U supabase_admin -d postgres -v ON_ERROR_STOP=1`, {
    input: sql,
    encoding: 'utf8'
  });
}

function runSqlQuiet(sql) {
  try {
    return runSql(sql);
  } catch (err) {
    return err.stdout || err.stderr || err.message;
  }
}

async function runPhase1RealDatabaseSuite() {
  logHeader('FASE 1: PREPARACIÓN DE ESQUEMA BASE Y EXTENSIONES EN POSTGRESQL 17.6');

  // Limpiar esquema en el sandbox para asegurar repetibilidad
  runSql(`
    DROP SCHEMA IF EXISTS public CASCADE;
    CREATE SCHEMA public;
    GRANT ALL ON SCHEMA public TO postgres, supabase_admin, authenticated, anon;
    CREATE EXTENSION IF NOT EXISTS pgcrypto;
    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (
      id UUID PRIMARY KEY,
      email TEXT
    );
    TRUNCATE auth.users CASCADE;
  `);
  assert(true, 'Extensiones pgcrypto y esquema auth configurados');

  // 2. Crear infraestructura base simulada de Supabase
  runSql(`
    -- Contexto de sesión simulada para RLS
    CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid AS $$
      SELECT coalesce(nullif(current_setting('request.jwt.claim.sub', true), ''), '00000000-0000-0000-0000-000000000000')::uuid;
    $$ LANGUAGE sql STABLE;

    -- Tablas estructurales
    CREATE TABLE IF NOT EXISTS public.tenants (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      nombre TEXT NOT NULL,
      nit TEXT,
      activo BOOLEAN DEFAULT true,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.profiles (
      id UUID PRIMARY KEY,
      tenant_id UUID REFERENCES public.tenants(id),
      full_name TEXT NOT NULL,
      role TEXT NOT NULL,
      registro_medico TEXT,
      especialidad TEXT,
      activo BOOLEAN DEFAULT true,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.audit_logs (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID REFERENCES public.tenants(id),
      user_id UUID,
      action TEXT NOT NULL,
      target_type TEXT,
      target_id TEXT,
      details JSONB,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    -- Funciones auxiliares de tenant y RLS
    CREATE OR REPLACE FUNCTION public.get_user_tenant_id() RETURNS uuid AS $$
      SELECT p.tenant_id FROM public.profiles p WHERE p.id = auth.uid();
    $$ LANGUAGE sql STABLE SECURITY DEFINER;

    CREATE OR REPLACE FUNCTION public.is_active_user() RETURNS boolean AS $$
      SELECT EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.activo IS TRUE);
    $$ LANGUAGE sql STABLE SECURITY DEFINER;

    CREATE OR REPLACE FUNCTION public.is_superadmin() RETURNS boolean AS $$
      SELECT EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND lower(trim(p.role)) = 'superadmin' AND p.activo IS TRUE);
    $$ LANGUAGE sql STABLE SECURITY DEFINER;

    -- Tablas clínicas base
    CREATE TABLE IF NOT EXISTS public.sucursales (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      nombre TEXT NOT NULL,
      direccion TEXT,
      telefono TEXT,
      activo BOOLEAN DEFAULT true
    );

    CREATE TABLE IF NOT EXISTS public.profesionales (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      nombre_completo TEXT NOT NULL,
      especialidad TEXT,
      registro_medico TEXT,
      activo BOOLEAN DEFAULT true
    );

    CREATE TABLE IF NOT EXISTS public.pacientes (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      tipo_documento TEXT NOT NULL,
      documento TEXT NOT NULL,
      nombres TEXT NOT NULL,
      apellidos TEXT NOT NULL,
      genero TEXT,
      fecha_nacimiento DATE,
      telefono TEXT,
      email TEXT,
      direccion TEXT,
      ciudad TEXT,
      activo BOOLEAN DEFAULT true,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.documentos_clinicos (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      paciente_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      tipo TEXT NOT NULL,
      firmado BOOLEAN DEFAULT false,
      contenido TEXT,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.odontogramas (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      paciente_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      hallazgos JSONB,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.treatment_plans (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      paciente_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      nombre TEXT,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.saldos_favor (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      paciente_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      monto NUMERIC DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS public.patient_portal_sessions (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      patient_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      pin TEXT
    );

    CREATE TABLE IF NOT EXISTS public.evoluciones (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      paciente_id UUID NOT NULL REFERENCES public.pacientes(id) ON DELETE CASCADE,
      profesional_id UUID REFERENCES public.profesionales(id),
      diagnostico TEXT,
      tratamiento TEXT,
      notas TEXT,
      procedimiento_cups TEXT,
      fecha TIMESTAMPTZ DEFAULT clock_timestamp(),
      status TEXT DEFAULT 'borrador',
      created_by UUID,
      closed_at TIMESTAMPTZ,
      closed_by UUID,
      closed_snapshot JSONB,
      content_hash TEXT,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    CREATE TABLE IF NOT EXISTS public.evolution_addenda (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      evolution_id UUID NOT NULL REFERENCES public.evoluciones(id),
      tenant_id UUID NOT NULL REFERENCES public.tenants(id),
      author_id UUID NOT NULL,
      comentario TEXT NOT NULL,
      content_hash TEXT,
      created_at TIMESTAMPTZ DEFAULT clock_timestamp()
    );

    -- RPC de cierre de evolución con inmutabilidad SHA-256
    CREATE OR REPLACE FUNCTION public.close_evolution(p_evolution_id UUID)
    RETURNS JSONB
    LANGUAGE plpgsql
    SECURITY DEFINER
    SET search_path = public
    AS $$
    DECLARE
      v_evo RECORD;
      v_user_id UUID;
      v_snapshot JSONB;
      v_hash TEXT;
      v_closed_at TIMESTAMPTZ;
    BEGIN
      v_user_id := auth.uid();
      SELECT * INTO v_evo FROM public.evoluciones WHERE id = p_evolution_id;
      IF NOT FOUND THEN
        RAISE EXCEPTION 'EVOLUTION_NOT_FOUND: Evolución no existe.';
      END IF;

      IF v_evo.status = 'cerrada' THEN
        RAISE EXCEPTION 'EVOLUTION_ALREADY_CLOSED: La evolución ya fue cerrada.';
      END IF;

      v_closed_at := clock_timestamp();
      v_snapshot := jsonb_build_object(
        'evolution_id', v_evo.id,
        'tenant_id', v_evo.tenant_id,
        'paciente_id', v_evo.paciente_id,
        'profesional_id', v_evo.profesional_id,
        'diagnostico', v_evo.diagnostico,
        'cie10_principal_codigo', v_evo.cie10_principal_codigo,
        'cups_codigo', v_evo.cups_codigo,
        'notas', v_evo.notas,
        'closed_at', v_closed_at,
        'closed_by', v_user_id
      );

      v_hash := encode(sha256(v_snapshot::text::bytea), 'hex');

      UPDATE public.evoluciones
      SET status = 'cerrada',
          closed_at = v_closed_at,
          closed_by = v_user_id,
          closed_snapshot = v_snapshot,
          content_hash = v_hash
      WHERE id = p_evolution_id;

      RETURN jsonb_build_object('success', true, 'content_hash', v_hash, 'closed_at', v_closed_at);
    END;
    $$;

    -- Trigger de protección contra UPDATE o DELETE sobre evoluciones cerradas
    CREATE OR REPLACE FUNCTION public.trg_protect_evolution_integrity()
    RETURNS TRIGGER
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF TG_OP = 'DELETE' AND OLD.status = 'cerrada' THEN
        RAISE EXCEPTION 'EVOLUTION_IS_IMMUTABLE: No es posible eliminar una evolución cerrada.';
      END IF;
      IF TG_OP = 'UPDATE' AND OLD.status = 'cerrada' AND NEW.status = 'cerrada' AND OLD.closed_at IS NOT NULL THEN
        IF NEW.content_hash IS DISTINCT FROM OLD.content_hash OR NEW.diagnostico IS DISTINCT FROM OLD.diagnostico THEN
          RAISE EXCEPTION 'EVOLUTION_IS_IMMUTABLE: Evolución cerrada no admite modificaciones.';
        END IF;
      END IF;
      RETURN NEW;
    END;
    $$;

    DROP TRIGGER IF EXISTS trg_protect_evoluciones ON public.evoluciones;
    CREATE TRIGGER trg_protect_evoluciones
      BEFORE UPDATE OR DELETE ON public.evoluciones
      FOR EACH ROW EXECUTE FUNCTION public.trg_protect_evolution_integrity();
  `);
  assert(true, 'Esquema clínico base y funciones de inmutabilidad instalados');

  logHeader('APLICACIÓN DE LAS 3 MIGRACIONES DE FASE 1 EN POSTGRESQL REAL');

  // Leer y aplicar Migración 1: Normalización Segura
  const mig1Sql = fs.readFileSync('supabase/migrations/20261012_ihce_microphase_1_safe_normalization.sql', 'utf8');
  runSql(mig1Sql);
  assert(true, 'Migración 1 (Normalización segura y FK RESTRICT) aplicada exitosamente');

  // Leer y aplicar Migración 2: Seguridad RLS V2 y Break-Glass
  const mig2Sql = fs.readFileSync('supabase/migrations/20261012_clinical_data_least_privilege_v2.sql', 'utf8');
  runSql(mig2Sql);
  assert(true, 'Migración 2 (RLS V2 Least Privilege y Break-Glass) aplicada exitosamente');

  // Leer y aplicar Migración 3: Cola Outbox Transaccional
  const mig3Sql = fs.readFileSync('supabase/migrations/20261012_ihce_transactional_outbox_queue.sql', 'utf8');
  runSql(mig3Sql);
  assert(true, 'Migración 3 (Cola outbox transaccional y trigger atómico) aplicada exitosamente');

  // Asegurar permisos para el rol authenticated en la base de datos de prueba
  runSql(`
    GRANT ALL ON SCHEMA public TO authenticated;
    GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
    GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated;
    GRANT ALL ON ALL FUNCTIONS IN SCHEMA public TO authenticated;
  `);

  logHeader('TEST 1: CREACIÓN DE DOS CLÍNICAS FICTICIAS Y USUARIOS CON ROLES');

  const tenantApoloId = crypto.randomUUID();
  const tenantBorealId = crypto.randomUUID();
  const doctorApoloId = crypto.randomUUID();
  const doctorBorealId = crypto.randomUUID();
  const superadminId = crypto.randomUUID();

  const pacienteApoloId = crypto.randomUUID();
  const pacienteBorealId = crypto.randomUUID();

  runSql(`
    -- Usuarios en auth.users
    INSERT INTO auth.users (id, email) VALUES
      ('${doctorApoloId}', 'elena@apolo.com'),
      ('${doctorBorealId}', 'marcos@boreal.com'),
      ('${superadminId}', 'soporte@odontocloud.com')
    ON CONFLICT (id) DO NOTHING;

    -- Clínica Apolo
    INSERT INTO public.tenants (id, nombre, nit) 
    VALUES ('${tenantApoloId}', 'Clínica Dental Apolo', '901234567');

    INSERT INTO public.profiles (id, tenant_id, full_name, role, registro_medico, especialidad)
    VALUES ('${doctorApoloId}', '${tenantApoloId}', 'Dra. Elena Apolo', 'odontologo', 'RETHUS-AP-101', 'Odontología General');

    INSERT INTO public.sucursales (tenant_id, nombre, codigo_habilitacion_reps, codigo_sede_reps, divipola_municipio)
    VALUES ('${tenantApoloId}', 'Sede Norte Apolo', '110010998801', '01', '11001');

    -- Clínica Boreal
    INSERT INTO public.tenants (id, nombre, nit) 
    VALUES ('${tenantBorealId}', 'Clínica Odontológica Boreal', '900987654');

    INSERT INTO public.profiles (id, tenant_id, full_name, role, registro_medico, especialidad)
    VALUES ('${doctorBorealId}', '${tenantBorealId}', 'Dr. Marcos Boreal', 'doctor', 'RETHUS-BO-202', 'Rehabilitación Oral');

    INSERT INTO public.sucursales (tenant_id, nombre, codigo_habilitacion_reps, codigo_sede_reps, divipola_municipio)
    VALUES ('${tenantBorealId}', 'Sede Poblado Boreal', '050010112201', '01', '05001');

    -- Superadmin de Soporte de Infraestructura
    INSERT INTO public.profiles (id, tenant_id, full_name, role)
    VALUES ('${superadminId}', '${tenantApoloId}', 'Ing. Soporte Técnico TI', 'superadmin');

    -- Pacientes Sintéticos
    INSERT INTO public.pacientes (id, tenant_id, tipo_documento, documento, nombres, apellidos, pertenencia_etnica_codigo, divipola_municipio)
    VALUES ('${pacienteApoloId}', '${tenantApoloId}', 'CC', '1018234567', 'Carlos', 'Sintético Apolo', '6', '11001');

    INSERT INTO public.pacientes (id, tenant_id, tipo_documento, documento, nombres, apellidos, pertenencia_etnica_codigo, divipola_municipio)
    VALUES ('${pacienteBorealId}', '${tenantBorealId}', 'CC', '1020345678', 'Diana', 'Sintética Boreal', '1', '05001');
  `);
  assert(true, 'Dos clínicas ficticias (Apolo y Boreal), profesionales y pacientes creados');

  logHeader('TEST 2: AISLAMIENTO MULTI-TENANT ESTRICTO ENTRE CLÍNICAS (RLS)');

  // Probar como Doctor Boreal
  const borealViewApolo = runSql(`
    SET ROLE authenticated;
    SET request.jwt.claim.sub = '${doctorBorealId}';
    SELECT count(*) as count FROM public.pacientes WHERE tenant_id = '${tenantApoloId}';
  `);
  assert(borealViewApolo.includes('0'), 'Doctor Boreal no puede ver los pacientes de Clínica Apolo (conteo = 0)');

  const borealViewOwn = runSql(`
    SET ROLE authenticated;
    SET request.jwt.claim.sub = '${doctorBorealId}';
    SELECT count(*) as count FROM public.pacientes WHERE tenant_id = '${tenantBorealId}';
  `);
  assert(borealViewOwn.includes('1'), 'Doctor Boreal puede ver exclusivamente los pacientes de su propia clínica (conteo = 1)');

  logHeader('TEST 3: SEGURIDAD LEAST PRIVILEGE — SUPERADMIN BLOQUEADO DE HISTORIAS');

  // Superadmin intentando leer pacientes y evoluciones
  const superadminPacientes = runSql(`
    SET ROLE authenticated;
    SET request.jwt.claim.sub = '${superadminId}';
    SELECT count(*) as count FROM public.pacientes;
  `);
  assert(superadminPacientes.includes('0'), 'Superadmin de TI bloqueado por RLS de leer pacientes (conteo = 0)');

  logHeader('TEST 4: PROTOCOLO BREAK-GLASS DE CONTINGENCIA AUDITADO');

  // Superadmin solicita acceso de emergencia justificado para paciente de Apolo
  const breakGlassResult = runSql(`
    SET ROLE authenticated;
    SET request.jwt.claim.sub = '${superadminId}';
    SELECT public.request_break_glass_access(
      '${pacienteApoloId}'::uuid,
      'Requerimiento de auditoría judicial urgente expediente No. 4921',
      'TICKET-SEC-882'
    ) as result;
  `);
  assert(breakGlassResult.includes('success": true'), 'Protocolo Break-Glass activado con justificación obligatoria');

  // Verificar que ahora el superadmin puede ver exclusivamente a ese paciente
  const superadminPostBreakGlass = runSql(`
    SET ROLE authenticated;
    SET request.jwt.claim.sub = '${superadminId}';
    SELECT count(*) as count FROM public.pacientes WHERE id = '${pacienteApoloId}';
  `);
  assert(superadminPostBreakGlass.includes('1'), 'Superadmin tiene acceso acotado en tiempo únicamente al paciente autorizado');

  // Verificar que el evento quedó registrado en audit_logs
  const auditLogCheck = runSql(`
    SELECT count(*) as count FROM public.audit_logs 
    WHERE action = 'BREAK_GLASS_ACCESS_ACTIVATED' AND target_id = '${pacienteApoloId}';
  `);
  assert(auditLogCheck.includes('1'), 'Evento de Break-Glass registrado de forma inmutable en audit_logs');

  logHeader('TEST 5: PROTECCIÓN CONTRA BORRADO DE EXPEDIENTES (ON DELETE RESTRICT)');

  // Crear consentimiento firmado y odontograma para paciente Apolo
  runSql(`
    INSERT INTO public.documentos_clinicos (tenant_id, paciente_id, tipo, firmado, contenido)
    VALUES ('${tenantApoloId}', '${pacienteApoloId}', 'Consentimiento Informado Endodoncia', true, 'Firma verificada');

    INSERT INTO public.odontogramas (tenant_id, paciente_id, hallazgos)
    VALUES ('${tenantApoloId}', '${pacienteApoloId}', '{"16": "caries_oclusal"}');
  `);

  // Intentar eliminar físicamente al paciente
  let deleteErrorOutput = runSqlQuiet(`
    DELETE FROM public.pacientes WHERE id = '${pacienteApoloId}';
  `);
  assert(
    deleteErrorOutput.includes('violates foreign key constraint') || deleteErrorOutput.includes('RESTRICT'),
    'Motor PostgreSQL 17.6 RECHAZA el borrado del paciente con ON DELETE RESTRICT'
  );

  // Verificar que los consentimientos siguen intactos
  const docsPreserved = runSql(`
    SELECT count(*) as count FROM public.documentos_clinicos WHERE paciente_id = '${pacienteApoloId}';
  `);
  assert(docsPreserved.includes('1'), 'Consentimientos informados y odontograma protegidos de destrucción');

  logHeader('TEST 6: CIERRE DE EVOLUCIÓN E INMUTABILIDAD CON HASH SHA-256');

  const evolutionId = crypto.randomUUID();
  runSql(`
    INSERT INTO public.evoluciones (
      id, tenant_id, paciente_id, diagnostico, procedimiento_cups, status,
      cie10_principal_codigo, cie10_principal_tipo, cups_codigo, modalidad_atencion, causa_externa, notas
    ) VALUES (
      '${evolutionId}', '${tenantApoloId}', '${pacienteApoloId}',
      'K021 - Caries de la dentina', '230101', 'borrador',
      'K021', 2, '230101', '01', '13', 'Paciente asiste a restauración de resina pieza 16'
    );
  `);

  // Cerrar la evolución
  const closeResult = runSql(`
    SET ROLE authenticated;
    SET request.jwt.claim.sub = '${doctorApoloId}';
    SELECT public.close_evolution('${evolutionId}'::uuid) as res;
  `);
  assert(closeResult.includes('content_hash'), 'Evolución sellada con cálculo de hash SHA-256 y cerrado atómico');

  // Intentar modificar la evolución cerrada
  const updateEvoBlocked = runSqlQuiet(`
    UPDATE public.evoluciones SET diagnostico = 'Modificación indebida' WHERE id = '${evolutionId}';
  `);
  assert(
    updateEvoBlocked.includes('EVOLUTION_IS_IMMUTABLE'),
    'Trigger bloquea cualquier intento de alteración sobre la evolución cerrada'
  );

  logHeader('TEST 7: ENCOLAMIENTO ATÓMICO EN ihce_outbox_queue VIA TRIGGER');

  const queueEntry = runSql(`
    SELECT id, status, idempotency_key, snapshot_hash 
    FROM public.ihce_outbox_queue 
    WHERE evolution_id = '${evolutionId}';
  `);
  assert(queueEntry.includes('PENDIENTE'), 'Evolución cerrada fue encolada automáticamente en ihce_outbox_queue');

  // Verificar Idempotencia: intentar insertar duplicado con la misma clave
  const duplicateInsert = runSqlQuiet(`
    INSERT INTO public.ihce_outbox_queue (
      tenant_id, evolution_id, paciente_id, idempotency_key, snapshot_hash, status
    ) VALUES (
      '${tenantApoloId}', '${evolutionId}', '${pacienteApoloId}',
      (SELECT idempotency_key FROM public.ihce_outbox_queue WHERE evolution_id = '${evolutionId}'),
      'dummy_hash', 'PENDIENTE'
    );
  `);
  assert(
    duplicateInsert.includes('duplicate key value violates unique constraint') || duplicateInsert.includes('uq_ihce_queue_idempotency'),
    'Idempotencia estricta: Se rechaza la duplicación de tareas en la cola'
  );

  logHeader('TEST 8: GENERADOR Y VALIDADOR DE BUNDLE HL7 FHIR R4 (COLOMBIA RDA)');

  const bundle = buildRdaConsultaExternaBundle({
    evolution: {
      id: evolutionId,
      fecha: new Date().toISOString(),
      closed_at: new Date().toISOString(),
      cie10_principal_codigo: 'K021',
      cie10_principal_tipo: 2,
      diagnostico: 'Caries de la dentina',
      cups_codigo: '230101',
      tratamiento: 'Restauración en resina',
      modalidad_atencion: '01',
      causa_externa: '13',
      notas: 'Atención odontológica en consultorio intramural'
    },
    patient: {
      id: pacienteApoloId,
      tipo_documento: 'CC',
      documento: '1018234567',
      nombres: 'Carlos',
      apellidos: 'Sintético Apolo',
      genero: 'M',
      fecha_nacimiento: '1995-04-12',
      direccion: 'Carrera 7 # 45-10',
      ciudad: 'Bogotá',
      divipola_municipio: '11001',
      pertenencia_etnica_codigo: '6'
    },
    practitioner: {
      id: doctorApoloId,
      tipo_documento: 'CC',
      numero_documento: '52123456',
      nombre_completo: 'Dra. Elena Apolo',
      registro_medico: 'RETHUS-AP-101',
      especialidad: 'Odontología General'
    },
    organization: {
      id: tenantApoloId,
      nombre: 'Clínica Dental Apolo',
      nit: '901234567'
    },
    branch: {
      id: crypto.randomUUID(),
      nombre: 'Sede Norte Apolo',
      codigo_habilitacion_reps: '110010998801',
      codigo_sede_reps: '01'
    }
  });

  const validation = validateRdaBundle(bundle);
  assert(validation.valid === true, 'Bundle RDA oficial generado y validado contra especificación FHIR R4');
  assert(bundle.resourceType === 'Bundle' && bundle.type === 'document', 'Bundle es formalmente de tipo "document"');
  assert(bundle.entry[0].resource.resourceType === 'Composition', 'Primera entrada del Bundle es una Composition válida');
  assert(bundle.entry.some(e => e.resource.resourceType === 'Condition'), 'Bundle contiene el recurso Condition con CIE-10');
  assert(bundle.entry.some(e => e.resource.resourceType === 'Procedure'), 'Bundle contiene el recurso Procedure con CUPS');

  logHeader('TEST 9: SIMULACIÓN DE DESPACHO DE COLA CON MOCK DE VULCANO');

  const queueItemSimulated = {
    id: crypto.randomUUID(),
    tenant_id: tenantApoloId,
    intentos: 0,
    max_intentos: 5
  };

  const contextData = {
    evolution: { id: evolutionId, cie10_principal_codigo: 'K021', cups_codigo: '230101' },
    patient: { tipo_documento: 'CC', documento: '1018234567', nombres: 'Carlos', apellidos: 'Sintético' },
    practitioner: { nombre_completo: 'Dra. Elena Apolo' },
    organization: { nombre: 'Clínica Apolo' },
    branch: { nombre: 'Sede Norte' }
  };

  // Simulación 1: Aceptado 201 por Minsalud
  const successClient = new MockVulcanoClient({ mode: 'SUCCESS' });
  const resultSuccess = await processQueueItem(queueItemSimulated, contextData, successClient);
  assert(resultSuccess.status === 'ACEPTADO' && resultSuccess.http_status === 201, 'Despacho simulado: RDA aceptado exitosamente con radicado');

  // Simulación 2: Rechazado 422 semántico
  const rejectClient = new MockVulcanoClient({ mode: 'REJECTED_422' });
  const resultReject = await processQueueItem(queueItemSimulated, contextData, rejectClient);
  assert(resultReject.status === 'RECHAZADO' && resultReject.http_status === 422, 'Despacho simulado: Rechazo semántico 422 detectado sin reintentar');

  // Simulación 3: Error temporal de red 503 con backoff exponencial
  const networkClient = new MockVulcanoClient({ mode: 'NETWORK_ERROR_503' });
  const resultRetry = await processQueueItem(queueItemSimulated, contextData, networkClient);
  assert(resultRetry.status === 'ERROR_REINTENTO' && resultRetry.intentos === 1, 'Despacho simulado: Falla 503 encola reintento exponencial sin perder datos');

  logHeader(`RESUMEN DE PRUEBAS DE FASE 1: ${passedTests}/${totalTests} PASADAS`);
  console.log('✓ Todas las validaciones de base de datos, seguridad, RLS, FHIR y cola fueron verificadas.');
}

runPhase1RealDatabaseSuite().catch(err => {
  console.error('\n✗ ERROR EN LA SUITE:', err);
  process.exit(1);
});
